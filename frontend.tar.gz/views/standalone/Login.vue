<template>
  <div class="login">
    <section class="login-story">
      <span class="eyebrow">TG ATTENDANCE / WORKSPACE</span>
      <h1>让每一次打卡，<br />都有清晰的记录。</h1>
      <p>Telegram 打卡 · 多班次 · 活动管理 · 审批与报表</p>
      <div class="orbit">
        <span>✓</span><small>CONNECTED TO YOUR TEAM</small>
      </div>
      <div class="story-footer">独立部署 / 数据自持 / 原有打卡体验</div>
    </section>
    <section class="login-form">
      <div>
        <span class="eyebrow">WELCOME BACK</span>
        <h2>登录考勤工作台</h2>
        <p class="muted">使用部署时创建的管理员账号。</p>
        <el-form @submit.prevent="submit" label-position="top"
          ><el-form-item label="账号"
            ><el-input
              v-model="username"
              autocomplete="username"
              size="large" /></el-form-item
          ><el-form-item label="密码"
            ><el-input
              v-model="password"
              type="password"
              show-password
              autocomplete="current-password"
              size="large" /></el-form-item
          ><el-alert
            v-if="error"
            :title="error"
            type="error"
            :closable="false"
          /><el-button
            native-type="submit"
            type="primary"
            size="large"
            :loading="busy"
            style="width: 100%; margin-top: 20px"
            >进入工作台 →</el-button
          ></el-form
        >
        <p class="muted" style="font-size: 11px; margin-top: 22px">
          免费服务休眠后，首次连接可能需要约一分钟。
        </p>
      </div>
    </section>
  </div>
</template>
<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useUserStore } from "../../store/user";
const username = ref("admin"),
  password = ref(""),
  error = ref(""),
  busy = ref(false),
  router = useRouter(),
  user = useUserStore();
async function submit() {
  busy.value = true;
  error.value = "";
  try {
    await user.login({ username: username.value, password: password.value });
    await router.push("/");
  } catch (e: any) {
    error.value = e.message;
  } finally {
    busy.value = false;
  }
}
</script>
<style scoped>
.login {
  display: grid;
  grid-template-columns: 1.05fr 1fr;
  min-height: 100vh;
}
.login-story {
  background: #102b2d;
  color: #e0eee6;
  padding: 65px 9%;
  position: relative;
  overflow: hidden;
}
.eyebrow {
  font-size: 10px;
  letter-spacing: 2px;
  color: #879e96;
}
.login-story h1 {
  font-size: clamp(28px, 3vw, 46px);
  line-height: 1.5;
  font-weight: 500;
  margin-top: 100px;
}
.login-story p {
  font-size: 12px;
  color: #9ab8ad;
  line-height: 2;
}
.orbit {
  margin: 65px auto;
  border: 1px solid #31514a;
  width: 230px;
  height: 230px;
  border-radius: 50%;
  display: grid;
  place-content: center;
  text-align: center;
  outline: 1px solid #24423d;
  outline-offset: 30px;
}
.orbit span {
  font-size: 65px;
  color: #c5e9b8;
}
.orbit small {
  font-size: 8px;
  letter-spacing: 2px;
  color: #789d8a;
  margin-top: 15px;
}
.story-footer {
  font-size: 11px;
  color: #729286;
  margin-top: 80px;
}
.login-form {
  display: grid;
  place-items: center;
  background: #fbfcfb;
  padding: 40px;
}
.login-form > div {
  width: 100%;
  max-width: 350px;
}
.login-form h2 {
  font-size: 27px;
  margin: 20px 0 10px;
}
.login-form form {
  margin-top: 35px;
}
@media (max-width: 760px) {
  .login {
    grid-template-columns: 1fr;
  }
  .login-story {
    display: none;
  }
  .login-form {
    min-height: 100vh;
  }
}
</style>

<template>
  <div>
    <h1 class="page-title">员工与绑定</h1>
    <p class="muted">
      创建独立的员工档案，再到「打卡规则 → 员工绑定」关联 Telegram 用户 ID。
    </p>
    <section class="panel">
      <div
        style="
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
        "
      >
        <el-input
          v-model="search"
          placeholder="按姓名或工号筛选"
          clearable
          style="max-width: 280px"
        /><el-button type="primary" @click="open()">＋ 新建员工</el-button>
      </div>
      <el-table :data="filtered" v-loading="busy"
        ><el-table-column prop="employeeId" label="工号" /><el-table-column
          prop="name"
          label="姓名"
        /><el-table-column prop="position" label="职位" /><el-table-column
          prop="workLocation"
          label="工作地点"
        /><el-table-column prop="hireDate" label="入职日期" /><el-table-column
          label="操作"
          ><template #default="{ row }"
            ><el-button link @click="open(row)">编辑</el-button></template
          ></el-table-column
        ></el-table
      >
    </section>
    <el-dialog
      v-model="visible"
      :title="form.id ? '编辑员工' : '新建员工'"
      width="480px"
      ><el-form label-position="top"
        ><el-form-item label="工号"
          ><el-input v-model="form.employee_id" /></el-form-item
        ><el-form-item label="姓名"
          ><el-input v-model="form.name" /></el-form-item
        ><el-form-item label="职位"
          ><el-input v-model="form.position" /></el-form-item
        ><el-form-item label="工作地点"
          ><el-input v-model="form.work_location" /></el-form-item
        ><el-form-item label="入职日期"
          ><el-input
            v-model="form.hire_date"
            type="date" /></el-form-item></el-form
      ><template #footer
        ><el-button @click="visible = false">取消</el-button
        ><el-button type="primary" :loading="saving" @click="save"
          >保存</el-button
        ></template
      ></el-dialog
    >
  </div>
</template>
<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage } from "element-plus";
import request from "../../api/request";
const rows = ref<any[]>([]),
  busy = ref(false),
  saving = ref(false),
  visible = ref(false),
  search = ref(""),
  form = ref<any>({});
const filtered = computed(() =>
  rows.value.filter((x) =>
    (x.name + " " + x.employeeId).includes(search.value),
  ),
);
async function load() {
  busy.value = true;
  try {
    const r: any = await request.get("/admin/employees", {
      params: { limit: 500, employmentScope: "all" },
    });
    rows.value = Array.isArray(r.data)
      ? r.data
      : r.data.items || r.data.employees || [];
  } catch (e: any) {
    ElMessage.error(e.message);
  } finally {
    busy.value = false;
  }
}
function open(row?: any) {
  form.value = row
    ? {
        id: row.id,
        employee_id: row.employeeId,
        name: row.name,
        position: row.position,
        work_location: row.workLocation,
        hire_date: row.hireDate?.slice(0, 10),
      }
    : {
        employee_id: "",
        name: "",
        position: "",
        work_location: "",
        hire_date: new Date().toLocaleDateString("en-CA"),
      };
  visible.value = true;
}
async function save() {
  if (!form.value.name || !form.value.employee_id) {
    ElMessage.warning("请填写姓名和工号");
    return;
  }
  saving.value = true;
  try {
    if (form.value.id)
      await request.put("/admin/employees/" + form.value.id, form.value);
    else await request.post("/admin/employees", form.value);
    visible.value = false;
    await load();
    ElMessage.success("已保存");
  } catch (e: any) {
    ElMessage.error(e.message);
  } finally {
    saving.value = false;
  }
}
onMounted(load);
</script>

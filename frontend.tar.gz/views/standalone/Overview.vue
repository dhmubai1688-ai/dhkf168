<template>
  <div>
    <div class="intro">
      <div>
        <div class="eyebrow">OPERATIONS / 运行状态</div>
        <h1 class="page-title">让考勤，一目了然。</h1>
        <p class="muted">原有打卡规则与消息文案，独立运行的管理空间。</p>
      </div>
      <el-button @click="load" :loading="busy">刷新状态</el-button>
    </div>
    <div class="metrics">
      <article>
        <span>消息处理记录</span><strong>{{ items.length }}</strong
        ><small>最近 100 条 Telegram 更新</small>
      </article>
      <article>
        <span>等待处理</span
        ><strong>{{
          items.filter((x) => x.status === "pending").length
        }}</strong
        ><small>已持久化，等待业务处理</small>
      </article>
      <article>
        <span>需要核对</span
        ><strong :class="{ attention: uncertain > 0 }">{{ uncertain }}</strong
        ><small>处理中断后由管理员核对</small>
      </article>
      <article>
        <span>数据库连接预算</span
        ><strong>{{ data.maxConnections || 5 }}<em> / 20</em></strong
        ><small>Aiven 免费版连接数优化</small>
      </article>
    </div>
    <div class="setup-grid">
      <section class="panel">
        <div class="section-tag">01 / 初次配置</div>
        <h3>连接你的 Telegram 工作群</h3>
        <ol>
          <li>在「员工与绑定」创建员工。</li>
          <li>在「打卡规则」保存 Bot Token，启用 Telegram。</li>
          <li>把机器人加入打卡群，配置允许群组与员工 TG ID。</li>
          <li>点击下面按钮注册 Webhook；更换 Token 或 Secret 后再注册。</li>
        </ol>
        <el-button type="primary" :loading="registering" @click="register"
          >注册 / 更新 Webhook</el-button
        >
        <p class="muted" style="font-size: 11px">
          此操作连接当前配置的机器人，不清空待处理消息。请使用独立机器人。
        </p>
      </section>
      <section class="panel limits">
        <div class="section-tag">02 / 免费部署说明</div>
        <h3>轻量运行，明确边界。</h3>
        <p>
          Render 休眠时，首次打卡会等待服务唤醒。普通文本消息按 Telegram
          原始发送时间记账。
        </p>
        <p>
          按钮回调没有点击时间字段，采用服务器接收时间。定时超时提醒、自动回座及定时重置在休眠期间无法保证准点。
        </p>
        <p>
          记录保存在 Aiven。服务重启不依赖 Render 本地磁盘，也不依赖 Redis。
        </p>
      </section>
    </div>
    <section class="panel">
      <h3>
        消息处理流水 <span class="muted">/ 持久化接收与重复投递去重</span>
      </h3>
      <el-alert
        v-if="error"
        :title="error"
        type="error"
        :closable="false"
      /><el-table
        :data="items"
        empty-text="暂无消息。完成机器人配置后，群内发送 /help 进行验证。"
        ><el-table-column
          prop="updateId"
          label="消息编号"
          width="150"
        /><el-table-column label="接收时间" min-width="170"
          ><template #default="{ row }">{{
            new Date(row.receivedAt).toLocaleString()
          }}</template></el-table-column
        ><el-table-column label="状态" width="110"
          ><template #default="{ row }"
            ><el-tag
              :type="
                row.status === 'uncertain'
                  ? 'warning'
                  : row.status === 'done'
                    ? 'success'
                    : 'info'
              "
              >{{ labels[row.status] || row.status }}</el-tag
            ></template
          ></el-table-column
        ><el-table-column
          prop="note"
          label="说明"
          min-width="220"
        /><el-table-column label="操作" width="100"
          ><template #default="{ row }"
            ><el-button
              v-if="row.status === 'uncertain'"
              link
              type="primary"
              @click="resolve(row)"
              >确认核对</el-button
            ></template
          ></el-table-column
        ></el-table
      >
      <p class="muted" style="font-size: 11px">
        「已处理」表示处理函数已返回；实际打卡是否成功请以业务记录为准。中断的消息不会自动重放，以避免重复罚款。
      </p>
    </section>
    <section class="panel">
      <h3>日重置报表备份 <span class="muted">/ Aiven 保存最近 7 天</span></h3>
      <el-table :data="exports" empty-text="日重置生成报表后会显示在这里。"
        ><el-table-column prop="filename" label="文件" /><el-table-column
          label="生成时间"
          ><template #default="{ row }">{{
            new Date(row.createdAt).toLocaleString()
          }}</template></el-table-column
        ><el-table-column label="下载" width="100"
          ><template #default="{ row }"
            ><a
              :href="
                '/api/v1/standalone/exports/' + encodeURIComponent(row.filename)
              "
              download
              >下载 Excel</a
            ></template
          ></el-table-column
        ></el-table
      >
    </section>
  </div>
</template>
<script setup lang="ts">
import { ref, computed, onMounted } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import request from "../../api/request";
const exports = ref<any[]>([]);
const data = ref<any>({}),
  items = ref<any[]>([]),
  busy = ref(false),
  registering = ref(false),
  error = ref("");
const labels: Record<string, string> = {
  pending: "待处理",
  processing: "处理中",
  done: "已处理",
  uncertain: "待核对",
  resolved: "已核对",
};
const uncertain = computed(
  () => items.value.filter((x) => x.status === "uncertain").length,
);
async function load() {
  busy.value = true;
  error.value = "";
  try {
    const r: any = await request.get("/standalone/status");
    data.value = r.data;
    items.value = r.data.items;
    const b: any = await request.get("/standalone/exports");
    exports.value = b.data.items;
  } catch (e: any) {
    error.value = e.message;
  } finally {
    busy.value = false;
  }
}
async function register() {
  try {
    await ElMessageBox.confirm(
      "将当前机器人连接到此项目。请确认该机器人没有被旧 monitor 服务使用。",
      "注册 Webhook",
    );
    registering.value = true;
    await request.post("/standalone/webhook");
    ElMessage.success("Webhook 已注册");
  } catch (e: any) {
    if (e?.message) ElMessage.error(e.message);
  } finally {
    registering.value = false;
  }
}
async function resolve(row: any) {
  try {
    const r = await ElMessageBox.prompt(
      "请先核对该时段考勤及罚款，必要时在后台修正，再填写结果。不会自动重放消息。",
      "确认核对",
      { inputValidator: (v) => (!!v && v.length >= 4) || "至少填写4个字" },
    );
    await request.post(`/standalone/inbox/${row.updateId}/resolve`, {
      note: r.value,
    });
    await load();
  } catch (e: any) {
    if (e?.message) ElMessage.error(e.message);
  }
}
onMounted(load);
</script>
<style scoped>
.intro {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.eyebrow,
.section-tag {
  font-size: 10px;
  letter-spacing: 1.5px;
  color: #7b9188;
  margin: 4px 0 15px;
}
.metrics {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-top: 25px;
}
.metrics article {
  background: white;
  border: 1px solid #e3e9eb;
  border-radius: 12px;
  padding: 23px;
}
.metrics span {
  font-size: 12px;
  color: #72827e;
}
.metrics strong {
  display: block;
  font-size: 37px;
  color: #244c41;
  font-weight: 550;
  margin: 17px 0;
}
.metrics em {
  font-size: 17px;
  font-style: normal;
  color: #b2bfba;
}
.metrics small {
  font-size: 10px;
  color: #92a09a;
}
.metrics .attention {
  color: #ba7843;
}
.setup-grid {
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 20px;
}
.setup-grid h3 {
  font-size: 17px;
}
.setup-grid ol {
  padding-left: 18px;
  font-size: 12px;
  line-height: 2.6;
  color: #5c706b;
  margin: 0 0 22px;
}
.limits {
  background: #edf2e9;
  border-color: #dde6d8;
}
.limits p {
  font-size: 12px;
  line-height: 1.95;
  color: #5a7063;
  margin: 14px 0;
}
@media (max-width: 1150px) {
  .metrics {
    grid-template-columns: repeat(2, 1fr);
  }
  .setup-grid {
    grid-template-columns: 1fr;
  }
}
@media (max-width: 600px) {
  .metrics {
    grid-template-columns: 1fr;
  }
  .intro {
    align-items: start;
  }
  .page-title {
    font-size: 22px;
  }
}
</style>

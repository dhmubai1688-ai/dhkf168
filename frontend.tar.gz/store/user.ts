import { defineStore } from "pinia";
import { ref } from "vue";
import request from "../api/request";
export const useUserStore = defineStore("user", () => {
  const role = ref(""),
    username = ref(""),
    permissions = ref<string[]>([]),
    isAuthenticated = ref(false),
    userId = ref("");
  const token = ref("");
  function apply(data: any) {
    role.value = data.role;
    username.value = data.username;
    userId.value = data.id;
    permissions.value = data.permissions || [];
    isAuthenticated.value = true;
  }
  async function login(payload: any) {
    const r: any = await request.post("/auth/login", payload);
    apply(r.data);
  }
  async function validateSession() {
    try {
      const r: any = await request.get("/auth/me");
      apply(r.data);
      return true;
    } catch {
      return false;
    }
  }
  async function logout() {
    await request.post("/auth/logout");
    role.value = "";
    isAuthenticated.value = false;
    location.assign("/login");
  }
  function hasPermission(p: string) {
    return role.value === "admin" || permissions.value.includes(p);
  }
  return {
    role,
    username,
    permissions,
    isAuthenticated,
    userId,
    token,
    login,
    logout,
    validateSession,
    ensureSession: validateSession,
    hasPermission,
    hasAnyPermission: (p: string[]) => p.some(hasPermission),
  };
});

<template>
  <router-view v-if="$route.path === '/login' || $route.meta.popup" />
  <div v-else class="shell">
    <aside>
      <router-link class="brand" to="/"
        ><span class="brand-icon">↗</span>
        <div>TG Attendance<small>独立考勤工作台</small></div></router-link
      >
      <div class="nav-caption">WORKSPACE / 工作空间</div>
      <nav>
        <router-link v-for="item in menus" :key="item.path" :to="item.path"
          ><span>{{ item.icon }}</span
          >{{ item.label }}</router-link
        >
      </nav>
      <div class="aside-bottom">
        <span class="dot"></span> Render + Aiven
        <p>数据持久保存在 PostgreSQL</p>
      </div>
    </aside>
    <section class="workspace">
      <header>
        <span>{{ title }}</span>
        <div class="header-right">
          <span>{{ user.username }}</span
          ><button @click="user.logout">退出登录</button>
        </div>
      </header>
      <main><router-view /></main>
      <footer>TG ATTENDANCE · 免费实例休眠可能延迟首次响应与定时提醒</footer>
    </section>
  </div>
</template>
<script setup lang="ts">
import { computed } from "vue";
import { useRoute } from "vue-router";
import { useUserStore } from "./store/user";
const user = useUserStore(),
  route = useRoute();
const menus = [
  { path: "/", label: "运行概览", icon: "◈" },
  { path: "/employees", label: "员工与绑定", icon: "◎" },
  { path: "/telegram", label: "打卡规则", icon: "⚙" },
  { path: "/telegram-records", label: "打卡记录", icon: "▤" },
  { path: "/telegram-punch", label: "后台打卡", icon: "↗" },
  { path: "/attendance", label: "考勤月历", icon: "▦" },
  { path: "/attendance-review", label: "待确认审批", icon: "◷" },
  { path: "/penalty-details", label: "罚款详情", icon: "◇" },
];
const title = computed(
  () => menus.find((x) => x.path === route.path)?.label || "考勤工作台",
);
</script>
<style>
* {
  box-sizing: border-box;
}
body {
  margin: 0;
  font-family:
    Inter,
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    "PingFang SC",
    sans-serif;
  color: #233146;
  background: #f5f7fa;
}
a {
  color: inherit;
  text-decoration: none;
}
button {
  cursor: pointer;
}
.shell {
  display: flex;
  min-height: 100vh;
}
aside {
  width: 228px;
  background: #102b2d;
  color: #b8cbca;
  position: fixed;
  inset: 0 auto 0 0;
  padding: 30px 19px;
  display: flex;
  flex-direction: column;
}
.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  color: white;
  font-weight: 650;
  font-size: 17px;
}
.brand small {
  display: block;
  font-size: 11px;
  color: #8da9a7;
  font-weight: 400;
  margin-top: 6px;
}
.brand-icon {
  display: grid;
  place-items: center;
  background: #b9edbc;
  color: #123831;
  border-radius: 12px;
  width: 35px;
  height: 38px;
  font-size: 26px;
}
.nav-caption {
  font-size: 9px;
  letter-spacing: 1.5px;
  color: #72918f;
  margin: 50px 12px 17px;
}
nav {
  display: grid;
  gap: 6px;
}
nav a {
  padding: 13px;
  border-radius: 8px;
  font-size: 13px;
  display: flex;
  gap: 14px;
}
nav a:hover {
  background: #1a3c3d;
}
nav a.router-link-exact-active {
  background: #254b46;
  color: #d6f4cb;
}
.aside-bottom {
  margin-top: auto;
  padding: 25px 8px 0;
  font-size: 11px;
}
.aside-bottom p {
  color: #789996;
  font-size: 10px;
}
.dot {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #b9edbc;
  margin-right: 5px;
}
.workspace {
  margin-left: 228px;
  min-width: 0;
  flex: 1;
}
header {
  height: 73px;
  background: white;
  border-bottom: 1px solid #e6ebee;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 34px;
  font-size: 14px;
}
.header-right {
  display: flex;
  gap: 20px;
  align-items: center;
  font-size: 12px;
  color: #71808e;
}
.header-right button {
  border: 0;
  background: transparent;
  color: #45615c;
}
main {
  padding: 30px;
  max-width: 1650px;
  margin: auto;
}
footer {
  font-size: 10px;
  letter-spacing: 0.5px;
  color: #89979c;
  padding: 15px 32px 25px;
}
.el-button--primary {
  --el-button-bg-color: #205c50;
  --el-button-border-color: #205c50;
  --el-button-hover-bg-color: #347567;
  --el-button-hover-border-color: #347567;
}
.page-title {
  margin: 0 0 8px;
  font-size: 26px;
  font-weight: 600;
}
.muted {
  color: #819096;
  font-size: 13px;
  line-height: 1.8;
}
.panel {
  background: white;
  border: 1px solid #e3e9eb;
  border-radius: 13px;
  padding: 24px;
  margin-top: 24px;
}
.panel h3 {
  margin: 0 0 20px;
  font-size: 15px;
}
.el-table {
  font-size: 12px !important;
}
@media (max-width: 900px) {
  aside {
    width: 72px;
    padding: 25px 9px;
  }
  .brand div,
  .nav-caption,
  .aside-bottom {
    display: none;
  }
  nav {
    margin-top: 30px;
  }
  nav a {
    font-size: 0;
    justify-content: center;
    padding: 14px;
  }
  nav a span {
    font-size: 18px;
  }
  .workspace {
    margin-left: 72px;
  }
  main {
    padding: 18px;
  }
  header {
    padding: 0 20px;
  }
  .brand-icon {
    margin: auto;
  }
}
</style>

package standalone

import (
	"context"
	"crypto/subtle"
	"database/sql"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"io"
	"log"
	"net/http"
	"os"
	"tg-attendance/backend/internal/tgbot"
	"tg-attendance/backend/models"
	"tg-attendance/backend/services"
	"time"
)

type Inbox struct {
	DB   *sql.DB
	TG   *services.WorkforceTelegramService
	Wake chan struct{}
}

func (i *Inbox) Notify() {
	select {
	case i.Wake <- struct{}{}:
	default:
	}
}
func (i *Inbox) Accept(c *gin.Context) {
	secret, err := i.TG.GetWebhookSecret(c.Request.Context())
	if err != nil || secret == "" {
		c.Status(503)
		return
	}
	if subtle.ConstantTimeCompare([]byte(secret), []byte(c.GetHeader("X-Telegram-Bot-Api-Secret-Token"))) != 1 {
		c.Status(403)
		return
	}
	body, err := io.ReadAll(http.MaxBytesReader(c.Writer, c.Request.Body, 1<<20))
	if err != nil {
		c.Status(413)
		return
	}
	var u struct {
		ID *int64 `json:"update_id"`
	}
	if json.Unmarshal(body, &u) != nil || u.ID == nil || *u.ID < 0 {
		c.Status(400)
		return
	}
	if _, err = i.DB.ExecContext(c.Request.Context(), `INSERT INTO standalone_inbox(update_id,body) VALUES($1,$2) ON CONFLICT DO NOTHING`, *u.ID, string(body)); err != nil {
		c.Status(503)
		return
	}
	// Acknowledge only after durable storage. Telegram retries safely on a database failure.
	i.Notify()
	c.Status(200)
}
func (i *Inbox) Run(ctx context.Context) {
	// One worker per database. Session advisory lock prevents duplicate processing on deploy overlap.
	conn, err := i.DB.Conn(ctx)
	if err != nil {
		return
	}
	defer conn.Close()
	for {
		var locked bool
		if err = conn.QueryRowContext(ctx, "SELECT pg_try_advisory_lock(84392702)").Scan(&locked); err != nil {
			return
		}
		if locked {
			break
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(5 * time.Second):
		}
	}
	defer conn.ExecContext(context.Background(), "SELECT pg_advisory_unlock(84392702)")
	// Legacy business operations aren't one transaction with external Telegram sends.
	// Never silently replay a partially processed event and risk duplicate fines/exports.
	i.DB.ExecContext(ctx, `UPDATE standalone_inbox SET status='uncertain',note='进程在处理期间退出；请核对考勤后处理，系统不会自动重放' WHERE status='processing'`)
	ticker := time.NewTicker(15 * time.Second)
	defer ticker.Stop()
	lastMaintenance, lastFull := time.Time{}, time.Time{}
	for {
		select {
		case <-ctx.Done():
			return
		case <-i.Wake:
		case <-ticker.C:
		}
		for ctx.Err() == nil {
			opts, e := i.TG.BuildTelegramBotOptions(os.Getenv("PORT"))
			if e != nil || opts.BotToken == "" {
				break
			}
			var id int64
			var body []byte
			var received time.Time
			e = i.DB.QueryRowContext(ctx, `UPDATE standalone_inbox SET status='processing',started_at=NOW() WHERE update_id=(SELECT update_id FROM standalone_inbox WHERE status='pending' ORDER BY update_id LIMIT 1) RETURNING update_id,body,received_at`).Scan(&id, &body, &received)
			if e == sql.ErrNoRows {
				break
			}
			if e != nil {
				log.Print("Inbox database unavailable")
				break
			}
			err = i.process(opts, body, received)
			status, note := "done", ""
			if err != nil {
				status = "uncertain"
				note = "处理异常，请核对业务记录后确认"
				log.Printf("Inbox update %d needs review: %v", id, err)
			}
			if _, e = i.DB.ExecContext(ctx, `UPDATE standalone_inbox SET status=$2,note=$3,finished_at=NOW(),body=CASE WHEN $2='done' THEN '{}'::jsonb ELSE body END WHERE update_id=$1`, id, status, note); e != nil {
				log.Print("Inbox completion could not be persisted; stopping to avoid unsafe replay")
				return
			}
		}
		if time.Since(lastMaintenance) >= 15*time.Second && ctx.Err() == nil {
			var pending int
			if e := i.DB.QueryRowContext(ctx, "SELECT COUNT(*) FROM standalone_inbox WHERE status IN ('pending','processing')").Scan(&pending); e == nil && pending == 0 {
				full := time.Since(lastFull) >= time.Hour
				maintenance, cancel := services.StandaloneMaintenanceContext(ctx)
				i.TG.StandaloneMaintenance(maintenance, full)
				cancel()
				lastMaintenance = time.Now()
				if full {
					lastFull = time.Now()
				}
			}
		}
	}
}
func (i *Inbox) process(opts tgbot.Options, body []byte, received time.Time) (err error) {
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("handler panic")
		}
	}()
	return tgbot.ProcessDurableUpdate(opts, body, received)
}
func (i *Inbox) Status(c *gin.Context) {
	rows, e := i.DB.QueryContext(c.Request.Context(), `SELECT update_id,status,received_at,note FROM standalone_inbox ORDER BY received_at DESC LIMIT 100`)
	if e != nil {
		models.SendError(c, 503, 503, "数据库暂不可用")
		return
	}
	defer rows.Close()
	items := []gin.H{}
	for rows.Next() {
		var id int64
		var status, note string
		var at time.Time
		if rows.Scan(&id, &status, &at, &note) == nil {
			items = append(items, gin.H{"updateId": id, "status": status, "receivedAt": at, "note": note})
		}
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items, "database": "Aiven PostgreSQL", "maxConnections": i.DB.Stats().MaxOpenConnections, "sleepNotice": "免费 Render 休眠期间不保证定时提醒准点；首次打卡需要唤醒。"})
}
func (i *Inbox) Resolve(c *gin.Context) {
	var in struct {
		Note string `json:"note"`
	}
	if c.ShouldBindJSON(&in) != nil || len(in.Note) < 4 || len(in.Note) > 500 {
		models.SendError(c, 400, 400, "请填写核对结果（4至500字）")
		return
	}
	r, e := i.DB.ExecContext(c.Request.Context(), `UPDATE standalone_inbox SET status='resolved',note=$2,finished_at=NOW(),body='{}'::jsonb WHERE update_id=$1 AND status='uncertain'`, c.Param("id"), in.Note)
	if e != nil {
		models.SendError(c, 500, 500, "更新失败")
		return
	}
	n, _ := r.RowsAffected()
	if n == 0 {
		models.SendError(c, 409, 409, "该消息不在待核对状态")
		return
	}
	models.Send(c, 200, 0, "success", nil)
}

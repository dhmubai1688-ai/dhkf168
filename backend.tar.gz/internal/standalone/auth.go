package standalone

import (
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"net/http"
	"net/url"
	"os"
	"strings"
	"tg-attendance/backend/models"
	"time"
)

type Auth struct{ DB *sql.DB }

func digest(s string) string { h := sha256.Sum256([]byte(s)); return hex.EncodeToString(h[:]) }
func (a Auth) cookie(c *gin.Context, value string, age int) {
	c.SetSameSite(http.SameSiteStrictMode)
	c.SetCookie("tg_admin", value, age, "/", "", os.Getenv("ENV") == "production", true)
}
func SameOrigin() gin.HandlerFunc {
	return func(c *gin.Context) {
		if c.Request.Method != "GET" && c.Request.Method != "HEAD" {
			origin := c.GetHeader("Origin")
			if origin != "" {
				u, e := url.Parse(origin)
				if e != nil || u.Host != c.Request.Host {
					c.AbortWithStatusJSON(403, gin.H{"code": 403, "message": "跨站请求被拒绝"})
					return
				}
			}
			if c.GetHeader("X-Requested-With") != "TGAttendance" {
				c.AbortWithStatusJSON(403, gin.H{"code": 403, "message": "缺少请求校验标记"})
				return
			}
		}
		c.Next()
	}
}
func (a Auth) Login(c *gin.Context) {
	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if c.ShouldBindJSON(&in) != nil || len(in.Username) > 100 || len(in.Password) > 256 {
		models.SendError(c, 400, 400, "请求格式错误")
		return
	}
	// Database-backed throttle survives restarts. Username limit also prevents proxy-IP spoofing bypass.
	for _, key := range []string{"user:" + strings.ToLower(in.Username), "global"} {
		var attempts int
		err := a.DB.QueryRowContext(c.Request.Context(), `INSERT INTO standalone_login_attempts(bucket,attempts,expires_at) VALUES($1,1,NOW()+interval '15 minutes') ON CONFLICT(bucket) DO UPDATE SET attempts=CASE WHEN standalone_login_attempts.expires_at<NOW() THEN 1 ELSE standalone_login_attempts.attempts+1 END,expires_at=CASE WHEN standalone_login_attempts.expires_at<NOW() THEN NOW()+interval '15 minutes' ELSE standalone_login_attempts.expires_at END RETURNING attempts`, digest(key)).Scan(&attempts)
		limit := 10
		if key == "global" {
			limit = 100
		}
		if err != nil {
			models.SendError(c, 503, 503, "数据库暂不可用")
			return
		}
		if attempts > limit {
			models.SendError(c, 429, 429, "登录尝试过多，请15分钟后重试")
			return
		}
	}
	var id, hash, name string
	err := a.DB.QueryRowContext(c.Request.Context(), `SELECT u.id,u.password_hash,u.username FROM users u WHERE u.username=$1 AND u.status=1 AND EXISTS(SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.name IN ('管理员','admin'))`, in.Username).Scan(&id, &hash, &name)
	if err != nil || bcrypt.CompareHashAndPassword([]byte(hash), []byte(in.Password)) != nil {
		models.SendError(c, 401, 401, "用户名或密码错误")
		return
	}
	token := make([]byte, 32)
	if _, err = rand.Read(token); err != nil {
		models.SendError(c, 500, 500, "无法创建会话")
		return
	}
	s := hex.EncodeToString(token)
	if _, err = a.DB.ExecContext(c.Request.Context(), `INSERT INTO standalone_sessions VALUES($1,$2,$3)`, digest(s), id, time.Now().Add(12*time.Hour)); err != nil {
		models.SendError(c, 503, 503, "无法保存会话")
		return
	}
	a.DB.ExecContext(c.Request.Context(), "DELETE FROM standalone_login_attempts WHERE bucket=$1", digest("user:"+strings.ToLower(in.Username)))
	a.cookie(c, s, 43200)
	models.Send(c, 200, 0, "success", gin.H{"id": id, "username": name, "role": "admin", "permissions": []string{"*"}})
}
func (a Auth) Require() gin.HandlerFunc {
	return func(c *gin.Context) {
		token, _ := c.Cookie("tg_admin")
		if token == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 401, "message": "请先登录"})
			return
		}
		var id, name string
		err := a.DB.QueryRowContext(c.Request.Context(), `SELECT u.id,u.username FROM standalone_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>NOW() AND u.status=1 AND EXISTS(SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.name IN ('管理员','admin'))`, digest(token)).Scan(&id, &name)
		if err != nil {
			c.AbortWithStatusJSON(401, gin.H{"code": 401, "message": "登录已过期"})
			return
		}
		c.Set("userID", id)
		c.Set("username", name)
		c.Set("role", "admin")
		c.Next()
	}
}
func (a Auth) Me(c *gin.Context) {
	models.Send(c, 200, 0, "success", gin.H{"id": c.GetString("userID"), "username": c.GetString("username"), "role": "admin", "permissions": []string{"*"}})
}
func (a Auth) Logout(c *gin.Context) {
	s, _ := c.Cookie("tg_admin")
	a.DB.ExecContext(c.Request.Context(), "DELETE FROM standalone_sessions WHERE token_hash=$1", digest(s))
	a.cookie(c, "", -1)
	models.Send(c, 200, 0, "success", nil)
}

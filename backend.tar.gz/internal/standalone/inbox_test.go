package standalone

import (
	"context"
	"database/sql"
	"github.com/gin-gonic/gin"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"tg-attendance/backend/services"
)

func TestInboxDurableDedupeAndSecret(t *testing.T) {
	dsn := os.Getenv("STANDALONE_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("requires disposable test database")
	}
	t.Setenv("TELEGRAM_TOKEN_SECRET", "local-test-encryption-key-not-production-123")
	db, e := sql.Open("postgres", dsn)
	if e != nil {
		t.Fatal(e)
	}
	defer db.Close()
	tg := services.NewWorkforceTelegramService(db, services.NewWorkforceService(db))
	secret, e := tg.GetWebhookSecret(context.Background())
	if e != nil || secret == "" {
		t.Fatal("test database needs initialized secret", e)
	}
	inbox := &Inbox{DB: db, TG: tg, Wake: make(chan struct{}, 1)}
	r := gin.New()
	r.POST("/telegram/webhook", inbox.Accept)
	const id = 8888888888999
	db.Exec("DELETE FROM standalone_inbox WHERE update_id=$1", id)
	defer db.Exec("DELETE FROM standalone_inbox WHERE update_id=$1", id)
	for _, h := range []string{"wrong", secret, secret} {
		req := httptest.NewRequest("POST", "/telegram/webhook", strings.NewReader(`{"update_id":8888888888999}`))
		req.Header.Set("X-Telegram-Bot-Api-Secret-Token", h)
		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)
		want := 200
		if h == "wrong" {
			want = 403
		}
		if w.Code != want {
			t.Fatalf("status %d want %d", w.Code, want)
		}
	}
	var n int
	if e = db.QueryRow("SELECT COUNT(*) FROM standalone_inbox WHERE update_id=$1", id).Scan(&n); e != nil || n != 1 {
		t.Fatal("duplicate message persisted", n, e)
	}
}

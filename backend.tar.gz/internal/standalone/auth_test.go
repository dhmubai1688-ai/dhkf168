package standalone

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestSameOriginRejectsCrossSite(t *testing.T) {
	gin.SetMode(gin.TestMode)
	for _, tt := range []struct {
		origin, header string
		want           int
	}{{"https://evil.example", "TGAttendance", 403}, {"", "", 403}, {"https://attendance.example", "TGAttendance", 200}, {"", "TGAttendance", 200}} {
		r := gin.New()
		r.Use(SameOrigin())
		r.POST("/", func(c *gin.Context) { c.Status(200) })
		req := httptest.NewRequest(http.MethodPost, "https://attendance.example/", strings.NewReader("{}"))
		req.Header.Set("Origin", tt.origin)
		req.Header.Set("X-Requested-With", tt.header)
		w := httptest.NewRecorder()
		r.ServeHTTP(w, req)
		if w.Code != tt.want {
			t.Fatalf("origin=%q: got %d want %d", tt.origin, w.Code, tt.want)
		}
	}
}

package standalone

import (
	"github.com/gin-gonic/gin"
	"os"
	"tg-attendance/backend/internal/tgbot"
	"tg-attendance/backend/models"
)

func (i *Inbox) RegisterWebhook(c *gin.Context) {
	opts, e := i.TG.BuildTelegramBotOptions(os.Getenv("PORT"))
	if e == nil {
		e = tgbot.RegisterDurableWebhook(opts)
	}
	if e != nil {
		models.SendError(c, 400, 400, "Webhook 注册失败，请确认已保存 Token、启用 Bot、配置 HTTPS 域名及网络连接。")
		return
	}
	models.Send(c, 200, 0, "success", gin.H{"webhookUrl": opts.WebhookURL})
}

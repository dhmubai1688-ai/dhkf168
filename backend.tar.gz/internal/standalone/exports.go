package standalone

import (
	"database/sql"
	"github.com/gin-gonic/gin"
	"path/filepath"
	"tg-attendance/backend/models"
	"time"
)

func (i *Inbox) Exports(c *gin.Context) {
	rows, e := i.DB.QueryContext(c.Request.Context(), "SELECT filename,octet_length(content),created_at FROM standalone_exports ORDER BY created_at DESC LIMIT 100")
	if e != nil {
		models.SendError(c, 503, 503, "备份暂不可用")
		return
	}
	defer rows.Close()
	items := []gin.H{}
	for rows.Next() {
		var name string
		var size int
		var at time.Time
		if rows.Scan(&name, &size, &at) == nil {
			items = append(items, gin.H{"filename": name, "size": size, "createdAt": at})
		}
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items})
}
func (i *Inbox) DownloadExport(c *gin.Context) {
	name := c.Param("filename")
	if name != filepath.Base(name) {
		c.Status(400)
		return
	}
	var body []byte
	e := i.DB.QueryRowContext(c.Request.Context(), "SELECT content FROM standalone_exports WHERE filename=$1", name).Scan(&body)
	if e == sql.ErrNoRows {
		c.Status(404)
		return
	}
	if e != nil {
		c.Status(503)
		return
	}
	c.Header("Content-Disposition", `attachment; filename="attendance.xlsx"`)
	c.Data(200, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", body)
}

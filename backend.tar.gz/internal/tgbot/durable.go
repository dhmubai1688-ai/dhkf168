package tgbot

import (
	"encoding/json"
	"fmt"
	"sync/atomic"
	"time"
)

// ProcessDurableUpdate is synchronous, so the owner can persist completion after processing.
func ProcessDurableUpdate(opts Options, body []byte, received time.Time) error {
	var u tgUpdate
	if err := json.Unmarshal(body, &u); err != nil {
		return err
	}
	cfg := opts.toConfig()
	cfg.Failure = &atomic.Bool{}
	cfg.EventUnix = received.Unix()
	if u.Message != nil && u.Message.Date > 0 {
		event := time.Unix(u.Message.Date, 0)
		if event.After(received.Add(time.Minute)) || event.Before(received.Add(-24*time.Hour)) {
			return fmt.Errorf("message timestamp outside Telegram delivery window")
		}
		cfg.EventUnix = u.Message.Date
	}
	// Callback messages carry the ORIGINAL bot message time, not the button click time.
	// Use receipt time for callbacks. Telegram does not provide a callback click timestamp.
	setActiveConfig(cfg)
	refreshRuntimeConfig(&cfg, "")
	ProcessUpdate(cfg, u)
	if cfg.Failure.Load() {
		return fmt.Errorf("internal backend call failed; review before retry")
	}
	return nil
}

// RegisterDurableWebhook never discards Telegram's pending delivery queue.
func RegisterDurableWebhook(opts Options) error {
	cfg := opts.toConfig()
	if cfg.BotToken == "" || cfg.WebhookSecret == "" {
		return fmt.Errorf("请先保存 Bot Token 并生成 Webhook Secret")
	}
	if len(cfg.WebhookURL) < 8 || cfg.WebhookURL[:8] != "https://" {
		return fmt.Errorf("请配置 PUBLIC_BASE_URL 或使用 Render 的 HTTPS 域名")
	}
	return setWebhook(cfg)
}

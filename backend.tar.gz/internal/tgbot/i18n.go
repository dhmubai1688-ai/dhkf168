package tgbot

import (
	"fmt"
	"strings"
	"sync"
)

type userLangState struct {
	EmpID string
	Lang  string // zh | vi | en
}

var cachedUserLang sync.Map // telegramUserID -> userLangState

func normalizeCacheLang(lang string) string {
	switch strings.ToLower(strings.TrimSpace(lang)) {
	case "vi", "vn", "vietnamese", "越南语", "越":
		return "vi"
	case "en", "english", "英语", "英文", "英":
		return "en"
	default:
		// both / empty / unknown → zh (punch default; clears prior shift's vi)
		return "zh"
	}
}

// rememberUserLang stores bot-local prefix language for a Telegram account.
// empID tracks which employee the lang belongs to (shared-TG shift handoff).
func rememberUserLang(userID int64, empID, lang string) {
	if userID <= 0 {
		return
	}
	cachedUserLang.Store(userID, userLangState{
		EmpID: strings.TrimSpace(empID),
		Lang:  normalizeCacheLang(lang),
	})
}

// applyBackendLangCache prefers replyLang (per-employee punch lang, default zh).
// preferredLang is display/keyboard fallback only when replyLang is absent.
func applyBackendLangCache(userID int64, empID, replyLang, preferredLang string) {
	lang := strings.TrimSpace(replyLang)
	if lang == "" {
		lang = preferredLang
	}
	rememberUserLang(userID, empID, lang)
}

func clearUserLang(userID int64) {
	if userID > 0 {
		cachedUserLang.Delete(userID)
	}
}

func cachedEmpID(userID int64) string {
	if userID <= 0 {
		return ""
	}
	if v, ok := cachedUserLang.Load(userID); ok {
		if st, ok := v.(userLangState); ok {
			return st.EmpID
		}
	}
	return ""
}

func userLang(userID int64) string {
	if userID <= 0 {
		return "zh"
	}
	if v, ok := cachedUserLang.Load(userID); ok {
		if st, ok := v.(userLangState); ok {
			if st.Lang == "vi" || st.Lang == "en" || st.Lang == "zh" {
				return st.Lang
			}
		}
		// Legacy string entries from older tests / hot reload
		if s, ok := v.(string); ok && (s == "vi" || s == "en" || s == "zh") {
			return s
		}
	}
	return "zh"
}

func tUser(userID int64, zh, vi, en string) string {
	switch userLang(userID) {
	case "vi":
		return vi
	case "en":
		return en
	default:
		return zh
	}
}

func punchFailPrefix(userID int64) string {
	return tUser(userID, "打卡失败：", "Chấm công thất bại: ", "Clock-in failed: ")
}

func checkoutFailPrefix(userID int64) string {
	return tUser(userID, "签退失败：", "Tan ca thất bại: ", "Clock-out failed: ")
}

func startActivityFailPrefix(userID int64) string {
	return tUser(userID, "开始活动失败：", "Bắt đầu hoạt động thất bại: ", "Start activity failed: ")
}

func endActivityFailPrefix(userID int64) string {
	return tUser(userID, "结束活动失败：", "Kết thúc hoạt động thất bại: ", "End activity failed: ")
}

func activityNotFoundPrefix(userID int64) string {
	return tUser(userID, "未找到活动：", "Không tìm thấy hoạt động: ", "Activity not found: ")
}

func currentLangMode() string {
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if cachedLangMode == "" {
		return "both"
	}
	return cachedLangMode
}

// Built-in labels so button presses still work before /config is loaded.
var builtinButtonLookup = map[string]string{
	"上班": "checkin", "Đi làm": "checkin", "上班 / Đi làm": "checkin", "Clock in": "checkin",
	"下班": "work_end", "Tan ca": "work_end", "下班 / Tan ca": "work_end", "🔴 下班": "work_end", "Clock out": "work_end",
	"白班上班": "work_start_day", "Ca ngày Đi làm": "work_start_day", "Day in": "work_start_day",
	"中班上班": "work_start_middle", "Ca giữa Đi làm": "work_start_middle", "Mid in": "work_start_middle",
	"夜班上班": "work_start_night", "Ca đêm Đi làm": "work_start_night", "Night in": "work_start_night",
	"回座": "back", "Trở lại chỗ ngồi": "back", "✅ 回座": "back", "Back": "back",
	"我的记录": "my_record", "Lịch sử của tôi": "my_record", "我的信息": "my_record", "My log": "my_record",
	"排行榜": "rank", "Bảng xếp hạng": "rank", "排名": "rank", "Rank": "rank",
	"状态": "status", "Trạng thái": "status", "Status": "status",
	"交接班": "handover", "Giao ca": "handover", "换班": "handover", "Handover": "handover",
	"帮助": "help", "Trợ giúp": "help", "Help": "help",
	"chatid": "chatid",
	"导出数据": "export_data", "Xuất dữ liệu": "export_data", "Export": "export_data",
	"🚾 小厕": "小厕", "🚽 大厕": "大厕",
	"🚽 小厕": "小厕", "🚾 大厕": "大厕", "🍱 吃饭": "吃饭", "🚬 抽烟": "抽烟", "🚬 抽烟或休息": "抽烟或休息",
}

const deviceTagSep = " · "

func splitDeviceTag(text string) (base, deviceHint string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "", ""
	}
	idx := strings.LastIndex(text, deviceTagSep)
	if idx <= 0 {
		return text, ""
	}
	base = strings.TrimSpace(text[:idx])
	deviceHint = strings.TrimSpace(text[idx+len(deviceTagSep):])
	if base == "" || deviceHint == "" {
		return text, ""
	}
	return base, deviceHint
}

func resolveButton(text string) string {
	text = strings.TrimSpace(text)
	if text == "" {
		return ""
	}
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	if canonical, ok := cachedButtonLookup[text]; ok {
		return canonical
	}
	if canonical, ok := builtinButtonLookup[text]; ok {
		return canonical
	}
	return text
}

func resolveActivityName(text string) string {
	canonical := resolveButton(text)
	activitiesMu.RLock()
	defer activitiesMu.RUnlock()
	for _, name := range cachedActivities {
		if canonical == name {
			return name
		}
	}
	return ""
}

func isActivityInput(text string) bool {
	return resolveActivityName(text) != ""
}

func tRateLimited() string {
	switch currentLangMode() {
	case "vi":
		return "Thao tác quá nhanh, vui lòng thử lại sau."
	case "zh":
		return "操作过于频繁，请稍后再试。"
	default:
		return "操作过于频繁，请稍后再试。 / Thao tác quá nhanh, vui lòng thử lại sau."
	}
}

func helpText() string {
	activitiesMu.RLock()
	acts := strings.Join(cachedActivities, "、")
	mode := cachedLangMode
	activitiesMu.RUnlock()
	if mode == "" {
		mode = "both"
	}
	switch mode {
	case "vi":
		return fmt.Sprintf(`Bot chấm công Telegram

Ca ngày / Ca đêm (chế độ hai ca)
Đi làm: gửi nút tương ứng
Tan ca: gửi nút Tan ca
Hoạt động: gửi tên hoạt động (%s)
Trở lại: gửi nút Trở lại chỗ ngồi
Giao ca: gửi Giao ca
Trạng thái / Lịch sử / Bảng xếp hạng: dùng nút bàn phím
Ngôn ngữ phản hồi chấm công theo nhân viên: /lang_zh /lang_vi /lang_en (bàn chia sẻ: đăng nhập PC trước)`, acts)
	case "zh":
		return fmt.Sprintf(`Telegram 考勤 Bot

绑定个人 TG（无需客户端）：/bind 邀请码 或 /bind 账号
多设备共用 TG（共享工位）：/bind_multi 账号 或 /bind_multi 邀请码（同一 TG 可绑多台；点普通打卡按钮后选择设备）
单设备工位 TG：/bind_workstation 邀请码（打卡需 PC 登录）
客户端：登录后托盘「绑定 Telegram」获取链接
群内键盘按钮无反应：请在 @BotFather 对该 Bot 执行 /setprivacy → Disable
或在群内使用命令：/checkin_day /checkin_middle /checkin_night /checkout
白班 / 中班 / 夜班上班（双班或三班模式）
上班：发送对应按钮，或 /checkin_day /checkin_middle /checkin_night
下班：发送「下班」或 /checkout
活动：发送活动名称开始（%s）
结束活动：发送「回座」或 /at
交接班：发送「交接班」（双班 day↔night；三班 day→middle→night→day）
状态 / 我的记录 / 排行榜：使用键盘按钮
查询本群/频道 ID：/chatid（或 /groupid、/channelid）
打卡回复语言按员工保存：/lang_zh /lang_vi /lang_en（也可 /lang zh|vi|en；共享工位需先 PC 登录；未设置默认中文）`, acts)
	default:
		return fmt.Sprintf(`Telegram 考勤 Bot / Bot chấm công

个人 /bind 邀请码 或 /bind 账号 | 多设备 /bind_multi 账号 或 /bind_multi 邀请码 | 工位 /bind_workstation 邀请码
白班 / 中班 / 夜班 | Ca ngày / giữa / đêm
上班 / 下班 | Đi làm / Tan ca
活动 (%s) | Hoạt động
回座 / 状态 / 我的记录 / 排行榜
Trở lại / Trạng thái / Lịch sử / Bảng xếp hạng
/chatid 查询群或频道 ID
/lang_zh /lang_vi /lang_en 打卡回复语言按员工（共享工位先 PC 登录；默认 zh）`, acts)
	}
}

func tGroupWelcome(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = "本群"
	}
	mode := currentLangMode()
	if chatType == "channel" {
		switch mode {
		case "vi":
			return fmt.Sprintf("🤖 Bot đã tham gia kênh\n\n📢 %s\n🆔 ID: %d\n\nThêm ID này trong trang quản trị monitorWin.", name, chatID)
		case "zh":
			return fmt.Sprintf("🤖 机器人已加入频道\n\n📢 %s\n🆔 频道 ID：%d\n\n请在后台「Telegram 考勤 → 推送配置」绑定此 ID。", name, chatID)
		default:
			return fmt.Sprintf("🤖 机器人已加入频道 / Bot đã tham gia kênh\n\n📢 %s\n🆔 ID：%d\n\n后台绑定此 ID。", name, chatID)
		}
	}
	switch mode {
	case "vi":
		return fmt.Sprintf("🤖 Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID: %d\n\nThêm Chat ID trong trang quản trị hoặc gửi /chatid.", name, chatID)
	case "zh":
		return fmt.Sprintf("🤖 机器人已加入群组\n\n💬 %s\n🆔 群组 ID：%d\n\n请在后台「群组绑定」添加此 Chat ID；也可发送 /chatid 查看。", name, chatID)
	default:
		return fmt.Sprintf("🤖 机器人已加入群组 / Bot đã tham gia nhóm\n\n💬 %s\n🆔 ID：%d\n\n后台「群组绑定」或 /chatid", name, chatID)
	}
}

func tChatIDHint(chatType, title string, chatID int64) string {
	name := title
	if name == "" {
		name = fmt.Sprintf("%d", chatID)
	}
	mode := currentLangMode()
	switch mode {
	case "vi":
		return fmt.Sprintf("📋 %s\n🆔 Chat ID: %d", name, chatID)
	case "zh":
		return fmt.Sprintf("📋 %s\n🆔 Chat ID：%d", name, chatID)
	default:
		return fmt.Sprintf("📋 %s\n🆔 Chat ID：%d", name, chatID)
	}
}

// needsDeviceSelectionRetry detects multi-device login errors (zh/vi/en) that should
// re-offer the device picker keyboard instead of a plain error.
func needsDeviceSelectionRetry(msg string) bool {
	msg = strings.TrimSpace(msg)
	if msg == "" {
		return false
	}
	return strings.Contains(msg, "选择设备") ||
		strings.Contains(msg, "多台设备已登录") ||
		strings.Contains(msg, "chọn thiết bị") ||
		strings.Contains(msg, "Nhiều thiết bị đã đăng nhập") ||
		strings.Contains(msg, "select a device") ||
		strings.Contains(msg, "Multiple devices are signed in")
}

package tgbot

import "testing"

func TestNeedsDeviceSelectionRetryLocalized(t *testing.T) {
	msgs := []string{
		"⚠️ 多台设备已登录，请重新点击普通打卡按钮并选择设备",
		"⚠️ Nhiều thiết bị đã đăng nhập, hãy bấm lại nút chấm công và chọn thiết bị",
		"⚠️ Multiple devices are signed in — tap the punch button again and select a device",
	}
	for _, msg := range msgs {
		if !needsDeviceSelectionRetry(msg) {
			t.Fatalf("device picker must still trigger for %q", msg)
		}
	}
	if needsDeviceSelectionRetry("⚠️ 已在上班状态") {
		t.Fatal("session-exists should not open device picker")
	}
}

func TestIsUnboundAlertLocalized(t *testing.T) {
	if !isUnboundAlert("⚠️ 未绑定。个人 TG：/bind") {
		t.Fatal("zh unbound")
	}
	if !isUnboundAlert("⚠️ Chưa gắn. Cá nhân: /bind") {
		t.Fatal("vi unbound")
	}
	if !isUnboundAlert("⚠️ Not bound. Personal: /bind") {
		t.Fatal("en unbound")
	}
}

func TestPunchFailPrefixFollowsUserLang(t *testing.T) {
	const uid int64 = 424242
	rememberUserLang(uid, "emp-a", "vi")
	if got := punchFailPrefix(uid); got != "Chấm công thất bại: " {
		t.Fatalf("vi prefix = %q", got)
	}
	rememberUserLang(uid, "emp-a", "en")
	if got := startActivityFailPrefix(uid); got != "Start activity failed: " {
		t.Fatalf("en prefix = %q", got)
	}
	rememberUserLang(uid, "emp-a", "zh")
	if got := checkoutFailPrefix(uid); got != "签退失败：" {
		t.Fatalf("zh prefix = %q", got)
	}
	clearUserLang(uid)
}

func TestSharedTGHandoffClearsPriorEmployeeLang(t *testing.T) {
	const uid int64 = 525252
	// A set Vietnamese
	rememberUserLang(uid, "employee-a", "vi")
	if userLang(uid) != "vi" || cachedEmpID(uid) != "employee-a" {
		t.Fatalf("A cache: lang=%s emp=%s", userLang(uid), cachedEmpID(uid))
	}
	// B logs in with no personal pref → backend replyLang zh
	applyBackendLangCache(uid, "employee-b", "zh", "vi")
	if got := userLang(uid); got != "zh" {
		t.Fatalf("B must get default zh, not inherit A vi; got %q", got)
	}
	if cachedEmpID(uid) != "employee-b" {
		t.Fatalf("emp id should be B, got %s", cachedEmpID(uid))
	}
	clearUserLang(uid)
}

func TestApplyBackendLangCachePrefersReplyLang(t *testing.T) {
	const uid int64 = 626262
	rememberUserLang(uid, "a", "vi")
	// preferredLang=vi (group) must not win over replyLang=zh (employee default)
	applyBackendLangCache(uid, "b", "zh", "vi")
	if userLang(uid) != "zh" {
		t.Fatal("replyLang zh must override preferredLang vi")
	}
	clearUserLang(uid)
}

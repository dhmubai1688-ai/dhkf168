package tgbot

import (
	"testing"
)

func TestHandleWebhookBody_SecretMatch(t *testing.T) {
	cfg := config{WebhookSecret: "wh-secret-token"}
	if err := HandleWebhookBody(cfg, "wh-secret-token", []byte(`{"update_id":1}`)); err != nil {
		t.Fatalf("expected valid secret to pass: %v", err)
	}
}

func TestHandleWebhookBody_SecretMismatch(t *testing.T) {
	cfg := config{WebhookSecret: "wh-secret-token"}
	if err := HandleWebhookBody(cfg, "wrong", []byte(`{"update_id":1}`)); err == nil {
		t.Fatal("expected wrong secret to be rejected")
	}
}

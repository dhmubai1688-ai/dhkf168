package security

import "testing"

func TestSecureCompare(t *testing.T) {
	secret := "test-worker-secret-ok"
	if !SecureCompare(secret, secret) {
		t.Fatal("expected equal secrets to match")
	}
	if !SecureCompare("  "+secret+"  ", secret) {
		t.Fatal("expected trimmed equal secrets to match")
	}
	if SecureCompare(secret, "wrong-secret") {
		t.Fatal("expected different secrets to not match")
	}
	if SecureCompare(secret, "") {
		t.Fatal("expected empty to not match")
	}
	if SecureCompare("", secret) {
		t.Fatal("expected empty to not match")
	}
	if SecureCompare("abc", "abcd") {
		t.Fatal("expected different lengths to not match")
	}
}

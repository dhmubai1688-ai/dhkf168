// backend/handlers/admin.go
package handlers

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/xuri/excelize/v2"

	"tg-attendance/backend/middleware"
	"tg-attendance/backend/models"
	"tg-attendance/backend/services"
)

type AdminHandler struct {
	db          *sql.DB
	workforce   *services.WorkforceService
	perfPush    *services.PerformancePushService
	penaltyPush *services.PenaltyPushService
	agentNotify *services.AgentNotificationService
	mail        *services.MailService
	csTool      *services.CsToolSettingsService
}

func NewAdminHandler(
	db *sql.DB,
	workforce *services.WorkforceService,
	perfPush *services.PerformancePushService,
	penaltyPush *services.PenaltyPushService,
	agentNotify *services.AgentNotificationService,
	mail *services.MailService,
	csTool *services.CsToolSettingsService,
) *AdminHandler {
	return &AdminHandler{
		db:          db,
		workforce:   workforce,
		perfPush:    perfPush,
		penaltyPush: penaltyPush,
		agentNotify: agentNotify,
		mail:        mail,
		csTool:      csTool,
	}
}

// AccountResult 账号统计结果
type AccountResult struct {
	AccountName string
	OrderCount  int
	AvgSeconds  int
}

// ==================== 考勤管理 ====================

// employeeDeviceActivatedSQL is true when the employee has bound a device, joined a shared
// workstation, or consumed an invite (shared-station members are not 1:1 on devices.employee_uuid).
const employeeDeviceActivatedSQL = `(
	EXISTS (
		SELECT 1 FROM devices d
		WHERE d.employee_uuid = e.id AND d.status != 'rejected'
	)
	OR EXISTS (
		SELECT 1 FROM wf_shared_workstation_members m
		INNER JOIN devices d ON d.id = m.device_id
		WHERE m.employee_id = e.id AND d.status != 'rejected'
	)
	OR EXISTS (
		SELECT 1 FROM device_invite_codes ic
		WHERE ic.employee_id = e.id AND ic.used_at IS NOT NULL
	)
)`

func parseEmployeeEmploymentFilter(c *gin.Context, fallbackMonth string) (scope string, yearMonth string) {
	scope = strings.TrimSpace(c.Query("employment_scope"))
	if scope == "" {
		scope = "all"
	}
	yearMonth = strings.TrimSpace(c.Query("year_month"))
	if yearMonth == "" {
		yearMonth = fallbackMonth
	}
	if _, err := time.Parse("2006-01", yearMonth); err != nil {
		yearMonth = fallbackMonth
	}
	return scope, yearMonth
}

const systemSettingPerformanceHireCutoffDay = "performance_hire_cutoff_day"

func clampPerformanceHireCutoffDay(day int) int {
	if day < 1 {
		return 1
	}
	if day > 31 {
		return 31
	}
	return day
}

func (h *AdminHandler) getPerformanceHireCutoffDay(ctx context.Context) int {
	if h.db == nil {
		return 15
	}
	var val sql.NullString
	if err := h.db.QueryRowContext(ctx, `SELECT value FROM system_settings WHERE key = $1`, systemSettingPerformanceHireCutoffDay).Scan(&val); err != nil || !val.Valid {
		return 15
	}
	n, err := strconv.Atoi(strings.TrimSpace(val.String))
	if err != nil {
		return 15
	}
	return clampPerformanceHireCutoffDay(n)
}

func parsePerformanceHireCutoffDay(c *gin.Context, fallback int) int {
	raw := strings.TrimSpace(c.Query("performance_hire_cutoff_day"))
	if raw == "" {
		return clampPerformanceHireCutoffDay(fallback)
	}
	n, err := strconv.Atoi(raw)
	if err != nil {
		return clampPerformanceHireCutoffDay(fallback)
	}
	return clampPerformanceHireCutoffDay(n)
}

func performanceStartMonthByHireDate(hireDate time.Time, cutoffDay int) string {
	monthStart := time.Date(hireDate.Year(), hireDate.Month(), 1, 0, 0, 0, 0, time.UTC)
	if hireDate.Day() <= cutoffDay {
		return monthStart.AddDate(0, 1, 0).Format("2006-01")
	}
	return monthStart.AddDate(0, 2, 0).Format("2006-01")
}

// GetEmployees 获取员工列表
func (h *AdminHandler) GetEmployees(c *gin.Context) {
	skip, _ := strconv.Atoi(c.DefaultQuery("skip", "0"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "100"))
	search := c.Query("search")
	scope, yearMonth := parseEmployeeEmploymentFilter(c, time.Now().Format("2006-01"))
	perfEligibility := strings.EqualFold(strings.TrimSpace(c.Query("performance_eligibility")), "true")
	cutoffDay := parsePerformanceHireCutoffDay(c, h.getPerformanceHireCutoffDay(c.Request.Context()))

	where := "1=1"
	args := []interface{}{}
	argIdx := 1

	if search != "" {
		where += fmt.Sprintf(" AND name ILIKE $%d", argIdx)
		args = append(args, "%"+search+"%")
		argIdx++
	}

	switch strings.TrimSpace(c.Query("device_bound")) {
	case "true":
		where += ` AND ` + employeeDeviceActivatedSQL
	case "false":
		where += ` AND e.status = 1 AND NOT ` + employeeDeviceActivatedSQL
	}

	if scope == "month_visible" {
		where += fmt.Sprintf(` AND (
			(e.status = 1 OR e.effective_resigned_month = $%d)
			AND (e.effective_resigned_month IS NULL OR e.effective_resigned_month >= $%d)
		)`, argIdx, argIdx)
		args = append(args, yearMonth)
		argIdx++
	}
	if perfEligibility && yearMonth != "" {
		where += fmt.Sprintf(` AND (
			e.hire_date IS NULL
			OR TO_CHAR(
				DATE_TRUNC('month', e.hire_date) +
				CASE WHEN EXTRACT(DAY FROM e.hire_date)::int <= $%d THEN INTERVAL '1 month' ELSE INTERVAL '2 month' END,
				'YYYY-MM'
			) <= $%d
		)`, argIdx, argIdx+1)
		args = append(args, cutoffDay, yearMonth)
		argIdx += 2
	}

	countQuery := fmt.Sprintf(`
		SELECT COUNT(*) FROM (
			SELECT e0.*,
				COALESCE(
					NULLIF(TRIM(e0.resigned_month), ''),
					(
						SELECT MIN(ar.year_month)
						FROM attendance_records ar
						WHERE ar.employee_id = e0.id AND ar.status = 'resigned'
					)
				) AS effective_resigned_month
			FROM employees e0
		) e
		WHERE %s`, where)
	var total int
	if err := h.db.QueryRowContext(c.Request.Context(), countQuery, args...).Scan(&total); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	query := fmt.Sprintf(`
		SELECT e.id, e.employee_id, e.name, e.position, e.department, e.status, e.user_id,
			e.hire_date, e.work_location, e.created_at, e.updated_at,
			e.effective_resigned_month,
			(SELECT u.username FROM users u WHERE u.id = e.user_id) AS username,
			(SELECT ic.code FROM device_invite_codes ic
			 WHERE ic.employee_id = e.id AND ic.used_at IS NULL AND ic.revoked_at IS NULL AND ic.expires_at > NOW()
			 ORDER BY ic.created_at DESC LIMIT 1) AS active_invite,
			COALESCE(
				(SELECT d.id::text FROM devices d WHERE d.employee_uuid = e.id AND d.status != 'rejected' LIMIT 1),
				(SELECT d.id::text FROM wf_shared_workstation_members m
				 INNER JOIN devices d ON d.id = m.device_id
				 WHERE m.employee_id = e.id AND d.status != 'rejected' LIMIT 1)
			) AS device_id,
			COALESCE(
				(SELECT d.last_seen_at FROM devices d WHERE d.employee_uuid = e.id AND d.status != 'rejected' LIMIT 1),
				(SELECT d.last_seen_at FROM wf_shared_workstation_members m
				 INNER JOIN devices d ON d.id = m.device_id
				 WHERE m.employee_id = e.id AND d.status != 'rejected' LIMIT 1)
			) AS last_seen_at,
			`+employeeDeviceActivatedSQL+` AS device_activated
		FROM (
			SELECT e0.*,
				COALESCE(
					NULLIF(TRIM(e0.resigned_month), ''),
					(
						SELECT MIN(ar.year_month)
						FROM attendance_records ar
						WHERE ar.employee_id = e0.id AND ar.status = 'resigned'
					)
				) AS effective_resigned_month
			FROM employees e0
		) e
		WHERE %s
		ORDER BY e.created_at DESC
		LIMIT $%d OFFSET $%d
	`, where, argIdx, argIdx+1)
	args = append(args, limit, skip)

	rows, err := h.db.QueryContext(c.Request.Context(), query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var employees []map[string]interface{}
	for rows.Next() {
		var id string
		var employeeID, name, position, department, workLocation, resignedMonth sql.NullString
		var userID, activeInvite, deviceID, username sql.NullString
		var empStatus int
		var deviceActivated bool
		var hireDate, createdAt, updatedAt, lastSeen sql.NullTime
		if err := rows.Scan(&id, &employeeID, &name, &position, &department, &empStatus, &userID,
			&hireDate, &workLocation, &createdAt, &updatedAt, &resignedMonth, &username, &activeInvite, &deviceID, &lastSeen, &deviceActivated); err != nil {
			log.Printf("GetEmployees scan error: %v", err)
			continue
		}
		bound := deviceActivated
		onlineStatus := "offline"
		if lastSeen.Valid && time.Since(lastSeen.Time) < 3*time.Minute {
			onlineStatus = "online"
		}
		activationStatus := "pending_activation"
		if bound {
			activationStatus = "active"
		}
		if empStatus == 0 {
			activationStatus = "disabled"
		}
		createdAtVal := interface{}(nil)
		if createdAt.Valid {
			createdAtVal = createdAt.Time
		}
		emp := map[string]interface{}{
			"id":                 id,
			"employee_id":        nullStringToString(employeeID),
			"username":           nullStringToString(username),
			"name":               nullStringToString(name),
			"position":           nullStringToString(position),
			"department":         nullStringToString(department),
			"status":             empStatus,
			"user_id":            nullStringToInterface(userID),
			"hire_date":          nullTimeToString(hireDate),
			"work_location":      nullStringToString(workLocation),
			"created_at":         createdAtVal,
			"updated_at":         nullTimeToString(updatedAt),
			"resigned_month":     nullStringToString(resignedMonth),
			"device_bound":       bound,
			"online_status":      onlineStatus,
			"activation_status":  activationStatus,
			"active_invite_code": nullStringToInterface(activeInvite),
		}
		employees = append(employees, emp)
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items": employees,
		"total": total,
	})
}

// CreateEmployee 创建员工
func (h *AdminHandler) CreateEmployee(c *gin.Context) {
    var req struct {
        EmployeeID   string `json:"employee_id"`
        Name         string `json:"name"`
        Position     string `json:"position"`
        HireDate     string `json:"hire_date"`
        WorkLocation string `json:"work_location"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }

    id := uuid.New().String()
    var hireDate interface{}
    if req.HireDate != "" {
        hireDate = req.HireDate
    }

    tx, err := h.db.Begin()
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer tx.Rollback()

    // 1. 插入员工
    _, err = tx.Exec(`
        INSERT INTO employees (id, employee_id, name, position, hire_date, work_location, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW())
    `, id, req.EmployeeID, req.Name, req.Position, hireDate, req.WorkLocation)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 2. ✅ 自动初始化当前月份的绩效记录
    currentMonth := time.Now().Format("2006-01")
    _, err = tx.Exec(`
        INSERT INTO performance_records (employee_id, employee_name, position, score_records, total_score, grade, month, created_at, updated_at)
        VALUES ($1, $2, $3, '[]'::jsonb, 10, '合格', $4, NOW(), NOW())
        ON CONFLICT (employee_id, month) DO NOTHING
    `, id, req.Name, req.Position, currentMonth)
    if err != nil {
        log.Printf("初始化绩效记录失败: %v", err)
    }

    today := time.Now().Format("2006-01-02")
    yearMonth := time.Now().Format("2006-01")
    _, err = tx.Exec(`
        INSERT INTO attendance_records (employee_id, year_month, date, status, position_snapshot, created_at, updated_at)
        VALUES ($1, $2, $3, 'pending', $4, NOW(), NOW())
        ON CONFLICT (employee_id, year_month, date) DO NOTHING
    `, id, yearMonth, today, req.Position)
    if err != nil {
        log.Printf("初始化考勤记录失败: %v", err)
    }

    if err := tx.Commit(); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    Log(c, "CREATE", "EMPLOYEE",
        fmt.Sprintf("新增员工：%s（工号 %s，岗位 %s）", req.Name, req.EmployeeID, req.Position),
        id, req.Name)

    models.Send(c, 200, 0, "Employee created", gin.H{"id": id})
}

// UpdateEmployee 更新员工
func (h *AdminHandler) UpdateEmployee(c *gin.Context) {
	id := c.Param("id")
	var req struct {
		Name         string `json:"name"`
		EmployeeID   string `json:"employee_id"`
		Position     string `json:"position"`
		Department   string `json:"department"`
		HireDate     string `json:"hire_date"`
		WorkLocation string `json:"work_location"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	var hireDate interface{}
	if req.HireDate != "" {
		hireDate = req.HireDate
	}

	_, err := h.db.Exec(`
		UPDATE employees SET name=$1, employee_id=$2, position=$3, department=$4, hire_date=$5, work_location=$6, updated_at=NOW()
		WHERE id=$7
	`, req.Name, req.EmployeeID, req.Position, req.Department, hireDate, req.WorkLocation, id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if h.workforce != nil {
		if empUUID, parseErr := uuid.Parse(id); parseErr == nil {
			if syncErr := h.workforce.SyncEmployeeLoginIdentity(c.Request.Context(), empUUID, req.EmployeeID); syncErr != nil {
				models.SendError(c, 400, 1001, syncErr.Error())
				return
			}
			if syncErr := h.workforce.SyncEmployeeProfile(c.Request.Context(), empUUID, req.Name, req.Position); syncErr != nil {
				log.Printf("SyncEmployeeProfile failed for %s: %v", id, syncErr)
			}
		}
	}

	currentMonth := time.Now().Format("2006-01")
	_, _ = h.db.Exec(`
		UPDATE attendance_records SET position_snapshot = $1, updated_at = NOW()
		WHERE employee_id = $2 AND year_month = $3
	`, req.Position, id, currentMonth)

	Log(c, "UPDATE", "EMPLOYEE",
		fmt.Sprintf("修改员工：%s（工号 %s，岗位 %s）", req.Name, req.EmployeeID, req.Position),
		id, req.Name)

	models.Send(c, 200, 0, "Employee updated", nil)
}

// DeleteEmployee 删除员工及其子账号、设备绑定等关联数据
func (h *AdminHandler) DeleteEmployee(c *gin.Context) {
	id := c.Param("id")
	empUUID, err := uuid.Parse(id)
	if err != nil {
		models.SendError(c, 400, 1001, "invalid employee id")
		return
	}
	var employeeName string
	_ = h.db.QueryRow(`SELECT name FROM employees WHERE id=$1`, id).Scan(&employeeName)

	if h.workforce == nil {
		models.SendError(c, 500, 5000, "workforce service unavailable")
		return
	}
	if err := h.workforce.DeleteEmployeeCompletely(c.Request.Context(), empUUID); err != nil {
		if errors.Is(err, services.ErrEmployeeNotFound) {
			models.SendError(c, 404, 2001, "employee not found")
			return
		}
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	if employeeName != "" {
		Log(c, "DELETE", "EMPLOYEE",
			fmt.Sprintf("删除员工：%s（含子账号与绑定）", employeeName), id, employeeName)
	}

	models.Send(c, 200, 0, "Employee deleted", nil)
}

// GetAttendanceRecords 批量获取考勤记录
func (h *AdminHandler) GetAttendanceRecords(c *gin.Context) {
    yearMonth := c.Query("year_month")
    
    employeeIDs := c.QueryArray("employee_ids[]")
    if len(employeeIDs) == 0 {
        employeeIDs = c.QueryArray("employee_ids")
    }
    if len(employeeIDs) == 0 {
        if ids := c.Query("employee_ids"); ids != "" {
            employeeIDs = strings.Split(ids, ",")
        }
    }

    if yearMonth == "" || len(employeeIDs) == 0 {
        models.Send(c, 200, 0, "success", gin.H{})
        return
    }

    // ✅ 验证并过滤有效的 UUID
    validUUIDs := make([]string, 0)
    for _, id := range employeeIDs {
        if _, err := uuid.Parse(id); err == nil {
            validUUIDs = append(validUUIDs, id)
        }
    }

    if len(validUUIDs) == 0 {
        models.Send(c, 200, 0, "success", gin.H{})
        return
    }

    // ✅ 构建占位符，将字符串 UUID 转换为 UUID 类型
    placeholders := make([]string, len(validUUIDs))
    args := []interface{}{yearMonth}
    for i, id := range validUUIDs {
        placeholders[i] = fmt.Sprintf("$%d::uuid", i+2)  // ✅ 关键：::uuid 转换
        args = append(args, id)
    }

    query := fmt.Sprintf(`
        SELECT ar.employee_id, ar.date::text, ar.status, COALESCE(ar.checkin_source,''), COALESCE(ar.checkout_source,''),
               ar.checkin_time, ar.checkout_time,
               COALESCE(NULLIF(TRIM(ar.shift_type), ''), ws.shift_type, ''),
               CASE
                   WHEN ar.activity_seconds IS NOT NULL THEN ar.activity_seconds
                   ELSE COALESCE(act.total_sec, 0)
               END
        FROM attendance_records ar
        LEFT JOIN LATERAL (
            SELECT COALESCE(shift_type, '') AS shift_type
            FROM work_sessions
            WHERE employee_id = ar.employee_id AND attendance_date = ar.date
            ORDER BY checkin_time DESC
            LIMIT 1
        ) ws ON TRUE
        LEFT JOIN LATERAL (
            SELECT COALESCE(SUM(elapsed_seconds), 0)::int AS total_sec
            FROM wf_tg_activity_sessions
            WHERE employee_id = ar.employee_id AND attendance_date = ar.date AND status = 'closed'
        ) act ON TRUE
        WHERE ar.year_month = $1 AND ar.employee_id IN (%s)
    `, strings.Join(placeholders, ","))

    rows, err := h.db.Query(query, args...)
    if err != nil {
        log.Printf("SQL错误: %v, query: %s", err, query)
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer rows.Close()

    // 构建返回结果
    result := make(map[string]map[string]interface{})
    for _, id := range employeeIDs {
        result[id] = make(map[string]interface{})
    }

    for rows.Next() {
        var employeeUUID, date, status, checkinSource, checkoutSource, shiftType string
        var checkinTime, checkoutTime sql.NullTime
        var activitySeconds int
        if err := rows.Scan(&employeeUUID, &date, &status, &checkinSource, &checkoutSource, &checkinTime, &checkoutTime, &shiftType, &activitySeconds); err != nil {
            continue
        }
        // 匹配原始输入的 ID
        for _, inputID := range employeeIDs {
            if inputID == employeeUUID {
                if result[inputID] == nil {
                    result[inputID] = make(map[string]interface{})
                }
                record := map[string]interface{}{
                    "status":          status,
                    "checkinSource":   checkinSource,
                    "checkoutSource":  checkoutSource,
                    "activitySeconds": activitySeconds,
                }
                if checkinTime.Valid {
                    record["checkinTime"] = checkinTime.Time.UTC().Format(time.RFC3339)
                }
                if checkoutTime.Valid {
                    record["checkoutTime"] = checkoutTime.Time.UTC().Format(time.RFC3339)
                }
                if strings.TrimSpace(shiftType) != "" {
                    record["shiftType"] = strings.TrimSpace(shiftType)
                }
                result[inputID][date] = record
                break
            }
        }
    }

    h.attachAttendanceLateEarlyFlags(result, yearMonth, validUUIDs)

    models.Send(c, 200, 0, "success", result)
}

var (
	attendanceLateMinutesRe  = regexp.MustCompile(`迟到\s*(\d+)\s*分钟`)
	attendanceEarlyMinutesRe = regexp.MustCompile(`早退\s*(\d+)\s*分钟`)
)

// attachAttendanceLateEarlyFlags merges late/early minutes from penalty_records into daily attendance rows.
func (h *AdminHandler) attachAttendanceLateEarlyFlags(
	result map[string]map[string]interface{},
	yearMonth string,
	employeeIDs []string,
) {
	if h.db == nil || len(result) == 0 || len(employeeIDs) == 0 || strings.TrimSpace(yearMonth) == "" {
		return
	}
	ym, err := time.Parse("2006-01", yearMonth)
	if err != nil {
		return
	}
	dateFrom := ym.Format("2006-01-02")
	dateTo := ym.AddDate(0, 1, -1).Format("2006-01-02")

	placeholders := make([]string, len(employeeIDs))
	args := []interface{}{dateFrom, dateTo}
	for i, id := range employeeIDs {
		placeholders[i] = fmt.Sprintf("$%d::uuid", i+3)
		args = append(args, id)
	}

	query := fmt.Sprintf(`
		SELECT employee_id::text, penalty_date::text, COALESCE(category,''), COALESCE(reason,'')
		FROM penalty_records
		WHERE penalty_date BETWEEN $1::date AND $2::date
		  AND employee_id IN (%s)
		  AND (
			category IN ('迟到', '早退', 'TG考勤')
			OR reason LIKE '%%迟到%%'
			OR reason LIKE '%%早退%%'
		  )`, strings.Join(placeholders, ","))

	rows, err := h.db.Query(query, args...)
	if err != nil {
		log.Printf("[Attendance] late/early flags query failed: %v", err)
		return
	}
	defer rows.Close()

	type dayFlags struct {
		lateMin  int
		earlyMin int
		lateHit  bool
		earlyHit bool
	}
	flags := make(map[string]*dayFlags) // empID|date

	for rows.Next() {
		var empID, penaltyDate, category, reason string
		if rows.Scan(&empID, &penaltyDate, &category, &reason) != nil {
			continue
		}
		if i := strings.IndexByte(penaltyDate, 'T'); i > 0 {
			penaltyDate = penaltyDate[:i]
		}
		key := empID + "|" + penaltyDate
		f := flags[key]
		if f == nil {
			f = &dayFlags{}
			flags[key] = f
		}
		cat := strings.TrimSpace(category)
		reason = strings.TrimSpace(reason)
		isLate := cat == "迟到" || strings.Contains(reason, "迟到")
		isEarly := cat == "早退" || strings.Contains(reason, "早退")
		if isLate {
			f.lateHit = true
			if m := attendanceLateMinutesRe.FindStringSubmatch(reason); len(m) == 2 {
				if n, err := strconv.Atoi(m[1]); err == nil && n > f.lateMin {
					f.lateMin = n
				}
			}
		}
		if isEarly {
			f.earlyHit = true
			if m := attendanceEarlyMinutesRe.FindStringSubmatch(reason); len(m) == 2 {
				if n, err := strconv.Atoi(m[1]); err == nil && n > f.earlyMin {
					f.earlyMin = n
				}
			}
		}
	}

	for empID, days := range result {
		for date, raw := range days {
			rec, ok := raw.(map[string]interface{})
			if !ok || rec == nil {
				continue
			}
			f := flags[empID+"|"+date]
			if f == nil {
				continue
			}
			if f.lateHit || f.lateMin > 0 {
				if f.lateMin > 0 {
					rec["lateMinutes"] = f.lateMin
					rec["lateLabel"] = fmt.Sprintf("迟到%d分钟", f.lateMin)
				} else {
					rec["lateLabel"] = "迟到"
				}
			}
			if f.earlyHit || f.earlyMin > 0 {
				if f.earlyMin > 0 {
					rec["earlyMinutes"] = f.earlyMin
					rec["earlyLabel"] = fmt.Sprintf("早退%d分钟", f.earlyMin)
				} else {
					rec["earlyLabel"] = "早退"
				}
			}
		}
	}
}

// SaveAttendanceRecords 保存考勤记录
func (h *AdminHandler) SaveAttendanceRecords(c *gin.Context) {
    var req struct {
        YearMonth         string                 `json:"year_month"`
        Data              map[string]interface{} `json:"data"`
        Clears            map[string]interface{} `json:"clears"`
        RestoreEmployees  []string               `json:"restoreEmployees"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }

    tx, err := h.db.Begin()
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer tx.Rollback()

    for empID, records := range req.Data {
        var exists bool
        err := tx.QueryRow(`
            SELECT EXISTS(SELECT 1 FROM employees WHERE id = $1)
        `, empID).Scan(&exists)
        if err != nil || !exists {
            // 如果不是有效的 UUID，尝试通过 employee_id 查找
            var realUUID string
            err = tx.QueryRow(`
                SELECT id FROM employees WHERE employee_id = $1
            `, empID).Scan(&realUUID)
            if err != nil {
                // 如果还是找不到，跳过这条记录
                continue
            }
            empID = realUUID // 使用找到的 UUID
        }

        recordsMap, ok := records.(map[string]interface{})
        if !ok {
            continue
        }
        for date, record := range recordsMap {
            recordMap, ok := record.(map[string]interface{})
            if !ok {
                continue
            }
            status, _ := recordMap["status"].(string)
            if status == "" {
                continue
            }
            _, err = tx.Exec(`
                INSERT INTO attendance_records (employee_id, year_month, date, status, manually_edited, updated_at)
                VALUES ($1, $2, $3, $4, TRUE, NOW())
                ON CONFLICT (employee_id, year_month, date) DO UPDATE SET
                    status = $4,
                    manually_edited = TRUE,
                    updated_at = NOW()
            `, empID, req.YearMonth, date, status)
            if err != nil {
                models.SendError(c, 500, 5000, err.Error())
                return
            }
        }
    }

    for empID, datesRaw := range req.Clears {
        resolvedEmpID := empID
        var exists bool
        if err := tx.QueryRow(`SELECT EXISTS(SELECT 1 FROM employees WHERE id = $1)`, empID).Scan(&exists); err != nil || !exists {
            var realUUID string
            if err = tx.QueryRow(`SELECT id FROM employees WHERE employee_id = $1`, empID).Scan(&realUUID); err != nil {
                continue
            }
            resolvedEmpID = realUUID
        }
        dateList, ok := datesRaw.([]interface{})
        if !ok {
            continue
        }
        for _, d := range dateList {
            dateStr, _ := d.(string)
            dateStr = strings.TrimSpace(dateStr)
            if dateStr == "" {
                continue
            }
            if _, err = tx.Exec(`
                DELETE FROM attendance_records
                WHERE employee_id = $1 AND year_month = $2 AND date = $3::date`,
                resolvedEmpID, req.YearMonth, dateStr); err != nil {
                models.SendError(c, 500, 5000, err.Error())
                return
            }
        }
    }

    if err := tx.Commit(); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    if h.workforce != nil {
        for _, empID := range req.RestoreEmployees {
            empID = strings.TrimSpace(empID)
            if empID == "" {
                continue
            }
            if uid, err := uuid.Parse(empID); err == nil {
                _ = h.workforce.ReactivateEmployee(c.Request.Context(), uid)
            }
        }
    }

    // ✅ 记录操作日志
	Log(c, "UPDATE", "ATTENDANCE",
		fmt.Sprintf("保存 %s 月考勤记录", req.YearMonth), "", req.YearMonth)

    models.Send(c, 200, 0, "Attendance saved", nil)
}

// ==================== 绩效管理 ====================

func (h *AdminHandler) GetPerformanceRuleSettings(c *gin.Context) {
	cutoff := h.getPerformanceHireCutoffDay(c.Request.Context())
	models.Send(c, 200, 0, "success", gin.H{
		"hireCutoffDay": cutoff,
	})
}

func (h *AdminHandler) SavePerformanceRuleSettings(c *gin.Context) {
	var req struct {
		HireCutoffDay int `json:"hireCutoffDay"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	day := clampPerformanceHireCutoffDay(req.HireCutoffDay)
	if _, err := h.db.ExecContext(c.Request.Context(), `
		INSERT INTO system_settings (key, value, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
		systemSettingPerformanceHireCutoffDay, strconv.Itoa(day)); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "PERFORMANCE", fmt.Sprintf("更新绩效起算规则：入职截止日=%d", day), "", strconv.Itoa(day))
	models.Send(c, 200, 0, "saved", gin.H{
		"hireCutoffDay": day,
	})
}

// GetPerformance 获取绩效数据
func (h *AdminHandler) GetPerformance(c *gin.Context) {
	month := c.Query("month")
	employeeID := c.Query("employee_id")
	scope, scopeMonth := parseEmployeeEmploymentFilter(c, time.Now().Format("2006-01"))
	cutoffDay := parsePerformanceHireCutoffDay(c, h.getPerformanceHireCutoffDay(c.Request.Context()))
	if month == "" {
		month = scopeMonth
	}

	var where string
	var args []interface{}
	argIdx := 1

	if month != "" {
		where += fmt.Sprintf(" AND month = $%d", argIdx)
		args = append(args, month)
		argIdx++
	}
	if employeeID != "" {
		where += fmt.Sprintf(" AND employee_id = $%d", argIdx)
		args = append(args, employeeID)
		argIdx++
	}
	if scope == "month_visible" && employeeID == "" {
		where += fmt.Sprintf(` AND (
			(e.status = 1 OR e.effective_resigned_month = $%d)
			AND (e.effective_resigned_month IS NULL OR e.effective_resigned_month >= $%d)
		)`, argIdx, argIdx)
		args = append(args, month)
		argIdx++
	}
	if month != "" && employeeID == "" {
		where += fmt.Sprintf(` AND (
			e.hire_date IS NULL
			OR TO_CHAR(
				DATE_TRUNC('month', e.hire_date) +
				CASE WHEN EXTRACT(DAY FROM e.hire_date)::int <= $%d THEN INTERVAL '1 month' ELSE INTERVAL '2 month' END,
				'YYYY-MM'
			) <= $%d
		)`, argIdx, argIdx+1)
		args = append(args, cutoffDay, month)
		argIdx += 2
	}

	query := fmt.Sprintf(`
		SELECT pr.employee_id, pr.employee_name, pr.position, pr.score_records, pr.total_score, pr.grade, pr.month
		FROM performance_records pr
		LEFT JOIN (
			SELECT e0.id, e0.status, e0.hire_date,
				COALESCE(
					NULLIF(TRIM(e0.resigned_month), ''),
					(
						SELECT MIN(ar.year_month)
						FROM attendance_records ar
						WHERE ar.employee_id = e0.id AND ar.status = 'resigned'
					)
				) AS effective_resigned_month
			FROM employees e0
		) e ON e.id = pr.employee_id
		WHERE 1=1 %s
	`, where)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var items []map[string]interface{}
	for rows.Next() {
		var employeeID, employeeName, position, month string
		var scoreRecordsJSON string
		var totalScore int
		var grade string
		if err := rows.Scan(&employeeID, &employeeName, &position, &scoreRecordsJSON, &totalScore, &grade, &month); err != nil {
			continue
		}
		var scoreRecords []interface{}
		json.Unmarshal([]byte(scoreRecordsJSON), &scoreRecords)
		items = append(items, map[string]interface{}{
			"employee_id":   employeeID,
			"employee_name": employeeName,
			"position":      position,
			"score_records": scoreRecords,
			"total_score":   totalScore,
			"grade":         grade,
			"month":         month,
		})
	}

	models.Send(c, 200, 0, "success", gin.H{"items": items})
}

// BatchSavePerformance 批量保存绩效
func (h *AdminHandler) BatchSavePerformance(c *gin.Context) {
	var req struct {
		Month string                   `json:"month"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	tx, err := h.db.Begin()
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer tx.Rollback()
	cutoffDay := h.getPerformanceHireCutoffDay(c.Request.Context())

	for _, item := range req.Items {
		employeeID, _ := item["employee_id"].(string)
		employeeName, _ := item["employee_name"].(string)
		position, _ := item["position"].(string)
		totalScore, _ := item["total_score"].(float64)
		grade, _ := item["grade"].(string)
		scoreRecords, _ := json.Marshal(item["score_records"])

		var hireDate sql.NullTime
		_ = tx.QueryRowContext(c.Request.Context(), `
			SELECT hire_date FROM employees WHERE id = $1`, employeeID).Scan(&hireDate)
		if hireDate.Valid && strings.TrimSpace(req.Month) != "" {
			startMonth := performanceStartMonthByHireDate(hireDate.Time, cutoffDay)
			if req.Month < startMonth {
				models.SendError(c, 400, 1001, fmt.Sprintf("员工 %s 绩效起算月为 %s，当前月份不可保存", employeeName, startMonth))
				return
			}
		}

		_, err = tx.Exec(`
			INSERT INTO performance_records (employee_id, employee_name, position, score_records, total_score, grade, month, updated_at)
			VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
			ON CONFLICT (employee_id, month) DO UPDATE SET
				employee_name=$2, position=$3, score_records=$4, total_score=$5, grade=$6, updated_at=NOW()
		`, employeeID, employeeName, position, string(scoreRecords), int(totalScore), grade, req.Month)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
	}

	if err := tx.Commit(); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	Log(c, "UPDATE", "PERFORMANCE",
		fmt.Sprintf("批量保存 %s 月绩效考核（共 %d 人）", req.Month, len(req.Items)),
		"", req.Month)

	models.Send(c, 200, 0, "Performance saved", nil)
}

// ==================== 罚款管理 ====================

// GetPenaltyRecords 获取罚款记录
func (h *AdminHandler) GetPenaltyRecords(c *gin.Context) {
	month := c.Query("month")
	employeeID := c.Query("employee_id")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "20"))

	offset := (page - 1) * pageSize
	where := "1=1"
	args := []interface{}{}
	argIdx := 1

	if month != "" {
		where += fmt.Sprintf(" AND DATE_TRUNC('month', penalty_date) = DATE_TRUNC('month', $%d::date)", argIdx)
		args = append(args, month+"-01")
		argIdx++
	}
	if employeeID != "" {
		where += fmt.Sprintf(" AND employee_id = $%d", argIdx)
		args = append(args, employeeID)
		argIdx++
	}

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM penalty_records WHERE %s", where)
	var total int
	h.db.QueryRow(countQuery, args...).Scan(&total)

	query := fmt.Sprintf(`
		SELECT pr.id, pr.employee_id, pr.employee_name, pr.position, pr.amount, pr.category, pr.reason, pr.penalty_date,
			pr.created_by,
			COALESCE(NULLIF(TRIM(u.real_name), ''), pr.created_by) AS created_by_name,
			pr.created_at
		FROM penalty_records pr
		LEFT JOIN users u ON u.username = pr.created_by
		WHERE %s
		ORDER BY pr.penalty_date DESC
		LIMIT $%d OFFSET $%d
	`, where, argIdx, argIdx+1)
	args = append(args, pageSize, offset)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var items []map[string]interface{}
	for rows.Next() {
		var id, employeeID, employeeName, position, category, reason, createdBy, createdByName string
		var amount float64
		var penaltyDate, createdAt time.Time
		rows.Scan(&id, &employeeID, &employeeName, &position, &amount, &category, &reason, &penaltyDate, &createdBy, &createdByName, &createdAt)
		items = append(items, map[string]interface{}{
			"id":              id,
			"employee_id":     employeeID,
			"employee_name":   employeeName,
			"position":        position,
			"amount":          amount,
			"category":        category,
			"reason":          reason,
			"penalty_date":    penaltyDate.Format("2006-01-02"),
			"created_by":      createdBy,
			"created_by_name": createdByName,
		})
	}

	// 统计汇总
	var totalAmount float64
	var employeeCount int
	h.db.QueryRow(fmt.Sprintf(`
		SELECT COALESCE(SUM(amount), 0), COUNT(DISTINCT employee_id)
		FROM penalty_records WHERE %s
	`, where), args[:len(args)-2]...).Scan(&totalAmount, &employeeCount)

	models.Send(c, 200, 0, "success", gin.H{
		"items": items,
		"total": total,
		"stats": gin.H{
			"total_amount":   totalAmount,
			"employee_count": employeeCount,
			"record_count":   total,
			"avg_amount": func() float64 {
				if employeeCount > 0 {
					return totalAmount / float64(employeeCount)
				}
				return 0
			}(),
		},
	})
}

// CreatePenaltyRecord 创建罚款记录
func (h *AdminHandler) CreatePenaltyRecord(c *gin.Context) {
	var req struct {
		EmployeeID  string  `json:"employee_id"`
		PenaltyDate string  `json:"penalty_date"`
		Amount      float64 `json:"amount"`
		Category    string  `json:"category"`
		Reason      string  `json:"reason"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	username := c.GetString("username")
	id := uuid.New().String()

	_, err := h.db.Exec(`
		INSERT INTO penalty_records (id, employee_id, employee_name, position, amount, category, reason, penalty_date, created_by, created_at)
		SELECT $1, $2, e.name, e.position, $3, $4, $5, $6, $7, NOW()
		FROM employees e WHERE e.id = $2
	`, id, req.EmployeeID, req.Amount, req.Category, req.Reason, req.PenaltyDate, username)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	var employeeName string
	h.db.QueryRow(`SELECT name FROM employees WHERE id = $1`, req.EmployeeID).Scan(&employeeName)
	Log(c, "CREATE", "PENALTY",
		fmt.Sprintf("添加罚款：员工 %s，金额 ¥%.2f，类型 %s", employeeName, req.Amount, req.Category),
		id, employeeName)

	models.Send(c, 200, 0, "Penalty record created", nil)
}

// DeletePenaltyRecord 删除罚款记录
func (h *AdminHandler) DeletePenaltyRecord(c *gin.Context) {
	id := c.Param("id")
    
    // ✅ 获取删除的记录信息用于日志
    var employeeName string
    var amount float64
    h.db.QueryRow(`SELECT employee_name, amount FROM penalty_records WHERE id = $1`, id).Scan(&employeeName, &amount)
    
	_, err := h.db.Exec("DELETE FROM penalty_records WHERE id=$1", id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
    
    // ✅ 修复: 使用全局 Log 函数
    Log(c, "DELETE", "PENALTY",
        fmt.Sprintf("删除罚款：员工 %s，金额 ¥%.2f", employeeName, amount),
        id, employeeName)
        
	models.Send(c, 200, 0, "Penalty record deleted", nil)
}

// ==================== 出款站点管理 ====================
// GetSites 获取站点列表
func (h *AdminHandler) GetSites(c *gin.Context) {
    isActive := c.Query("is_active")
    where := "1=1"
    args := []interface{}{}
    if isActive != "" {
        where += " AND is_active = $1"
        args = append(args, isActive == "true")
    }
    
    query := fmt.Sprintf(`
        SELECT id, code, name, sort_order, is_active, created_at, updated_at,
            COALESCE((SELECT COUNT(*) FROM employee_accounts WHERE site_id = sites.id), 0) as account_count,
            COALESCE((SELECT COUNT(*) FROM site_stats WHERE site_id = sites.id), 0) as data_count
        FROM sites WHERE %s ORDER BY sort_order ASC
    `, where)
    
    rows, err := h.db.Query(query, args...)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer rows.Close()

    var items []map[string]interface{}
    for rows.Next() {
        var id, code, name string
        var sortOrder int
        var isActive bool
        var createdAt, updatedAt sql.NullTime  // ✅ 使用 sql.NullTime
        var accountCount, dataCount int
        
        err := rows.Scan(&id, &code, &name, &sortOrder, &isActive, &createdAt, &updatedAt, &accountCount, &dataCount)
        if err != nil {
            log.Printf("Scan error in GetSites: %v", err)
            continue
        }
        
        log.Printf("Site: id=%s, code=%s, name=%s, accountCount=%d, isActive=%v", 
            id, code, name, accountCount, isActive)
        
        items = append(items, map[string]interface{}{
            "id":            id,
            "code":          code,
            "name":          name,
            "sort_order":    sortOrder,
            "is_active":     isActive,
            "account_count": accountCount,
            "data_count":    dataCount,
        })
    }
    
    models.Send(c, 200, 0, "success", gin.H{"items": items})
}

// CreateSite 创建站点
func (h *AdminHandler) CreateSite(c *gin.Context) {
	var req struct {
		Code      string `json:"code"`
		Name      string `json:"name"`
		SortOrder int    `json:"sort_order"`
		IsActive  bool   `json:"is_active"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	id := uuid.New().String()
	_, err := h.db.Exec(`INSERT INTO sites (id, code, name, sort_order, is_active, created_at) VALUES ($1, $2, $3, $4, $5, NOW())`,
		id, req.Code, req.Name, req.SortOrder, req.IsActive)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "SITE_STATS",
		fmt.Sprintf("新增出款站点：%s（编码 %s）", req.Name, req.Code), id, req.Name)
	models.Send(c, 200, 0, "Site created", nil)
}

// UpdateSite 更新站点
func (h *AdminHandler) UpdateSite(c *gin.Context) {
	id := c.Param("id")
	var req struct {
		Name      string `json:"name"`
		SortOrder int    `json:"sort_order"`
		IsActive  bool   `json:"is_active"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	var siteCode string
	_ = h.db.QueryRow(`SELECT code FROM sites WHERE id=$1`, id).Scan(&siteCode)

	_, err := h.db.Exec(`UPDATE sites SET name=$1, sort_order=$2, is_active=$3, updated_at=NOW() WHERE id=$4`,
		req.Name, req.SortOrder, req.IsActive, id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "SITE_STATS",
		fmt.Sprintf("修改出款站点：%s（编码 %s）", req.Name, siteCode), id, req.Name)
	models.Send(c, 200, 0, "Site updated", nil)
}

// DeleteSite 删除站点
func (h *AdminHandler) DeleteSite(c *gin.Context) {
	id := c.Param("id")
	var siteName, siteCode string
	_ = h.db.QueryRow(`SELECT name, code FROM sites WHERE id=$1`, id).Scan(&siteName, &siteCode)

	_, err := h.db.Exec("DELETE FROM sites WHERE id=$1", id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if siteName != "" {
		Log(c, "DELETE", "SITE_STATS",
			fmt.Sprintf("删除出款站点：%s（编码 %s）", siteName, siteCode), id, siteName)
	}
	models.Send(c, 200, 0, "Site deleted", nil)
}

// GetEmployeeAccounts 获取员工账号列表
func (h *AdminHandler) GetEmployeeAccounts(c *gin.Context) {
	siteID := c.Query("site_id")
	accountName := c.Query("account_name")
	name := strings.TrimSpace(c.Query("name"))
	shift := c.Query("shift")
	skip, _ := strconv.Atoi(c.DefaultQuery("skip", "0"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	where := "1=1"
	args := []interface{}{}
	argIdx := 1
	if siteID != "" {
		where += fmt.Sprintf(" AND ea.site_id = $%d", argIdx)
		args = append(args, siteID)
		argIdx++
	}
	if accountName != "" {
		where += fmt.Sprintf(" AND ea.account_name ILIKE $%d", argIdx)
		args = append(args, "%"+accountName+"%")
		argIdx++
	}
	if name != "" {
		where += fmt.Sprintf(" AND ea.name ILIKE $%d", argIdx)
		args = append(args, "%"+name+"%")
		argIdx++
	}
	if shift != "" {
		where += fmt.Sprintf(" AND ea.shift = $%d", argIdx)
		args = append(args, shift)
		argIdx++
	}

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM employee_accounts ea WHERE %s", where)
	var total int
	h.db.QueryRow(countQuery, args...).Scan(&total)

	query := fmt.Sprintf(`
		SELECT ea.id, ea.site_id, s.code as site_code, ea.name, ea.account_name, ea.shift, ea.is_active, ea.created_at,
			(SELECT COUNT(*) FROM site_stats WHERE employee_account_id = ea.id) as data_count
		FROM employee_accounts ea
		LEFT JOIN sites s ON ea.site_id = s.id
		WHERE %s
		ORDER BY ea.created_at DESC
		LIMIT $%d OFFSET $%d
	`, where, argIdx, argIdx+1)
	args = append(args, limit, skip)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var items []map[string]interface{}
	for rows.Next() {
		var id, siteID, siteCode, name, accountName, shift string
		var isActive bool
		var createdAt time.Time
		var dataCount int
		rows.Scan(&id, &siteID, &siteCode, &name, &accountName, &shift, &isActive, &createdAt, &dataCount)
		items = append(items, map[string]interface{}{
			"id":           id,
			"site_id":      siteID,
			"site_code":    siteCode,
			"name":         name,
			"account_name": accountName,
			"shift":        shift,
			"is_active":    isActive,
			"data_count":   dataCount,
		})
	}
	models.Send(c, 200, 0, "success", gin.H{"items": items, "total": total})
}

// CreateEmployeeAccount 创建出款站点员工账号
func (h *AdminHandler) CreateEmployeeAccount(c *gin.Context) {
	var req struct {
		SiteID      string `json:"site_id" binding:"required"`
		Name        string `json:"name" binding:"required"`
		AccountName string `json:"account_name" binding:"required"`
		Shift       string `json:"shift" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	siteID, err := uuid.Parse(strings.TrimSpace(req.SiteID))
	if err != nil {
		models.SendError(c, 400, 1001, "invalid site_id")
		return
	}
	id := uuid.New()
	_, err = h.db.Exec(`
		INSERT INTO employee_accounts (id, site_id, name, account_name, shift, is_active, created_at)
		VALUES ($1, $2, $3, $4, $5, true, NOW())
	`, id, siteID, req.Name, req.AccountName, req.Shift)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "CREATE", "SITE_STATS",
		fmt.Sprintf("新增出款员工账号：%s（账号 %s，%s班）", req.Name, req.AccountName, req.Shift),
		id.String(), req.Name)
	models.Send(c, 200, 0, "Employee account created", nil)
}

// UpdateEmployeeAccount 更新员工账号
func (h *AdminHandler) UpdateEmployeeAccount(c *gin.Context) {
	id := c.Param("id")
	var req struct {
		Name        string `json:"name"`
		AccountName string `json:"account_name"`
		Shift       string `json:"shift"`
		IsActive    bool   `json:"is_active"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	_, err := h.db.Exec(`
		UPDATE employee_accounts SET name=$1, account_name=$2, shift=$3, is_active=$4, updated_at=NOW()
		WHERE id=$5
	`, req.Name, req.AccountName, req.Shift, req.IsActive, id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	Log(c, "UPDATE", "SITE_STATS",
		fmt.Sprintf("修改出款员工账号：%s（账号 %s，%s班）", req.Name, req.AccountName, req.Shift),
		id, req.Name)
	models.Send(c, 200, 0, "Employee account updated", nil)
}

const maxEmployeeAccountBatchShift = 200

// BatchUpdateEmployeeAccountShift 批量修改出款员工账号班次
func (h *AdminHandler) BatchUpdateEmployeeAccountShift(c *gin.Context) {
	var req struct {
		IDs   []string `json:"ids"`
		Name  string   `json:"name"`
		Shift string   `json:"shift" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}

	shift := strings.TrimSpace(req.Shift)
	if shift != "day" && shift != "night" {
		models.SendError(c, 400, 1001, "shift 无效，仅支持 day / night")
		return
	}

	var ids []uuid.UUID
	if len(req.IDs) > 0 {
		if len(req.IDs) > maxEmployeeAccountBatchShift {
			models.SendError(c, 400, 1001, fmt.Sprintf("单次最多修改 %d 个账号", maxEmployeeAccountBatchShift))
			return
		}
		seen := make(map[string]struct{}, len(req.IDs))
		for _, raw := range req.IDs {
			id, err := uuid.Parse(strings.TrimSpace(raw))
			if err != nil {
				models.SendError(c, 400, 1001, "无效的账号 ID")
				return
			}
			key := id.String()
			if _, ok := seen[key]; ok {
				continue
			}
			seen[key] = struct{}{}
			ids = append(ids, id)
		}
	} else {
		name := strings.TrimSpace(req.Name)
		if name == "" {
			models.SendError(c, 400, 1001, "请勾选要修改的账号，或输入员工姓名")
			return
		}
		rows, err := h.db.Query(`
			SELECT id FROM employee_accounts
			WHERE name ILIKE $1
			ORDER BY created_at DESC
			LIMIT $2
		`, "%"+name+"%", maxEmployeeAccountBatchShift+1)
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		defer rows.Close()
		for rows.Next() {
			var id uuid.UUID
			if err := rows.Scan(&id); err != nil {
				models.SendError(c, 500, 5000, err.Error())
				return
			}
			ids = append(ids, id)
		}
		if len(ids) > maxEmployeeAccountBatchShift {
			models.SendError(c, 400, 1001, "匹配账号过多，请缩小姓名或改为勾选后修改")
			return
		}
		if len(ids) == 0 {
			models.SendError(c, 404, 2001, "未找到匹配的员工账号")
			return
		}
	}

	if len(ids) == 0 {
		models.SendError(c, 400, 1001, "没有可修改的账号")
		return
	}

	placeholders := make([]string, len(ids))
	args := make([]interface{}, 0, len(ids)+1)
	args = append(args, shift)
	for i, id := range ids {
		placeholders[i] = fmt.Sprintf("$%d", i+2)
		args = append(args, id)
	}
	query := fmt.Sprintf(
		`UPDATE employee_accounts SET shift=$1, updated_at=NOW() WHERE id IN (%s)`,
		strings.Join(placeholders, ","),
	)
	result, err := h.db.Exec(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	updated, _ := result.RowsAffected()

	shiftLabel := "A班"
	if shift == "night" {
		shiftLabel = "B班"
	}
	Log(c, "UPDATE", "SITE_STATS",
		fmt.Sprintf("批量修改出款员工班次：%d 个账号 → %s", updated, shiftLabel),
		"", "")
	models.Send(c, 200, 0, "班次已更新", gin.H{
		"updated": updated,
		"total":   len(ids),
		"shift":   shift,
	})
}

// DeleteEmployeeAccount 删除员工账号
func (h *AdminHandler) DeleteEmployeeAccount(c *gin.Context) {
	id := c.Param("id")
	var accountName, displayName string
	_ = h.db.QueryRow(`SELECT account_name, COALESCE(NULLIF(name, ''), account_name) FROM employee_accounts WHERE id=$1`, id).
		Scan(&accountName, &displayName)

	_, err := h.db.Exec("DELETE FROM employee_accounts WHERE id=$1", id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	if displayName != "" {
		Log(c, "DELETE", "SITE_STATS",
			fmt.Sprintf("删除出款员工账号：%s（账号 %s）", displayName, accountName), id, displayName)
	}
	models.Send(c, 200, 0, "Employee account deleted", nil)
}

// ==================== 出款统计 ====================

// PreviewSiteStatsUpload 预览上传文件表头，供前端手动选择列映射
func (h *AdminHandler) PreviewSiteStatsUpload(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		models.SendError(c, 400, 1001, "请选择文件")
		return
	}

	mode := c.PostForm("mode")
	if mode == "" {
		mode = "BX"
	}

	rows, err := readSiteStatsRowsFromFileHeader(file)
	if err != nil {
		models.SendError(c, 400, 1001, err.Error())
		return
	}
	if len(rows) < 1 {
		models.SendError(c, 400, 1001, "文件无表头数据")
		return
	}

	rows = padSiteStatsRows(rows)
	header := rows[0]
	cols := resolveSiteStatsColumns(header, mode)

	models.Send(c, 200, 0, "success", gin.H{
		"columns":        buildSiteStatsColumnOptions(header),
		"total_columns":  len(header),
		"suggested": gin.H{
			"account_col": cols.AccountCol + 1,
			"start_col":   cols.StartCol + 1,
			"end_col":     cols.EndCol + 1,
			"source":      cols.Source,
		},
	})
}

func (h *AdminHandler) UploadSiteStats(c *gin.Context) {
    file, err := c.FormFile("file")
    if err != nil {
        models.SendError(c, 400, 1001, "请选择文件")
        return
    }
    siteID := c.PostForm("site_id")
    shift := c.PostForm("shift")
    statDate := c.PostForm("date")
    mode := c.PostForm("mode")
    if mode == "" {
        mode = "BX"
    }

    columnOverride, err := parseSiteStatsColumnOverrideFromForm(c)
    if err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }

    rows, err := readSiteStatsRowsFromFileHeader(file)
    if err != nil {
        log.Printf("文件解析失败: %v", err)
        models.SendError(c, 400, 1001, err.Error())
        return
    }
    log.Printf("文件解析成功，共 %d 行", len(rows))

    if len(rows) < 2 {
        models.SendError(c, 400, 1001, "文件无数据，请确保有表头和数据行")
        return
    }

    rows = padSiteStatsRows(rows)
    cols := resolveSiteStatsColumnMapping(rows[0], mode, columnOverride)
    accountNameCol := cols.AccountCol
    startTimeCol := cols.StartCol
    endTimeCol := cols.EndCol

    // 检查列数是否足够
    maxColNeeded := accountNameCol + 1
    if len(rows[0]) < maxColNeeded {
        models.SendError(c, 400, 1001, fmt.Sprintf("文件列数不足，需要至少 %d 列，实际 %d 列", maxColNeeded, len(rows[0])))
        return
    }

    log.Printf("[Upload] Mode: %s, MappingSource: %s, AccountCol: %d, StartCol: %d, EndCol: %d, TotalRows: %d",
        mode, cols.Source, accountNameCol, startTimeCol, endTimeCol, len(rows))
    
    // 打印表头信息（前几列）
    if len(rows[0]) > 0 {
        headerPreview := rows[0]
        if len(headerPreview) > maxColNeeded {
            headerPreview = headerPreview[:maxColNeeded]
        }
        log.Printf("表头前%d列: %v", len(headerPreview), headerPreview)
    }

    accountStats := make(map[string]struct {
        Count      int
        StartTimes []time.Time
        EndTimes   []time.Time
    })

    // 解析数据（跳过表头）
    for i, row := range rows[1:] {
        rowIndex := i + 2
        
        // 检查列数是否足够
        if len(row) <= accountNameCol {
            log.Printf("行 %d: 列数不足，需要至少 %d 列，实际 %d 列，跳过", rowIndex, accountNameCol+1, len(row))
            continue
        }
        
        // 获取账号
        accountName := strings.TrimSpace(getColumn(row, accountNameCol))
        accountName = strings.Trim(accountName, "\r\n\t ")
        if accountName == "" {
            log.Printf("行 %d: 账号为空，跳过", rowIndex)
            continue
        }
        if isLikelyHeaderAccountValue(accountName) {
            log.Printf("行 %d: 疑似表头行，跳过 [%s]", rowIndex, accountName)
            continue
        }

        cleanAccountName := normalizeAccountNameForMatch(accountName)
        if cleanAccountName == "" {
            log.Printf("行 %d: 账号规范化后为空，跳过", rowIndex)
            continue
        }

        if i < 5 {
            log.Printf("行 %d: 账号原始=[%s] 规范化=[%s]", rowIndex, accountName, cleanAccountName)
        }

        // 获取时间
        startTimeStr := ""
        if len(row) > startTimeCol {
            startTimeStr = strings.TrimSpace(getColumn(row, startTimeCol))
        }
        endTimeStr := ""
        if len(row) > endTimeCol {
            endTimeStr = strings.TrimSpace(getColumn(row, endTimeCol))
        }

        stats := accountStats[cleanAccountName]
        stats.Count++

        // 解析开始时间
        if startTimeStr != "" {
            if t, err := parseChineseTime(startTimeStr); err == nil {
                stats.StartTimes = append(stats.StartTimes, t)
            } else {
                log.Printf("行 %d: 开始时间解析失败: %s, error: %v", rowIndex, startTimeStr, err)
            }
        }

        // 解析结束时间
        if endTimeStr != "" {
            if t, err := parseChineseTime(endTimeStr); err == nil {
                stats.EndTimes = append(stats.EndTimes, t)
            } else {
                log.Printf("行 %d: 结束时间解析失败: %s, error: %v", rowIndex, endTimeStr, err)
            }
        }

        accountStats[cleanAccountName] = stats
    }

    if len(accountStats) == 0 {
        models.SendError(c, 400, 1001, "未找到有效的账号数据，请检查文件格式")
        return
    }

    // 计算并保存结果
    type AccountResult struct {
        AccountName string
        OrderCount  int
        AvgSeconds  int
    }
    
    var results []AccountResult
    for accountName, stats := range accountStats {
        var totalDuration float64
        var validCount int
        
        minLen := len(stats.StartTimes)
        if len(stats.EndTimes) < minLen {
            minLen = len(stats.EndTimes)
        }
        
        for j := 0; j < minLen; j++ {
            duration := stats.EndTimes[j].Sub(stats.StartTimes[j]).Seconds()
            if duration > 0 && duration < 3600 { // 小于1小时
                totalDuration += duration
                validCount++
            }
        }
        
        avgSeconds := 0
        if validCount > 0 {
            avgSeconds = int(totalDuration / float64(validCount))
        }
        
        results = append(results, AccountResult{
            AccountName: accountName,
            OrderCount:  stats.Count,
            AvgSeconds:  avgSeconds,
        })
    }

    // 保存到数据库
    tx, err := h.db.BeginTx(c.Request.Context(), nil)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer tx.Rollback()

    matchedCount := 0
    var unmatchedAccounts []string
    for _, res := range results {
        var employeeAccountID string

        cleanAccountName := normalizeAccountNameForMatch(res.AccountName)
        if cleanAccountName == "" {
            unmatchedAccounts = append(unmatchedAccounts, res.AccountName)
            continue
        }

        err := tx.QueryRow(`
            SELECT id FROM employee_accounts 
            WHERE site_id = $1 
              AND LOWER(REGEXP_REPLACE(TRIM(account_name), '[[:space:]]+', '', 'g')) = $2
              AND shift = $3
        `, siteID, cleanAccountName, shift).Scan(&employeeAccountID)

        if err != nil {
            log.Printf("账号 [%s] 未匹配到员工（规范化后: [%s]）", res.AccountName, cleanAccountName)
            unmatchedAccounts = append(unmatchedAccounts, res.AccountName)
            continue
        }

        _, err = tx.Exec(`
            INSERT INTO site_stats (employee_account_id, site_id, stat_date, shift, order_count, avg_time_seconds, created_at)
            VALUES ($1, $2, $3, $4, $5, $6, NOW())
            ON CONFLICT (employee_account_id, stat_date, shift) DO UPDATE SET
                order_count = EXCLUDED.order_count,
                avg_time_seconds = EXCLUDED.avg_time_seconds,
                updated_at = NOW()
        `, employeeAccountID, siteID, statDate, shift, res.OrderCount, res.AvgSeconds)
        if err != nil {
            models.SendError(c, 500, 5000, err.Error())
            return
        }
        matchedCount++
    }
    if err := tx.Commit(); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    var siteName string
    _ = h.db.QueryRow(`SELECT name FROM sites WHERE id = $1`, siteID).Scan(&siteName)
    shiftLabel := map[string]string{"day": "A班", "night": "B班"}[shift]
    if shiftLabel == "" {
        shiftLabel = shift
    }
    Log(c, "UPLOAD", "SITE_STATS",
        fmt.Sprintf("上传出款统计：站点 %s，日期 %s，%s，成功匹配 %d 人", siteName, statDate, shiftLabel, matchedCount),
        siteID, siteName)

    models.Send(c, 200, 0, "Upload successful", gin.H{
        "matched_count":      matchedCount,
        "unmatched_count":    len(accountStats) - matchedCount,
        "unmatched_accounts": unmatchedAccounts,
        "column_mapping":     cols.toResponse(),
        "stats": gin.H{
            "total_records":  len(rows) - 1,
            "total_accounts": len(accountStats),
            "matched":        matchedCount,
            "unmatched":      len(accountStats) - matchedCount,
        },
    })
}

// ClearSiteStatsByDate 清除指定日期的站点统计数据
func (h *AdminHandler) ClearSiteStatsByDate(c *gin.Context) {
	siteID := c.Query("site_id")
	shift := c.Query("shift")
	date := c.Query("date")

	if siteID == "" || date == "" {
		models.SendError(c, 400, 1001, "site_id 和 date 不能为空")
		return
	}

	query := "DELETE FROM site_stats WHERE site_id = $1 AND stat_date = $2"
	args := []interface{}{siteID, date}

	if shift != "" {
		query += " AND shift = $3"
		args = append(args, shift)
	}

	result, err := h.db.Exec(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	rowsAffected, _ := result.RowsAffected()
	var siteName string
	_ = h.db.QueryRow(`SELECT name FROM sites WHERE id=$1`, siteID).Scan(&siteName)
	Log(c, "DELETE", "SITE_STATS",
		fmt.Sprintf("清除出款统计：站点 %s，日期 %s，删除 %d 条", siteName, date, rowsAffected),
		siteID, siteName)
	models.Send(c, 200, 0, "Data cleared", gin.H{"deleted": rowsAffected})
}

// GetSiteStatsSummary 获取站点统计汇总
func (h *AdminHandler) GetSiteStatsSummary(c *gin.Context) {
	siteID := c.Query("site_id")
	employeeAccountID := c.Query("employee_account_id")
	employeeName := c.Query("employee_name")  // ✅ 新增：员工姓名搜索
	startDate := c.Query("start_date")
	endDate := c.Query("end_date")
	shift := c.Query("shift")

	where := "1=1"
	args := []interface{}{}
	argIdx := 1
	
	if siteID != "" {
		where += fmt.Sprintf(" AND ss.site_id = $%d", argIdx)
		args = append(args, siteID)
		argIdx++
	}
	if employeeAccountID != "" {
		where += fmt.Sprintf(" AND ss.employee_account_id = $%d", argIdx)
		args = append(args, employeeAccountID)
		argIdx++
	}
	// ✅ 新增：员工姓名模糊搜索
	if employeeName != "" {
		where += fmt.Sprintf(" AND ea.name ILIKE $%d", argIdx)
		args = append(args, "%"+employeeName+"%")
		argIdx++
	}
	if startDate != "" {
		where += fmt.Sprintf(" AND ss.stat_date >= $%d", argIdx)
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where += fmt.Sprintf(" AND ss.stat_date <= $%d", argIdx)
		args = append(args, endDate)
		argIdx++
	}
	if shift != "" {
		where += fmt.Sprintf(" AND ss.shift = $%d", argIdx)
		args = append(args, shift)
		argIdx++
	}

	query := fmt.Sprintf(`
		SELECT 
			ea.name as employee_name,
			ea.account_name,
			ss.site_id,
			s.code as site_code,
            ss.shift, 
			SUM(ss.order_count) as total_value,
			SUM(ss.order_count * ss.avg_time_seconds) as weighted_time,
			SUM(ss.order_count) as total_weight
		FROM site_stats ss
		JOIN employee_accounts ea ON ss.employee_account_id = ea.id
		JOIN sites s ON ss.site_id = s.id
		WHERE %s
        GROUP BY ea.name, ea.account_name, ss.site_id, s.code, ss.shift 
		ORDER BY total_value DESC
	`, where)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var items []map[string]interface{}
	siteColumns := make(map[string]bool)

	for rows.Next() {
		var employeeName, accountName, siteID, siteCode string
		var totalValue int
		var weightedTime, totalWeight int
		var shiftValue string

		err := rows.Scan(&employeeName, &accountName, &siteID, &siteCode, &shiftValue, &totalValue, &weightedTime, &totalWeight)
		if err != nil {
			continue
		}

		siteColumns[siteCode] = true

		items = append(items, map[string]interface{}{
			"employee_name": employeeName,
			"account_name":  accountName,
			"site_id":       siteID,
			"site_code":     siteCode,
            "shift":         shiftValue,
			"total_value":   totalValue,
			"total_avg_seconds": func() int {
				if totalWeight > 0 {
					return weightedTime / totalWeight
				}
				return 0
			}(),
		})
	}

	// 转换为按员工聚合的格式
	employeeMap := make(map[string]map[string]interface{})
	for _, item := range items {
		empName := item["employee_name"].(string)
		if employeeMap[empName] == nil {
			employeeMap[empName] = map[string]interface{}{
				"employee_name":       empName,
				"account_name":        item["account_name"],
				"sites":               make(map[string]interface{}),
				"total_value":         0,
				"total_weighted_time": 0,
				"total_weight":        0,
			}
		}
		emp := employeeMap[empName]
		siteCode := item["site_code"].(string)
		emp["sites"].(map[string]interface{})[siteCode] = map[string]interface{}{
			"value":            item["total_value"],
			"avg_time_seconds": item["total_avg_seconds"],
			"avg_time_str":     formatSecondsToTime(item["total_avg_seconds"].(int)),
		}
		emp["total_value"] = emp["total_value"].(int) + item["total_value"].(int)
		
		// 累加加权时间和权重用于计算总体平均时间
		if val, ok := item["total_avg_seconds"].(int); ok {
			emp["total_weighted_time"] = emp["total_weighted_time"].(int) + (val * item["total_value"].(int))
			emp["total_weight"] = emp["total_weight"].(int) + item["total_value"].(int)
		}
	}

	var result []map[string]interface{}
	for _, emp := range employeeMap {
		// 计算总体平均时间
		totalWeight := emp["total_weight"].(int)
		if totalWeight > 0 {
			avgSeconds := emp["total_weighted_time"].(int) / totalWeight
			emp["total_avg_seconds"] = avgSeconds
			emp["total_avg_time"] = formatSecondsToTime(avgSeconds)
		} else {
			emp["total_avg_seconds"] = 0
			emp["total_avg_time"] = "-"
		}
		result = append(result, emp)
	}

	// 获取站点列
	var siteCols []string
	for site := range siteColumns {
		siteCols = append(siteCols, site)
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":        result,
		"site_columns": siteCols,
	})
}

// 辅助函数
func getColumn(row []string, idx int) string {
	if idx < len(row) {
		return row[idx]
	}
	return ""
}

func parseChineseTime(timeStr string) (time.Time, error) {
	layouts := []string{
		"2006-01-02 15:04:05",
		"2006/1/2 15:04:05",
		"2006-01-02 15:04",
		"2006/1/2 15:04",
	}
	for _, layout := range layouts {
		if t, err := time.ParseInLocation(layout, timeStr, time.Local); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("parse error: %s", timeStr)
}

func formatSecondsToTime(seconds int) string {
	if seconds <= 0 {
		return "0秒"
	}
	minutes := seconds / 60
	secs := seconds % 60
	if minutes > 0 && secs > 0 {
		return fmt.Sprintf("%d分%d秒", minutes, secs)
	}
	if minutes > 0 {
		return fmt.Sprintf("%d分", minutes)
	}
	return fmt.Sprintf("%d秒", secs)
}

func nullTimeToString(t sql.NullTime) string {
	if t.Valid {
		return t.Time.Format("2006-01-02")
	}
	return ""
}

func nullStringToString(s sql.NullString) string {
	if s.Valid {
		return s.String
	}
	return ""
}

func nullStringToInterface(s sql.NullString) interface{} {
	if s.Valid {
		return s.String
	}
	return nil
}

// GetSiteStatsStacked 获取站点统计堆叠数据（按日期+员工+班次分组）
func (h *AdminHandler) GetSiteStatsStacked(c *gin.Context) {
	siteID := c.Query("site_id")
	employeeAccountID := c.Query("employee_account_id")
	employeeName := c.Query("employee_name")
	startDate := c.Query("start_date")
	endDate := c.Query("end_date")
	shift := c.Query("shift")

	where := "1=1"
	args := []interface{}{}
	argIdx := 1

	if siteID != "" {
		where += fmt.Sprintf(" AND ss.site_id = $%d", argIdx)
		args = append(args, siteID)
		argIdx++
	}
	if employeeAccountID != "" {
		where += fmt.Sprintf(" AND ss.employee_account_id = $%d", argIdx)
		args = append(args, employeeAccountID)
		argIdx++
	}
	if employeeName != "" {
		where += fmt.Sprintf(" AND ea.name ILIKE $%d", argIdx)
		args = append(args, "%"+employeeName+"%")
		argIdx++
	}
	if startDate != "" {
		where += fmt.Sprintf(" AND ss.stat_date >= $%d", argIdx)
		args = append(args, startDate)
		argIdx++
	}
	if endDate != "" {
		where += fmt.Sprintf(" AND ss.stat_date <= $%d", argIdx)
		args = append(args, endDate)
		argIdx++
	}
	if shift != "" {
		where += fmt.Sprintf(" AND ss.shift = $%d", argIdx)
		args = append(args, shift)
		argIdx++
	}

	// ✅ 修改：在 SELECT 中添加 ss.shift 字段
	query := fmt.Sprintf(`
        SELECT 
            ea.name as employee_name,
            ea.account_name,
            ss.stat_date as date,
            s.code as site_code,
            ss.shift,                       -- ✅ 新增：班次字段
            ss.order_count as value,
            ss.avg_time_seconds,
            ss.employee_account_id
        FROM site_stats ss
        JOIN employee_accounts ea ON ss.employee_account_id = ea.id
        JOIN sites s ON ss.site_id = s.id
        WHERE %s
        ORDER BY ss.stat_date DESC, ea.name ASC
    `, where)

	rows, err := h.db.Query(query, args...)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var items []map[string]interface{}
	siteColumns := make(map[string]bool)

	for rows.Next() {
		var employeeName, accountName, date, siteCode, shiftValue string // ✅ 新增 shiftValue
		var value, avgTimeSeconds int
		var employeeAccountID string

		// ✅ 修改：扫描 shift 字段
		err := rows.Scan(&employeeName, &accountName, &date, &siteCode, &shiftValue,
			&value, &avgTimeSeconds, &employeeAccountID)
		if err != nil {
			log.Printf("Scan error in GetSiteStatsStacked: %v", err)
			continue
		}

		siteColumns[siteCode] = true

		items = append(items, map[string]interface{}{
			"employee_name":    employeeName,
			"account_name":     accountName,
			"employee_id":      employeeAccountID,
			"date":             date,
			"site_code":        siteCode,
			"shift":            shiftValue, // ✅ 新增：返回班次
			"value":            value,
			"avg_time_seconds": avgTimeSeconds,
			"avg_time_str":     formatSecondsToTime(avgTimeSeconds),
		})
	}

	var siteCols []string
	for site := range siteColumns {
		siteCols = append(siteCols, site)
	}

	models.Send(c, 200, 0, "success", gin.H{
		"items":        items,
		"site_columns": siteCols,
	})
}

// ClearAllSiteStats 清空所有站点统计数据（保留站点与员工配置）
func (h *AdminHandler) ClearAllSiteStats(c *gin.Context) {
	result, err := h.db.Exec("DELETE FROM site_stats")
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	rowsAffected, _ := result.RowsAffected()
	Log(c, "DELETE", "SITE_STATS",
		fmt.Sprintf("清空全部出款统计数据，删除 %d 条", rowsAffected), "", "全部站点")
	models.Send(c, 200, 0, "All site stats data cleared", gin.H{"deleted": rowsAffected})
}

// ClearSiteStatsByDateOnly 删除指定日期的所有站点统计数据
func (h *AdminHandler) ClearSiteStatsByDateOnly(c *gin.Context) {
    date := c.Query("date")
    
    if date == "" {
        models.SendError(c, 400, 1001, "date 不能为空")
        return
    }
    
    query := "DELETE FROM site_stats WHERE stat_date = $1"
    
    result, err := h.db.Exec(query, date)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    
    rowsAffected, _ := result.RowsAffected()
    Log(c, "DELETE", "SITE_STATS",
        fmt.Sprintf("清除 %s 全部站点出款统计，删除 %d 条", date, rowsAffected), "", date)
    models.Send(c, 200, 0, "Data cleared", gin.H{"deleted": rowsAffected})
}

// ClearSiteStatsByDateAndShift 删除指定日期、指定班次的全部站点统计数据
func (h *AdminHandler) ClearSiteStatsByDateAndShift(c *gin.Context) {
	date := c.Query("date")
	shift := c.Query("shift")

	if date == "" || shift == "" {
		models.SendError(c, 400, 1001, "date 和 shift 不能为空")
		return
	}

	result, err := h.db.Exec(
		"DELETE FROM site_stats WHERE stat_date = $1 AND shift = $2",
		date, shift,
	)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	rowsAffected, _ := result.RowsAffected()
	shiftLabel := shift
	if shift == "day" {
		shiftLabel = "A班"
	} else if shift == "night" {
		shiftLabel = "B班"
	}
	Log(c, "DELETE", "SITE_STATS",
		fmt.Sprintf("清除 %s %s 全部站点出款统计，删除 %d 条", date, shiftLabel, rowsAffected), "", date)
	models.Send(c, 200, 0, "Data cleared", gin.H{"deleted": rowsAffected})
}

// ==================== 工资管理 ====================
// EmployeeInfo 员工基本信息（用于工资匹配）
type EmployeeInfo struct {
    ID       string `json:"id"`
    Name     string `json:"name"`
    Position string `json:"position"`
}

// SalaryRecord 工资记录结构
type SalaryRecord struct {
    ID                   string    `json:"id"`
    EmployeeID           string    `json:"employeeId"`
    EmployeeName         string    `json:"employeeName"`
    Position             string    `json:"position"`
    HireDateDept         string    `json:"hireDateDept"`
    MonthsEmployed       int       `json:"monthsEmployed"`
    LastMonthBase        float64   `json:"lastMonthBase"`
    TotalIncrease        float64   `json:"totalIncrease"`
    BaseSalary           float64   `json:"baseSalary"`
    AttendanceDays       float64   `json:"attendanceDays"`
    ActualBaseSalary     float64   `json:"actualBaseSalary"`
    AttendanceAdjustment float64   `json:"attendanceAdjustment"`
    HalfYearUnpaidLeave  float64   `json:"halfYearUnpaidLeave"`
    ExchangeRate         float64   `json:"exchangeRate"`
    PerformanceScore     int       `json:"performanceScore"`
    PerformanceBonusB    float64   `json:"performanceBonusB"`
    Reward               float64   `json:"reward"`
    Penalty              float64   `json:"penalty"`
    Advance              float64   `json:"advance"`
    OtherDeduction       float64   `json:"otherDeduction"`
    ProtectionReturn     float64   `json:"protectionReturn"`
    ProtectionFee        float64   `json:"protectionFee"`
    TotalSalary          float64   `json:"totalSalary"`
    Remark               string    `json:"remark"`
    YearMonth            string    `json:"yearMonth"`
    PaidStatus           string    `json:"paidStatus"`
    PaidAt               *time.Time `json:"paidAt,omitempty"`
    CreatedAt            time.Time `json:"createdAt"`
    UpdatedAt            time.Time `json:"updatedAt"`
}

// UploadSalary 上传工资表
func (h *AdminHandler) UploadSalary(c *gin.Context) {
    file, err := c.FormFile("file")
    if err != nil {
        models.SendError(c, 400, 1001, "请选择文件")
        return
    }

    yearMonth := c.PostForm("yearMonth")
    if yearMonth == "" {
        yearMonth = time.Now().AddDate(0, -1, 0).Format("2006-01")
    }

    src, err := file.Open()
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer src.Close()

    f, err := excelize.OpenReader(src)
    if err != nil {
        models.SendError(c, 400, 1001, "无法解析Excel文件")
        return
    }

    sheetName := f.GetSheetName(0)
    rows, err := f.GetRows(sheetName)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    if len(rows) < 2 {
        models.SendError(c, 400, 1001, "文件无数据")
        return
    }

    header := rows[0]
    useDynamic := parseUseDynamicColumns(c)
    nameCol := 1
    colMap := defaultSalaryColumnMap()
    var sheetHeaders []string
    if useDynamic {
        nameCol = parseNameColumnIndex(c, header)
        sheetWidth := maxSalarySheetWidth(rows)
        sheetHeaders = buildSalarySheetHeaders(header, sheetWidth)
        if err := upsertSalaryMonthLayout(c.Request.Context(), h.db, yearMonth, sheetHeaders, nameCol); err != nil {
            models.SendError(c, 500, 5000, err.Error())
            return
        }
        colMap = resolveSalaryColumnsFromHeader(header)
    } else if err := clearSalaryMonthLayout(c.Request.Context(), h.db, yearMonth); err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 按用户管理（用户名/姓名）匹配并关联员工
    userLookup, err := h.getSalaryUserLookupMap(c.Request.Context())
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    var successCount, failCount int
    var failedRecords []map[string]interface{}

    for i, row := range rows[1:] {
        rowIndex := i + 2

        if isSalaryHeaderRow(row, nameCol) {
            continue
        }

        name := getColumnValue(row, nameCol)
        if name == "" || isSalaryEmptyToken(name) {
            continue
        }

        userMatch, exists := userLookup[normalizeSalaryLookupKey(name)]
        if !exists || userMatch == nil || strings.TrimSpace(userMatch.EmployeeID) == "" {
            failCount++
            failedRecords = append(failedRecords, map[string]interface{}{
                "row":    rowIndex,
                "name":   name,
                "reason": salaryUserLookupFailReason(name, userMatch, exists),
            })
            continue
        }

        record := SalaryRecord{
            EmployeeID:   userMatch.EmployeeID,
            EmployeeName: userMatch.EmployeeName,
            YearMonth:    yearMonth,
            ID:           uuid.New().String(),
            CreatedAt:    time.Now(),
            UpdatedAt:    time.Now(),
        }

        fillSalaryLegacyFields(&record, row, colMap, userMatch.Position)

        var sheetJSON interface{}
        if useDynamic {
            sheetValues := buildSalarySheetValues(sheetHeaders, row)
            encoded, marshalErr := json.Marshal(sheetValues)
            if marshalErr != nil {
                failCount++
                failedRecords = append(failedRecords, map[string]interface{}{
                    "row": rowIndex, "name": name, "reason": marshalErr.Error(),
                })
                continue
            }
            sheetJSON = string(encoded)
        }

        _, err = h.db.ExecContext(c.Request.Context(), `
            INSERT INTO salary_records (
                id, employee_id, employee_name, position, hire_date_dept,
                months_employed, last_month_base, total_increase, base_salary,
                attendance_days, actual_base_salary, attendance_adjustment,
                half_year_unpaid_leave, exchange_rate, performance_score,
                performance_bonus_b, reward, penalty, advance, other_deduction,
                protection_return, protection_fee, total_salary, remark, year_month,
                paid_status, sheet_values, created_at, updated_at
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, 'pending', $26::jsonb, $27, $28)
            ON CONFLICT (employee_id, year_month) DO UPDATE SET
                employee_name = EXCLUDED.employee_name,
                position = EXCLUDED.position,
                hire_date_dept = EXCLUDED.hire_date_dept,
                months_employed = EXCLUDED.months_employed,
                last_month_base = EXCLUDED.last_month_base,
                total_increase = EXCLUDED.total_increase,
                base_salary = EXCLUDED.base_salary,
                attendance_days = EXCLUDED.attendance_days,
                actual_base_salary = EXCLUDED.actual_base_salary,
                attendance_adjustment = EXCLUDED.attendance_adjustment,
                half_year_unpaid_leave = EXCLUDED.half_year_unpaid_leave,
                exchange_rate = EXCLUDED.exchange_rate,
                performance_score = EXCLUDED.performance_score,
                performance_bonus_b = EXCLUDED.performance_bonus_b,
                reward = EXCLUDED.reward,
                penalty = EXCLUDED.penalty,
                advance = EXCLUDED.advance,
                other_deduction = EXCLUDED.other_deduction,
                protection_return = EXCLUDED.protection_return,
                protection_fee = EXCLUDED.protection_fee,
                total_salary = EXCLUDED.total_salary,
                remark = EXCLUDED.remark,
                sheet_values = EXCLUDED.sheet_values,
                paid_status = 'pending',
                paid_at = NULL,
                updated_at = EXCLUDED.updated_at
        `,
            record.ID, record.EmployeeID, record.EmployeeName, record.Position, record.HireDateDept,
            record.MonthsEmployed, record.LastMonthBase, record.TotalIncrease, record.BaseSalary,
            record.AttendanceDays, record.ActualBaseSalary, record.AttendanceAdjustment,
            record.HalfYearUnpaidLeave, record.ExchangeRate, record.PerformanceScore,
            record.PerformanceBonusB, record.Reward, record.Penalty, record.Advance, record.OtherDeduction,
            record.ProtectionReturn, record.ProtectionFee, record.TotalSalary, record.Remark, record.YearMonth,
            sheetJSON, record.CreatedAt, record.UpdatedAt,
        )
        if err != nil {
            failCount++
            failedRecords = append(failedRecords, map[string]interface{}{
                "row":    rowIndex,
                "name":   name,
                "reason": err.Error(),
            })
            continue
        }
        successCount++
    }

    models.Send(c, 200, 0, "上传完成", gin.H{
        "successCount":  successCount,
        "failCount":     failCount,
        "failedRecords": failedRecords,
        "yearMonth":     yearMonth,
    })


    // ✅ 记录操作日志（需要在函数内获取 operationLogHandler）
    Log(c, "UPLOAD", "SALARY",
        fmt.Sprintf("上传工资表：%s 月，成功 %d 条，失败 %d 条", yearMonth, successCount, failCount),
        "", yearMonth)
}

// canScopeSalaryToOthers reports whether the caller may query salary for any employee.
// salary:upload keeps full management scope; salary:view_others is view-only across employees.
func canScopeSalaryToOthers(c *gin.Context) bool {
	return middleware.UserHasPermission(c, "salary:view_others") ||
		middleware.UserHasPermission(c, "salary:upload")
}

// GetSalaryRecords 获取工资记录
func (h *AdminHandler) GetSalaryRecords(c *gin.Context) {
    yearMonth := c.Query("yearMonth")
    employeeID := c.Query("employeeId")
    employeeName := c.Query("employeeName")

    // No cross-employee scope → always self.
    // view_others without upload and without employeeId → self (do not dump all records).
    // upload may omit employeeId to list all (SalaryManagement).
    forceSelf := !canScopeSalaryToOthers(c) ||
        (employeeID == "" && !middleware.UserHasPermission(c, "salary:upload"))
    if forceSelf {
        empUUID, err := h.resolveEmployeeIDForCurrentUser(c)
        if err != nil {
            if errors.Is(err, errEmployeeNotFound) {
                models.SendError(c, 404, 2001, "未找到员工信息")
                return
            }
            models.SendError(c, 500, 5000, err.Error())
            return
        }
        employeeID = empUUID
    }

    where := "1=1"
    args := []interface{}{}
    argIdx := 1

    if yearMonth != "" {
        where += fmt.Sprintf(" AND sr.year_month = $%d", argIdx)
        args = append(args, yearMonth)
        argIdx++
    }
    if employeeID != "" {
        where += fmt.Sprintf(" AND sr.employee_id = $%d", argIdx)
        args = append(args, employeeID)
        argIdx++
    }
    if employeeName != "" {
        where += fmt.Sprintf(" AND sr.employee_name ILIKE $%d", argIdx)
        args = append(args, "%"+employeeName+"%")
        argIdx++
    }

    query := fmt.Sprintf(`
        SELECT sr.id, sr.employee_id, sr.employee_name, sr.position, sr.hire_date_dept,
               sr.months_employed, sr.last_month_base, sr.total_increase, sr.base_salary,
               sr.attendance_days, sr.actual_base_salary, sr.attendance_adjustment,
               sr.half_year_unpaid_leave, sr.exchange_rate, sr.performance_score,
               sr.performance_bonus_b, sr.reward, sr.penalty, sr.advance, sr.other_deduction,
               sr.protection_return, sr.protection_fee, sr.total_salary, sr.remark, sr.year_month,
               COALESCE(sr.paid_status, 'pending'), sr.paid_at, sr.created_at, sr.updated_at,
               sr.sheet_values,
               spp.id::text, spp.file_name, spp.uploaded_at
        FROM salary_records sr
        LEFT JOIN salary_payment_proofs spp
          ON spp.employee_id = sr.employee_id::uuid AND spp.year_month = sr.year_month
        WHERE %s
        ORDER BY sr.year_month DESC, sr.employee_name ASC
    `, where)

    rows, err := h.db.Query(query, args...)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer rows.Close()

    sheetHeaders, _ := loadSalaryMonthLayout(c.Request.Context(), h.db, yearMonth)

    var records []map[string]interface{}
    for rows.Next() {
        var r SalaryRecord
        var createdAt, updatedAt time.Time
        var paidAt sql.NullTime
        var proofID, proofFileName sql.NullString
        var proofUploadedAt sql.NullTime
        var sheetValuesRaw []byte
        err := rows.Scan(
            &r.ID, &r.EmployeeID, &r.EmployeeName, &r.Position, &r.HireDateDept,
            &r.MonthsEmployed, &r.LastMonthBase, &r.TotalIncrease, &r.BaseSalary,
            &r.AttendanceDays, &r.ActualBaseSalary, &r.AttendanceAdjustment,
            &r.HalfYearUnpaidLeave, &r.ExchangeRate, &r.PerformanceScore,
            &r.PerformanceBonusB, &r.Reward, &r.Penalty, &r.Advance, &r.OtherDeduction,
            &r.ProtectionReturn, &r.ProtectionFee, &r.TotalSalary, &r.Remark, &r.YearMonth,
            &r.PaidStatus, &paidAt, &createdAt, &updatedAt,
            &sheetValuesRaw,
            &proofID, &proofFileName, &proofUploadedAt,
        )
        if err != nil {
            continue
        }
        item := map[string]interface{}{
            "id":                    r.ID,
            "employeeId":            r.EmployeeID,
            "employeeName":          r.EmployeeName,
            "position":              r.Position,
            "hireDateDept":          r.HireDateDept,
            "monthsEmployed":        r.MonthsEmployed,
            "lastMonthBase":         r.LastMonthBase,
            "totalIncrease":         r.TotalIncrease,
            "baseSalary":            r.BaseSalary,
            "attendanceDays":        r.AttendanceDays,
            "actualBaseSalary":      r.ActualBaseSalary,
            "attendanceAdjustment":  r.AttendanceAdjustment,
            "halfYearUnpaidLeave":   r.HalfYearUnpaidLeave,
            "exchangeRate":          r.ExchangeRate,
            "performanceScore":      r.PerformanceScore,
            "performanceBonusB":     r.PerformanceBonusB,
            "reward":                r.Reward,
            "penalty":               r.Penalty,
            "advance":               r.Advance,
            "otherDeduction":        r.OtherDeduction,
            "protectionReturn":      r.ProtectionReturn,
            "protectionFee":         r.ProtectionFee,
            "totalSalary":           r.TotalSalary,
            "remark":                r.Remark,
            "yearMonth":             r.YearMonth,
            "paidStatus":            r.PaidStatus,
            "paidStatusLabel":       map[string]string{"paid": "已发", "pending": "待发"}[r.PaidStatus],
            "createdAt":             createdAt,
        }
        if paidAt.Valid {
            item["paidAt"] = models.FormatUTC(paidAt.Time)
        }
        if proofID.Valid {
            item["paymentProofId"] = proofID.String
            item["paymentProofFileName"] = proofFileName.String
            if proofUploadedAt.Valid {
                item["paymentProofUploadedAt"] = models.FormatUTC(proofUploadedAt.Time)
            }
        }
        if len(sheetValuesRaw) > 0 {
            var sheetValues []string
            if err := json.Unmarshal(sheetValuesRaw, &sheetValues); err == nil {
                item["sheetValues"] = sheetValues
            }
        }
        records = append(records, item)
    }

    models.Send(c, 200, 0, "success", gin.H{
        "items":        records,
        "total":        len(records),
        "sheetHeaders": sheetHeaders,
    })
}

// UpdateSalaryRecord 更新工资记录
func (h *AdminHandler) UpdateSalaryRecord(c *gin.Context) {
    id := c.Param("id")

    // ✅ 1. 先查询旧记录（用于日志记录）
    var oldRecord SalaryRecord
    err := h.db.QueryRow(`
        SELECT employee_name, base_salary, attendance_adjustment, performance_bonus_b,
               reward, penalty, advance, other_deduction, protection_fee, 
               protection_return, total_salary, remark, year_month
        FROM salary_records WHERE id = $1
    `, id).Scan(
        &oldRecord.EmployeeName, &oldRecord.BaseSalary, &oldRecord.AttendanceAdjustment,
        &oldRecord.PerformanceBonusB, &oldRecord.Reward, &oldRecord.Penalty,
        &oldRecord.Advance, &oldRecord.OtherDeduction, &oldRecord.ProtectionFee,
        &oldRecord.ProtectionReturn, &oldRecord.TotalSalary, &oldRecord.Remark, &oldRecord.YearMonth,
    )
    if err != nil {
        models.SendError(c, 500, 5000, "获取原工资记录失败: "+err.Error())
        return
    }

    // 2. 解析请求参数
    var req SalaryRecord
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }

    // 3. 执行更新
    _, err = h.db.Exec(`
        UPDATE salary_records SET
            position = $1, hire_date_dept = $2, months_employed = $3,
            last_month_base = $4, total_increase = $5, base_salary = $6,
            attendance_days = $7, actual_base_salary = $8, attendance_adjustment = $9,
            half_year_unpaid_leave = $10, exchange_rate = $11, performance_score = $12,
            performance_bonus_b = $13, reward = $14, penalty = $15, advance = $16,
            other_deduction = $17, protection_return = $18, protection_fee = $19,
            total_salary = $20, remark = $21, updated_at = NOW()
        WHERE id = $22
    `,
        req.Position, req.HireDateDept, req.MonthsEmployed,
        req.LastMonthBase, req.TotalIncrease, req.BaseSalary,
        req.AttendanceDays, req.ActualBaseSalary, req.AttendanceAdjustment,
        req.HalfYearUnpaidLeave, req.ExchangeRate, req.PerformanceScore,
        req.PerformanceBonusB, req.Reward, req.Penalty, req.Advance,
        req.OtherDeduction, req.ProtectionReturn, req.ProtectionFee,
        req.TotalSalary, req.Remark, id,
    )
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // ✅ 4. 记录操作日志（使用全局 Log 函数）
    changeDesc := fmt.Sprintf("修改工资：员工 %s，%s 月", oldRecord.EmployeeName, oldRecord.YearMonth)
    Log(c, "UPDATE", "SALARY", changeDesc, id, oldRecord.EmployeeName)

    models.Send(c, 200, 0, "更新成功", nil)
}

// DeleteSalaryRecord 删除工资记录
func (h *AdminHandler) DeleteSalaryRecord(c *gin.Context) {
	id := c.Param("id")
    
    // ✅ 获取员工姓名用于日志
    var employeeName string
    h.db.QueryRow(`SELECT employee_name FROM salary_records WHERE id = $1`, id).Scan(&employeeName)
    
	_, err := h.db.Exec("DELETE FROM salary_records WHERE id = $1", id)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
    
    // ✅ 修复: 记录操作日志
    Log(c, "DELETE", "SALARY", fmt.Sprintf("删除工资：员工 %s", employeeName), id, employeeName)
    
	models.Send(c, 200, 0, "删除成功", nil)
}

// MarkSalaryPaid 标记工资已发放
func (h *AdminHandler) MarkSalaryPaid(c *gin.Context) {
	var req struct {
		ID         string `json:"id"`
		EmployeeID string `json:"employeeId"`
		YearMonth  string `json:"yearMonth"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}

	var employeeName, yearMonth, employeeUUID string
	var totalSalary float64
	var result sql.Result
	var err error

	if strings.TrimSpace(req.ID) != "" {
		err = h.db.QueryRow(`
			SELECT employee_name, year_month, employee_id, total_salary FROM salary_records WHERE id = $1
		`, req.ID).Scan(&employeeName, &yearMonth, &employeeUUID, &totalSalary)
		if err == sql.ErrNoRows {
			models.SendError(c, 404, 2001, "工资记录不存在，请先上传工资")
			return
		}
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		result, err = h.db.Exec(`
			UPDATE salary_records SET paid_status = 'paid', paid_at = NOW(), updated_at = NOW()
			WHERE id = $1 AND paid_status != 'paid'
		`, req.ID)
	} else {
		req.EmployeeID = strings.TrimSpace(req.EmployeeID)
		req.YearMonth = strings.TrimSpace(req.YearMonth)
		if req.EmployeeID == "" || req.YearMonth == "" {
			models.SendError(c, 400, 1001, "请提供工资记录或员工与月份")
			return
		}
		err = h.db.QueryRow(`
			SELECT employee_name, year_month, employee_id, total_salary FROM salary_records
			WHERE employee_id = $1 AND year_month = $2
		`, req.EmployeeID, req.YearMonth).Scan(&employeeName, &yearMonth, &employeeUUID, &totalSalary)
		if err == sql.ErrNoRows {
			models.SendError(c, 404, 2001, "该月工资尚未上传，请先上传")
			return
		}
		if err != nil {
			models.SendError(c, 500, 5000, err.Error())
			return
		}
		result, err = h.db.Exec(`
			UPDATE salary_records SET paid_status = 'paid', paid_at = NOW(), updated_at = NOW()
			WHERE employee_id = $1 AND year_month = $2 AND paid_status != 'paid'
		`, req.EmployeeID, req.YearMonth)
	}
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		models.Send(c, 200, 0, "该月工资已是已发状态", gin.H{
			"employeeName": employeeName,
			"yearMonth":    yearMonth,
			"paidStatus":   "paid",
		})
		return
	}

	Log(c, "UPDATE", "SALARY",
		fmt.Sprintf("标记已发：%s %s 月工资", employeeName, yearMonth),
		req.ID, employeeName)

	if employeeUUID != "" {
		h.notifySalaryPaid(c.Request.Context(), employeeUUID, yearMonth, employeeName, totalSalary)
	}

	models.Send(c, 200, 0, "已标记为已发", gin.H{
		"employeeName": employeeName,
		"yearMonth":    yearMonth,
		"paidStatus":   "paid",
	})
}

// MarkAllSalaryPaid marks all pending salary records for a month as paid and notifies employees.
func (h *AdminHandler) MarkAllSalaryPaid(c *gin.Context) {
	var req struct {
		YearMonth string `json:"yearMonth" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		models.SendError(c, 400, 1001, "Invalid request")
		return
	}
	yearMonth := strings.TrimSpace(req.YearMonth)
	if yearMonth == "" {
		models.SendError(c, 400, 1001, "请选择工资月份")
		return
	}

	rows, err := h.db.QueryContext(c.Request.Context(), `
		SELECT id, employee_id, employee_name, total_salary
		FROM salary_records
		WHERE year_month = $1 AND COALESCE(paid_status, 'pending') != 'paid'
	`, yearMonth)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	type pendingSalary struct {
		id           string
		employeeUUID string
		employeeName string
		totalSalary  float64
	}
	pending := make([]pendingSalary, 0)
	for rows.Next() {
		var item pendingSalary
		if err := rows.Scan(&item.id, &item.employeeUUID, &item.employeeName, &item.totalSalary); err != nil {
			continue
		}
		pending = append(pending, item)
	}
	if len(pending) == 0 {
		models.Send(c, 200, 0, "该月份工资已全部标记为已发", gin.H{
			"yearMonth":   yearMonth,
			"markedCount": 0,
		})
		return
	}

	result, err := h.db.ExecContext(c.Request.Context(), `
		UPDATE salary_records SET paid_status = 'paid', paid_at = NOW(), updated_at = NOW()
		WHERE year_month = $1 AND COALESCE(paid_status, 'pending') != 'paid'
	`, yearMonth)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	markedCount, _ := result.RowsAffected()

	ctx := c.Request.Context()
	for _, item := range pending {
		h.notifySalaryPaid(ctx, item.employeeUUID, yearMonth, item.employeeName, item.totalSalary)
	}

	Log(c, "UPDATE", "SALARY",
		fmt.Sprintf("批量标记已发：%s 共 %d 人", yearMonth, markedCount),
		yearMonth, yearMonth)

	models.Send(c, 200, 0, fmt.Sprintf("已批量标记 %d 人为已发", markedCount), gin.H{
		"yearMonth":   yearMonth,
		"markedCount": markedCount,
	})
}

// GetSalaryMonths 获取可用的工资月份列表
func (h *AdminHandler) GetSalaryMonths(c *gin.Context) {
    var rows *sql.Rows
    var err error

    employeeID := strings.TrimSpace(c.Query("employeeId"))
    forceSelf := !canScopeSalaryToOthers(c) ||
        (employeeID == "" && !middleware.UserHasPermission(c, "salary:upload"))
    if forceSelf {
        empUUID, resolveErr := h.resolveEmployeeIDForCurrentUser(c)
        if resolveErr != nil {
            if errors.Is(resolveErr, errEmployeeNotFound) {
                models.SendError(c, 404, 2001, "未找到员工信息")
                return
            }
            models.SendError(c, 500, 5000, resolveErr.Error())
            return
        }
        employeeID = empUUID
    }
    if employeeID != "" {
        rows, err = h.db.Query(`
            SELECT DISTINCT year_month FROM salary_records
            WHERE employee_id = $1
            ORDER BY year_month DESC
        `, employeeID)
    } else {
        rows, err = h.db.Query(`
            SELECT DISTINCT year_month FROM salary_records
            ORDER BY year_month DESC
        `)
    }
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    defer rows.Close()

    var months []string
    for rows.Next() {
        var month string
        rows.Scan(&month)
        months = append(months, month)
    }

    models.Send(c, 200, 0, "success", months)
}

// SalaryUserMatch 工资上传：按用户管理匹配后关联的员工
type SalaryUserMatch struct {
    EmployeeID   string
    EmployeeName string
    Position     string
}

// getSalaryUserLookupMap 按用户管理的用户名/姓名匹配，并关联员工档案
func (h *AdminHandler) getSalaryUserLookupMap(ctx context.Context) (map[string]*SalaryUserMatch, error) {
    rows, err := h.db.QueryContext(ctx, `
        SELECT u.username,
               COALESCE(NULLIF(TRIM(u.real_name), ''), ''),
               COALESCE(e.id::text, ''),
               COALESCE(e.position, '')
        FROM users u
        LEFT JOIN employees e ON e.user_id = u.id AND e.status = 1
        WHERE u.status = 1`)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    lookup := make(map[string]*SalaryUserMatch)
    for rows.Next() {
        var username, realName, empID, position string
        if err := rows.Scan(&username, &realName, &empID, &position); err != nil {
            continue
        }
        displayName := strings.TrimSpace(realName)
        if displayName == "" {
            displayName = strings.TrimSpace(username)
        }
        match := &SalaryUserMatch{
            EmployeeID:   empID,
            EmployeeName: displayName,
            Position:     position,
        }
        if key := normalizeSalaryLookupKey(username); key != "" {
            lookup[key] = match
        }
        if realName != "" {
            if key := normalizeSalaryLookupKey(realName); key != "" {
                lookup[key] = match
            }
        }
    }
    return lookup, nil
}

func salaryUserLookupFailReason(name string, match *SalaryUserMatch, exists bool) string {
    if !exists {
        return fmt.Sprintf("用户「%s」不存在，请确认 Excel 姓名/用户名与用户管理一致", name)
    }
    if match == nil || strings.TrimSpace(match.EmployeeID) == "" {
        return fmt.Sprintf("用户「%s」未关联员工档案，请先在员工管理中绑定该用户账号", name)
    }
    return "匹配失败"
}

func normalizeSalaryLookupKey(s string) string {
    return strings.ToUpper(strings.TrimSpace(s))
}

func isSalaryHeaderRow(row []string, nameIdx int) bool {
    name := getColumnValue(row, nameIdx)
    switch name {
    case "名字", "姓名", "用户名", "员工姓名", "员工名字":
        return true
    default:
        return strings.Contains(name, "姓名") && len(name) <= 6
    }
}

func formatExcelDateSerial(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" || isSalaryEmptyToken(raw) {
		return ""
	}
	numStr := strings.ReplaceAll(raw, ",", "")
	if f, err := strconv.ParseFloat(numStr, 64); err == nil && f > 20000 && f < 80000 {
		if t, err := excelize.ExcelDateToTime(f, false); err == nil {
			return t.Format("2006-01-02")
		}
	}
	return ""
}

func parseFlexibleDateString(s string) (time.Time, bool) {
	s = strings.TrimSpace(s)
	layouts := []string{
		"2006-01-02", "2006-1-2", "2006/01/02", "2006/1/2",
		"2006.01.02", "2006.1.2", "2006年01月02日", "2006年1月2日",
		"01-02-06", "2006-01-02 15:04:05",
	}
	for _, layout := range layouts {
		if t, err := time.Parse(layout, s); err == nil {
			return t, true
		}
	}
	return time.Time{}, false
}

func splitLeadingDatePart(raw string) (dateStr, rest string) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return "", ""
	}
	if len(raw) >= 10 {
		if t, ok := parseFlexibleDateString(raw[:10]); ok {
			remainder := strings.TrimSpace(raw[10:])
			remainder = strings.TrimPrefix(remainder, "-")
			remainder = strings.TrimPrefix(remainder, "—")
			remainder = strings.TrimPrefix(remainder, "/")
			return t.Format("2006-01-02"), remainder
		}
	}
	if t, ok := parseFlexibleDateString(raw); ok {
		return t.Format("2006-01-02"), ""
	}
	return "", raw
}

func formatSalaryHireDateDept(raw string) string {
	raw = strings.TrimSpace(raw)
	if raw == "" || isSalaryEmptyToken(raw) {
		return ""
	}
	if formatted := formatExcelDateSerial(raw); formatted != "" {
		return formatted
	}
	// Excel 序列号 + 部门，如 44927-技术部
	if idx := strings.Index(raw, "-"); idx > 0 {
		head := strings.TrimSpace(raw[:idx])
		tail := strings.TrimSpace(raw[idx+1:])
		if formatted := formatExcelDateSerial(head); formatted != "" {
			if tail != "" {
				return formatted + "-" + tail
			}
			return formatted
		}
	}
	// 2023-01-01-部门
	if datePart, rest := splitLeadingDatePart(raw); datePart != "" {
		if rest != "" && rest != raw {
			return datePart + "-" + rest
		}
		return datePart
	}
	return raw
}

func isSalaryDateHeader(header string) bool {
	h := strings.TrimSpace(header)
	if h == "" {
		return false
	}
	if strings.Contains(h, "入职日期") || strings.Contains(h, "入职时间") {
		return true
	}
	if strings.Contains(h, "日期-部门") || strings.Contains(h, "入职") && strings.Contains(h, "部门") {
		return true
	}
	return false
}

func formatSalaryCellDisplay(header, val string) string {
	val = strings.TrimSpace(val)
	if val == "" || isSalaryEmptyToken(val) {
		return ""
	}
	if isSalaryDateHeader(header) {
		return formatSalaryHireDateDept(val)
	}
	if formatted := formatExcelDateSerial(val); formatted != "" {
		return formatted
	}
	return val
}

func isSalaryEmptyToken(s string) bool {
    switch strings.TrimSpace(s) {
    case "", "(空)", "空", "-", "--", "—", "N/A", "n/a", "NULL", "null", "无", "暂无":
        return true
    default:
        return false
    }
}

// getEmployeeNameMap 获取员工姓名映射（兼容旧调用）
func (h *AdminHandler) getEmployeeNameMap(ctx context.Context) (map[string]*EmployeeInfo, error) {
    userLookup, err := h.getSalaryUserLookupMap(ctx)
    if err != nil {
        return nil, err
    }
    out := make(map[string]*EmployeeInfo, len(userLookup))
    for key, m := range userLookup {
        if m == nil || m.EmployeeID == "" {
            continue
        }
        out[key] = &EmployeeInfo{
            ID:       m.EmployeeID,
            Name:     m.EmployeeName,
            Position: m.Position,
        }
    }
    return out, nil
}

// 辅助函数
func getColumnValue(row []string, idx int) string {
    if idx >= 0 && idx < len(row) {
        return strings.TrimSpace(row[idx])
    }
    return ""
}

func parseSalaryFloat(s string) (float64, error) {
    s = strings.TrimSpace(s)
    if isSalaryEmptyToken(s) {
        return 0, nil
    }
    s = strings.TrimPrefix(s, "¥")
    s = strings.TrimPrefix(s, "$")
    s = strings.ReplaceAll(s, ",", "")
    return strconv.ParseFloat(s, 64)
}

// ==================== 绩效管理（增强版：添加修改删除日志） ====================
// UpdatePerformance 更新单条绩效记录
func (h *AdminHandler) UpdatePerformance(c *gin.Context) {
    var req struct {
        EmployeeID  string      `json:"employee_id"`
        Month       string      `json:"month"`
        TotalScore  int         `json:"total_score"`
        Grade       string      `json:"grade"`
        ScoreRecords interface{} `json:"score_records"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }

    // 获取旧值用于日志（同时获取员工ID用于后续查询）
    var oldTotalScore int
    var oldGrade string
    var employeeID, employeeName string
    err := h.db.QueryRow(`
        SELECT employee_id, employee_name, total_score, grade 
        FROM performance_records 
        WHERE employee_id = $1 AND month = $2
    `, req.EmployeeID, req.Month).Scan(&employeeID, &employeeName, &oldTotalScore, &oldGrade)
    if err != nil && err != sql.ErrNoRows {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // 序列化 score_records
    scoreRecordsJSON, _ := json.Marshal(req.ScoreRecords)

    // 执行更新
    _, err = h.db.Exec(`
        UPDATE performance_records 
        SET total_score = $1, grade = $2, score_records = $3, updated_at = NOW()
        WHERE employee_id = $4 AND month = $5
    `, req.TotalScore, req.Grade, string(scoreRecordsJSON), req.EmployeeID, req.Month)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }

    // ✅ 修复：更新后重新查询最新的员工姓名
    var latestEmployeeName string
    err = h.db.QueryRow(`
        SELECT e.name 
        FROM performance_records p
        JOIN employees e ON p.employee_id = e.id
        WHERE p.employee_id = $1 AND p.month = $2
    `, req.EmployeeID, req.Month).Scan(&latestEmployeeName)
    if err == nil && latestEmployeeName != "" {
        employeeName = latestEmployeeName
    } else {
        // 降级方案：使用绩效表中存储的姓名
        _ = h.db.QueryRow(`
            SELECT employee_name FROM performance_records 
            WHERE employee_id = $1 AND month = $2
        `, req.EmployeeID, req.Month).Scan(&employeeName)
    }

    month := c.Param("month")
    if month == "" {
        month = req.Month
    }

    // 记录操作日志（现在使用最新数据）
    Log(c, "UPDATE", "PERFORMANCE",
        fmt.Sprintf("修改绩效考核：员工 %s，%s 月，分数 %d→%d，等级 %s→%s",
            employeeName, month, oldTotalScore, req.TotalScore, oldGrade, req.Grade),
        req.EmployeeID, employeeName)

    models.Send(c, 200, 0, "Performance updated", nil)
}

// DeletePerformance 删除绩效记录
func (h *AdminHandler) DeletePerformance(c *gin.Context) {
    employeeID := c.Param("employeeId")
    month := c.Param("month")
    
    if employeeID == "" || month == "" {
        models.SendError(c, 400, 1001, "employeeId and month are required")
        return
    }
    
    // 获取员工姓名用于日志
    var employeeName string
    var oldTotalScore int
    h.db.QueryRow(`
        SELECT employee_name, total_score 
        FROM performance_records 
        WHERE employee_id = $1 AND month = $2
    `, employeeID, month).Scan(&employeeName, &oldTotalScore)
    
    _, err := h.db.Exec(`
        DELETE FROM performance_records 
        WHERE employee_id = $1 AND month = $2
    `, employeeID, month)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    
    // ✅ 记录操作日志
    Log(c, "DELETE", "PERFORMANCE",
        fmt.Sprintf("删除绩效考核：员工 %s，%s 月（原分数 %d）", employeeName, month, oldTotalScore),
        employeeID, employeeName)
    
    models.Send(c, 200, 0, "Performance deleted", nil)
}

// UpdatePenaltyRecord 更新罚款记录
func (h *AdminHandler) UpdatePenaltyRecord(c *gin.Context) {
    id := c.Param("id")
    
    var req struct {
        Amount      float64 `json:"amount"`
        Category    string  `json:"category"`
        Reason      string  `json:"reason"`
        PenaltyDate string  `json:"penalty_date"`
    }
    if err := c.ShouldBindJSON(&req); err != nil {
        models.SendError(c, 400, 1001, err.Error())
        return
    }
    
    // 获取旧值用于日志
    var oldAmount float64
    var oldCategory, oldReason, employeeName string
    err := h.db.QueryRow(`
        SELECT employee_name, amount, category, reason 
        FROM penalty_records WHERE id = $1
    `, id).Scan(&employeeName, &oldAmount, &oldCategory, &oldReason)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    
    // 执行更新
    _, err = h.db.Exec(`
        UPDATE penalty_records 
        SET amount = $1, category = $2, reason = $3, penalty_date = $4
        WHERE id = $5
    `, req.Amount, req.Category, req.Reason, req.PenaltyDate, id)
    if err != nil {
        models.SendError(c, 500, 5000, err.Error())
        return
    }
    
    // ✅ 修复：更新后重新查询最新的员工姓名
    var latestEmployeeName string
    err = h.db.QueryRow(`
        SELECT employee_name FROM penalty_records WHERE id = $1
    `, id).Scan(&latestEmployeeName)
    if err == nil && latestEmployeeName != "" {
        employeeName = latestEmployeeName  // 使用最新的员工姓名
    }
    
    // 记录操作日志（现在使用最新数据）
    Log(c, "UPDATE", "PENALTY",
        fmt.Sprintf("修改罚款：员工 %s，金额 ¥%.2f→¥%.2f，类型 %s",
            employeeName, oldAmount, req.Amount, req.Category),
        id, employeeName)
    
    models.Send(c, 200, 0, "Penalty record updated", nil)
}

// ==================== 仪表盘：今日休假/请假/旷工人员 ====================

// TodayAbsenteeItem 今日异常考勤人员项
type TodayAbsenteeItem struct {
	EmployeeID   string `json:"employeeId"`
	EmployeeName string `json:"employeeName"`
	Position     string `json:"position"`
	Status       string `json:"status"`
	StatusLabel  string `json:"statusLabel"`
	Date         string `json:"date"`
}

// TodayAbsenteesResponse 今日异常考勤响应
type TodayAbsenteesResponse struct {
	Vacation []TodayAbsenteeItem `json:"vacation"` // 休假（全天+半天）
	Leave    []TodayAbsenteeItem `json:"leave"`    // 请假
	Absent   []TodayAbsenteeItem `json:"absent"`   // 旷工
	Total    int                 `json:"total"`
}

// GetTodayAbsentees 获取今日休假/请假/旷工人员列表
func (h *AdminHandler) GetTodayAbsentees(c *gin.Context) {
	today := time.Now().Format("2006-01-02")
	yearMonth := time.Now().Format("2006-01")

	// 查询今日有考勤记录且状态为休假/请假/旷工的员工
	query := `
		SELECT 
			e.id,
			e.employee_id,
			e.name,
			COALESCE(e.position, '') as position,
			ar.status,
			ar.date
		FROM employees e
		INNER JOIN attendance_records ar ON e.id = ar.employee_id
		WHERE ar.year_month = $1 
			AND ar.date = $2
			AND ar.status IN ('rest_full', 'rest_half', 'leave', 'absent')
		ORDER BY 
			CASE ar.status
				WHEN 'absent' THEN 1
				WHEN 'leave' THEN 2
				WHEN 'rest_full' THEN 3
				WHEN 'rest_half' THEN 4
				ELSE 5
			END,
			e.name
	`

	rows, err := h.db.QueryContext(c.Request.Context(), query, yearMonth, today)
	if err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}
	defer rows.Close()

	var vacationList []TodayAbsenteeItem
	var leaveList []TodayAbsenteeItem
	var absentList []TodayAbsenteeItem

	for rows.Next() {
		var id, employeeID, name, position, status, date string
		if err := rows.Scan(&id, &employeeID, &name, &position, &status, &date); err != nil {
			continue
		}

		item := TodayAbsenteeItem{
			EmployeeID:   employeeID,
			EmployeeName: name,
			Position:     position,
			Status:       status,
			StatusLabel:  getStatusLabel(status),
			Date:         date,
		}

		switch status {
		case "rest_full", "rest_half":
			vacationList = append(vacationList, item)
		case "leave":
			leaveList = append(leaveList, item)
		case "absent":
			absentList = append(absentList, item)
		}
	}

	response := TodayAbsenteesResponse{
		Vacation: vacationList,
		Leave:    leaveList,
		Absent:   absentList,
		Total:    len(vacationList) + len(leaveList) + len(absentList),
	}

	models.Send(c, 200, 0, "success", response)
}

// GetTodayAttendanceRate 统计当天出勤率（全员，不受分页影响）
func (h *AdminHandler) GetTodayAttendanceRate(c *gin.Context) {
	today := time.Now().Format("2006-01-02")
	yearMonth := time.Now().Format("2006-01")

	query := `
		WITH eligible AS (
			SELECT e.id
			FROM employees e
			WHERE e.status = 1
			  AND NOT EXISTS (
				SELECT 1 FROM attendance_records r
				WHERE r.employee_id = e.id
				  AND r.status = 'resigned'
				  AND r.year_month < $1
			  )
			  AND NOT EXISTS (
				SELECT 1 FROM attendance_records r
				WHERE r.employee_id = e.id
				  AND r.status = 'resigned'
				  AND r.year_month = $1
				  AND r.date <= $2
			  )
		)
		SELECT
			COUNT(eligible.id) AS total,
			COALESCE(SUM(
				CASE
					WHEN ar.status IN ('work', 'working') THEN 1.0
					WHEN ar.status IN ('rest_half', 'leave') THEN 0.5
					ELSE 0.0
				END
			), 0) AS points
		FROM eligible
		LEFT JOIN attendance_records ar
			ON ar.employee_id = eligible.id
			AND ar.year_month = $1
			AND ar.date = $2
	`

	var total int
	var points float64
	if err := h.db.QueryRowContext(c.Request.Context(), query, yearMonth, today).Scan(&total, &points); err != nil {
		models.SendError(c, 500, 5000, err.Error())
		return
	}

	rate := 0
	if total > 0 {
		rate = int(math.Round(points / float64(total) * 100))
	}

	models.Send(c, 200, 0, "success", gin.H{
		"date":   today,
		"rate":   rate,
		"total":  total,
		"points": points,
	})
}

// getStatusLabel 获取状态的中文标签
func getStatusLabel(status string) string {
	switch status {
	case "rest_full":
		return "全天休假"
	case "rest_half":
		return "半天休假"
	case "leave":
		return "请假"
	case "absent":
		return "旷工"
	default:
		return status
	}
}
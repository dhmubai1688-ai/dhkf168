package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"tg-attendance/backend/services"
)

// WebSocketAuth — ticket 优先；生产环境 WS_TICKET_REQUIRED 禁用 JWT fallback
func WebSocketAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		if tickets := extractWSTicketCandidates(c); len(tickets) > 0 {
			sess, ok := redeemWSTicketCandidates(c, tickets)
			if !ok {
				return
			}
			if sess.SubjectType != services.SessionSubjectUser {
				c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "User session required"})
				return
			}
			c.Next()
			return
		}

		if services.WSTicketRequired() {
			logWSAuthFailure(c, "WS ticket required", nil)
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "WS ticket required"})
			return
		}

		token := extractWSToken(c)
		if token == "" {
			logWSAuthFailure(c, "Missing ticket or token", nil)
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing ticket or token"})
			return
		}

		if !authenticateSessionJWT(c, token, true, false) {
			return
		}
		c.Next()
	}
}

// AgentWebSocketAuth — ticket 优先；生产环境禁用 JWT fallback
func AgentWebSocketAuth(_ *redis.Client) gin.HandlerFunc {
	return func(c *gin.Context) {
		deviceID := strings.TrimSpace(c.Query("deviceId"))
		if deviceID == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing deviceId"})
			return
		}

		if tickets := extractWSTicketCandidates(c); len(tickets) > 0 {
			sess, ok := redeemWSTicketCandidates(c, tickets)
			if !ok {
				return
			}
			if sess.SubjectType != services.SessionSubjectDevice || sess.SubjectID.String() != deviceID {
				c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "Ticket device mismatch"})
				return
			}
			c.Next()
			return
		}

		if services.WSTicketRequired() {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "WS ticket required"})
			return
		}

		token := extractWSToken(c)
		if token == "" {
			c.AbortWithStatusJSON(401, gin.H{"code": 1002, "message": "Missing ticket or token"})
			return
		}

		if !authenticateSessionJWT(c, token, false, true) {
			return
		}
		if c.GetString("deviceID") != deviceID {
			c.AbortWithStatusJSON(403, gin.H{"code": 1003, "message": "Device ID mismatch"})
			return
		}
		c.Next()
	}
}

// extractWSToken reads session JWT for WebSocket fallback (dev / WS_TICKET_REQUIRED=false).
// Browser WebSocket handshakes cannot set Authorization; query token is allowed here only.
func extractWSToken(c *gin.Context) string {
	if token := strings.TrimSpace(c.Query("token")); token != "" {
		return token
	}
	return extractToken(c)
}

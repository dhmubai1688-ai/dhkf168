package main

import (
	"bytes"
	"context"
	"encoding/json"
	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"tg-attendance/backend/handlers"
	"tg-attendance/backend/internal/standalone"
	"tg-attendance/backend/middleware"
	"tg-attendance/backend/models"
	"tg-attendance/backend/services"
	"time"
)

func main() {
	_ = godotenv.Load()
	if os.Getenv("PORT") == "" {
		os.Setenv("PORT", "8080")
	}
	if len(os.Getenv("ADMIN_PASSWORD")) < 12 || len(os.Getenv("TELEGRAM_TOKEN_SECRET")) < 32 {
		log.Fatal("Set ADMIN_PASSWORD (12+ characters) and TELEGRAM_TOKEN_SECRET (32+ characters)")
	}
	os.Setenv("CAPTURE_LINKED_TO_CHECKIN", "false")
	if os.Getenv("ENV") == "production" {
		gin.SetMode(gin.ReleaseMode)
	}
	// Bound all legacy HTTP calls; no independent polling process or Redis required.
	http.DefaultClient.Timeout = 20 * time.Second
	db, err := services.OpenAttendanceDatabase()
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	middleware.InitPermissionDB(db)
	middleware.InitEmployeeScopeDB(db)
	workforce := services.NewWorkforceService(db)
	tg := services.NewWorkforceTelegramService(db, workforce)
	settings, err := tg.GetSettings(context.Background())
	if err != nil {
		log.Fatal(err)
	}
	changes := map[string]interface{}{"requirePCLogin": false, "captureLinkedToCheckin": false, "botMode": "webhook"}
	public := strings.TrimRight(os.Getenv("PUBLIC_BASE_URL"), "/")
	if public == "" {
		public = strings.TrimRight(os.Getenv("RENDER_EXTERNAL_URL"), "/")
	}
	if public != "" {
		changes["webhookUrl"] = public + "/telegram/webhook"
	}
	if token := os.Getenv("TELEGRAM_BOT_TOKEN"); token != "" {
		changes["botToken"] = token
	}
	if !settings.HasWebhookSecret {
		changes["regenerateWebhookSecret"] = true
	}
	if _, err = tg.UpdateSettings(context.Background(), changes); err != nil {
		log.Fatal(err)
	}
	tgHandler := handlers.NewWorkforceTelegramHandler(db, tg, nil)
	adminHandler := handlers.NewAdminHandler(db, workforce, services.NewPerformancePushService(db), services.NewPenaltyPushService(db), nil, nil, nil)
	workforceHandler := handlers.NewWorkforceHandler(db, workforce, tg, services.NewUserRepository(db), services.NewDeviceRepository(db), nil)
	handlers.GlobalLogger = handlers.NewOperationLogHandler(db)
	inbox := &standalone.Inbox{DB: db, TG: tg, Wake: make(chan struct{}, 1)}
	r := gin.New()
	r.Use(gin.Recovery())
	_ = r.SetTrustedProxies(nil)
	r.Use(func(c *gin.Context) {
		c.Header("X-Content-Type-Options", "nosniff")
		c.Header("X-Frame-Options", "DENY")
		c.Header("Referrer-Policy", "same-origin")
		if strings.HasPrefix(c.Request.URL.Path, "/api/") {
			c.Header("Cache-Control", "no-store")
		}
		c.Request.Body = http.MaxBytesReader(c.Writer, c.Request.Body, 12<<20)
		c.Next()
	})
	r.GET("/health", func(c *gin.Context) { c.JSON(200, gin.H{"status": "ok"}) })
	r.POST("/telegram/webhook", inbox.Accept)
	a := standalone.Auth{DB: db}
	api := r.Group("/api/v1")
	authAPI := api.Group("", standalone.SameOrigin())
	authAPI.POST("/auth/login", a.Login)
	protected := authAPI.Group("", a.Require())
	protected.GET("/auth/me", a.Me)
	protected.POST("/auth/logout", a.Logout)
	protected.POST("/standalone/webhook", inbox.RegisterWebhook)
	protected.GET("/standalone/status", inbox.Status)
	protected.GET("/standalone/exports", inbox.Exports)
	protected.GET("/standalone/exports/:filename", inbox.DownloadExport)
	protected.POST("/standalone/inbox/:id/resolve", inbox.Resolve)
	protected.GET("/meta/modules", func(c *gin.Context) {
		models.Send(c, 200, 0, "success", gin.H{"telegramAttendance": true, "telegram": true, "attendance": true, "modules": gin.H{"telegramAttendance": true}})
	})
	protected.GET("/devices", func(c *gin.Context) { models.Send(c, 200, 0, "success", gin.H{"items": []interface{}{}, "total": 0}) })
	admin := protected.Group("/admin")
	registerAdminRoutes(admin, tgHandler, adminHandler, workforceHandler)
	// This deployment always uses webhook and has no PC-agent prerequisite.

	worker := api.Group("/telegram/worker", middleware.TelegramWorkerAuth(tg), func(c *gin.Context) {
		if raw := c.GetHeader("X-TG-Event-Time"); raw != "" {
			if n, e := strconv.ParseInt(raw, 10, 64); e == nil && n > 0 && n <= time.Now().Add(time.Minute).Unix() {
				c.Request = c.Request.WithContext(services.WithPunchTime(c.Request.Context(), time.Unix(n, 0)))
			}
		}
		c.Next()
	})
	registerWorkerRoutes(worker, tgHandler)
	dist := os.Getenv("FRONTEND_DIST")
	if dist == "" {
		dist = "../frontend/dist"
	}
	r.Static("/assets", filepath.Join(dist, "assets"))
	r.NoRoute(func(c *gin.Context) {
		if c.Request.Method != "GET" || strings.HasPrefix(c.Request.URL.Path, "/api/") {
			c.Status(404)
			return
		}
		c.File(filepath.Join(dist, "index.html"))
	})
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	srv := &http.Server{Addr: ":" + os.Getenv("PORT"), Handler: r, ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 120 * time.Second, IdleTimeout: 60 * time.Second}
	go func() {
		if e := srv.ListenAndServe(); e != nil && e != http.ErrServerClosed {
			log.Fatal(e)
		}
	}()
	go inbox.Run(ctx)
	inbox.Notify()
	// Timers are best effort while awake; recovery remains available after sleep.
	// Maintenance is serialized by the inbox owner, after queued updates.
	// Registration/reconfiguration is explicit in the admin UI, never reset webhook on each cold start.
	log.Printf("TG Attendance listening on %s", srv.Addr)
	<-ctx.Done()
	shutdown, cancel := context.WithTimeout(context.Background(), 25*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutdown)
}
func forceWebhookSettings() gin.HandlerFunc {
	return func(c *gin.Context) {
		body, e := io.ReadAll(c.Request.Body)
		if e != nil {
			c.AbortWithStatus(400)
			return
		}
		var in map[string]interface{}
		if json.Unmarshal(body, &in) != nil || in == nil {
			c.AbortWithStatus(400)
			return
		}
		in["botMode"] = "webhook"
		in["requirePCLogin"] = false
		in["captureLinkedToCheckin"] = false
		public := strings.TrimRight(os.Getenv("PUBLIC_BASE_URL"), "/")
		if public == "" {
			public = strings.TrimRight(os.Getenv("RENDER_EXTERNAL_URL"), "/")
		}
		if public != "" {
			in["webhookUrl"] = public + "/telegram/webhook"
		}
		body, _ = json.Marshal(in)
		c.Request.Body = io.NopCloser(bytes.NewReader(body))
		c.Next()
	}
}

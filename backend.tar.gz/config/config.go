package config

import (
	"log"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

var (
	corsProvider   func() []string
	corsProviderMu sync.RWMutex
)

// SetCorsOriginsProvider registers runtime CORS origin resolver (database + env).
func SetCorsOriginsProvider(provider func() []string) {
	corsProviderMu.Lock()
	corsProvider = provider
	corsProviderMu.Unlock()
}

// AllowedOrigins 返回 CORS / WebSocket 允许的 Origin 列表
func AllowedOrigins() []string {
	corsProviderMu.RLock()
	provider := corsProvider
	corsProviderMu.RUnlock()
	if provider != nil {
		return provider()
	}

	raw := strings.TrimSpace(os.Getenv("CORS_ALLOWED_ORIGINS"))
	if raw == "" {
		if os.Getenv("ENV") != "production" {
			return []string{
				"http://localhost:5173",
				"http://localhost:3000",
				"http://127.0.0.1:5173",
				"http://127.0.0.1:3000",
			}
		}
		return nil
	}

	parts := strings.Split(raw, ",")
	origins := make([]string, 0, len(parts))
	for _, part := range parts {
		if o := strings.TrimSpace(part); o != "" {
			origins = append(origins, o)
		}
	}
	return origins
}

// normalizeOrigin 规范化 Origin，便于 http:80 / https:443 与省略端口的写法互通
func normalizeOrigin(origin string) string {
	origin = strings.TrimSpace(origin)
	if origin == "" {
		return ""
	}

	u, err := url.Parse(origin)
	if err != nil {
		return strings.TrimRight(strings.ToLower(origin), "/")
	}

	scheme := strings.ToLower(u.Scheme)
	host := strings.ToLower(u.Hostname())
	port := u.Port()

	switch {
	case port == "" && scheme == "https":
		port = "443"
	case port == "" && scheme == "http":
		port = "80"
	}

	if (scheme == "http" && port == "80") || (scheme == "https" && port == "443") {
		return scheme + "://" + host
	}
	return scheme + "://" + host + ":" + port
}

// IsOriginAllowed 校验 Origin（空 Origin 允许，兼容非浏览器客户端）
func IsOriginAllowed(origin string) bool {
	origin = strings.TrimSpace(origin)
	if origin == "" {
		return true
	}

	normalized := normalizeOrigin(origin)
	for _, allowed := range AllowedOrigins() {
		if strings.EqualFold(normalizeOrigin(allowed), normalized) {
			return true
		}
	}
	return false
}

// LogOriginRejected 记录被拒绝的 WebSocket/CORS Origin（便于生产排错）
func LogOriginRejected(origin string) {
	allowed := AllowedOrigins()
	if len(allowed) == 0 {
		log.Printf("[CORS] Origin rejected: %q (CORS_ALLOWED_ORIGINS is empty in production)", origin)
		return
	}
	log.Printf("[CORS] Origin rejected: %q (allowed: %v)", origin, allowed)
}

// LiveKitConfig holds LiveKit connection and token settings.
type LiveKitConfig struct {
	URL              string
	APIHost          string
	RTMPBaseURL      string
	WHIPBaseURL      string
	PublishProtocol  string // whip | rtmp | auto
	APIKey           string
	APISecret        string
	TokenTTL         time.Duration
	MaxViewersPerDev int
	StartingTimeout  time.Duration
	PublisherGrace       time.Duration
	LifecycleDiagEnabled bool
}

func LoadLiveKitConfig() LiveKitConfig {
	ttlMinutes := 480
	if v := os.Getenv("REMOTE_VIEW_TOKEN_TTL_MINUTES"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			ttlMinutes = n
		}
	}

	maxViewers := 10
	if v := os.Getenv("REMOTE_VIEW_MAX_VIEWERS_PER_DEVICE"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			maxViewers = n
		}
	}

	startingTimeoutSec := 90
	if v := os.Getenv("REMOTE_VIEW_STARTING_TIMEOUT_SECONDS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			startingTimeoutSec = n
		}
	}

	publisherGraceSec := 45
	if v := os.Getenv("REMOTE_VIEW_PUBLISHER_GRACE_SECONDS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n >= 0 {
			publisherGraceSec = n
		}
	}

	url := strings.TrimSpace(os.Getenv("LIVEKIT_URL"))
	apiHost := strings.TrimSpace(os.Getenv("LIVEKIT_API_HOST"))
	if apiHost == "" {
		apiHost = deriveAPIHost(url)
	}

	protocol := strings.ToLower(strings.TrimSpace(os.Getenv("REMOTE_VIEW_PUBLISH_PROTOCOL")))
	if protocol == "" {
		protocol = "auto"
	}

	lifecycleDiag := strings.EqualFold(strings.TrimSpace(os.Getenv("REMOTE_VIEW_LIFECYCLE_DIAG")), "true") ||
		os.Getenv("REMOTE_VIEW_LIFECYCLE_DIAG") == "1"

	return LiveKitConfig{
		URL:                  url,
		APIHost:              apiHost,
		RTMPBaseURL:          strings.TrimSuffix(strings.TrimSpace(os.Getenv("LIVEKIT_RTMP_BASE_URL")), "/"),
		WHIPBaseURL:          strings.TrimSuffix(strings.TrimSpace(os.Getenv("LIVEKIT_WHIP_BASE_URL")), "/"),
		PublishProtocol:      protocol,
		APIKey:               strings.TrimSpace(os.Getenv("LIVEKIT_API_KEY")),
		APISecret:            strings.TrimSpace(os.Getenv("LIVEKIT_API_SECRET")),
		TokenTTL:             time.Duration(ttlMinutes) * time.Minute,
		MaxViewersPerDev:     maxViewers,
		StartingTimeout:      time.Duration(startingTimeoutSec) * time.Second,
		PublisherGrace:       time.Duration(publisherGraceSec) * time.Second,
		LifecycleDiagEnabled: lifecycleDiag,
	}
}

// ResolvePublishProtocol returns the effective publish protocol (whip or rtmp).
func (c LiveKitConfig) ResolvePublishProtocol() string {
	switch strings.ToLower(strings.TrimSpace(c.PublishProtocol)) {
	case "rtmp":
		return "rtmp"
	case "whip":
		return "whip"
	default: // auto
		if strings.TrimSpace(c.WHIPBaseURL) != "" {
			return "whip"
		}
		return "rtmp"
	}
}

// AllowRtmpFallback is false when REMOTE_VIEW_PUBLISH_PROTOCOL=whip (WHIP-only mode).
func (c LiveKitConfig) AllowRtmpFallback() bool {
	p := strings.ToLower(strings.TrimSpace(c.PublishProtocol))
	return p != "whip"
}

func (c LiveKitConfig) Enabled() bool {
	return c.URL != "" && c.APIKey != "" && c.APISecret != "" && c.APIHost != ""
}

func deriveAPIHost(wsURL string) string {
	if wsURL == "" {
		return ""
	}
	host := strings.TrimPrefix(wsURL, "wss://")
	host = strings.TrimPrefix(host, "ws://")
	host = strings.TrimPrefix(host, "https://")
	host = strings.TrimPrefix(host, "http://")
	if idx := strings.Index(host, "/"); idx >= 0 {
		host = host[:idx]
	}
	if host == "" {
		return ""
	}
	return "http://" + host
}

func RoomNameForDevice(deviceID string) string {
	return "rv-" + deviceID
}

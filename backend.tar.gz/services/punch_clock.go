package services

import (
	"context"
	"time"
)

type punchClockKey struct{}

func WithPunchTime(ctx context.Context, t time.Time) context.Context {
	return context.WithValue(ctx, punchClockKey{}, t)
}
func punchNow(ctx context.Context) time.Time {
	if t, ok := ctx.Value(punchClockKey{}).(time.Time); ok {
		return t
	}
	return time.Now()
}

package services

import (
	"bytes"
	"context"
	"database/sql"
	"github.com/google/uuid"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type fakeTelegramTransport struct{}

func (fakeTelegramTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(`{"ok":true,"result":{"id":999,"username":"local_test_bot","message_id":123}}`)), Header: make(http.Header)}, nil
}

// Uses ONLY an explicitly supplied disposable test database. No real Telegram calls.
func TestStandaloneAttendanceRoundTrip(t *testing.T) {
	dsn := os.Getenv("STANDALONE_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("set STANDALONE_TEST_DATABASE_URL to a disposable initialized database")
	}
	t.Setenv("TELEGRAM_TOKEN_SECRET", "local-test-encryption-key-not-production-123")
	old := http.DefaultClient
	http.DefaultClient = &http.Client{Transport: fakeTelegramTransport{}}
	defer func() { http.DefaultClient = old }()
	db, e := sql.Open("postgres", dsn)
	if e != nil {
		t.Fatal(e)
	}
	defer db.Close()
	db.SetMaxOpenConns(5)
	s := NewWorkforceTelegramService(db, NewWorkforceService(db))
	ctx := context.Background()
	_, e = s.UpdateSettings(ctx, map[string]interface{}{"enabled": true, "botToken": "999:test-only", "requirePCLogin": false, "shiftWindowDisabled": true, "dailyResetEnabled": false, "dualShiftEnabled": true, "botUiLang": "zh", "dayStart": "09:00", "dayEnd": "18:00", "nightStart": "21:00", "nightEnd": "09:00"})
	if e != nil {
		t.Fatal(e)
	}
	emp := uuid.New()
	tgID := time.Now().UnixNano()%1000000000 + 1000000000
	_, e = db.Exec(`INSERT INTO employees(id,employee_id,name,status,attendance_mode) VALUES($1,$2,'测试员工',1,'tg_only')`, emp, "it-"+emp.String()[:8])
	if e != nil {
		t.Fatal(e)
	}
	defer db.Exec("DELETE FROM employees WHERE id=$1", emp)
	if _, e = s.CreateBinding(ctx, emp, tgID, "testemployee", ""); e != nil {
		t.Fatal(e)
	}
	loc, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Now().In(loc)
	start := time.Date(now.Year(), now.Month(), now.Day(), 9, 0, 0, 0, loc)
	inCtx := WithPunchTime(ctx, start)
	checkin, _, _, _, _, reply, e := s.TelegramCheckIn(inCtx, tgID, "", "day")
	if e != nil {
		t.Fatal("checkin:", e)
	}
	if !strings.Contains(reply, "上班完成") {
		t.Fatal("original reply missing", reply)
	}
	var saved time.Time
	if e = db.QueryRow("SELECT checkin_time FROM work_sessions WHERE id=$1", checkin.SessionID).Scan(&saved); e != nil || !saved.Equal(start) {
		t.Fatal("cold start timestamp not preserved", saved, e)
	}
	if _, _, _, _, _, _, e = s.TelegramCheckIn(inCtx, tgID, "", "day"); e == nil {
		t.Fatal("duplicate checkin accepted")
	}
	act, e := s.TelegramStartActivity(WithPunchTime(ctx, start.Add(time.Hour)), tgID, "", "wc_small", 0)
	if e != nil {
		t.Fatal("activity:", e)
	}
	if !strings.Contains(act.GroupReplyHTML, "打卡成功") {
		t.Fatal("original activity reply missing")
	}
	if _, e = s.TelegramStartActivity(WithPunchTime(ctx, start.Add(time.Hour)), tgID, "", "eat", 0); e == nil {
		t.Fatal("overlapping activity accepted")
	}
	_, e = s.UpsertActivityFine(ctx, "wc_small", 5, 10)
	if e != nil {
		t.Fatal(e)
	}
	ended, e := s.TelegramEndActivity(WithPunchTime(ctx, start.Add(time.Hour+4*time.Minute)), tgID)
	if e != nil {
		t.Fatal("back:", e)
	}
	if ended.ElapsedSeconds != 240 || ended.OvertimeSeconds != 60 || ended.FineAmount != 10 {
		t.Fatalf("incorrect activity settlement: %+v", ended)
	}
	outAt := start.Add(9 * time.Hour)
	_, _, _, _, _, _, _, e = s.TelegramCheckOut(WithPunchTime(ctx, outAt), tgID, "")
	if e != nil {
		t.Fatal("checkout:", e)
	}
	if e = db.QueryRow("SELECT checkout_time FROM work_sessions WHERE id=$1", checkin.SessionID).Scan(&saved); e != nil || !saved.Equal(outAt) {
		t.Fatal("checkout event timestamp lost", saved, e)
	}
	// Cross-midnight retains the start day's business date.
	night := start.Add(12 * time.Hour)
	ci, _, _, _, _, _, e := s.TelegramCheckIn(WithPunchTime(ctx, night), tgID, "", "night")
	if e != nil {
		t.Fatal("night:", e)
	}
	if ci.Date != night.Format("2006-01-02") {
		t.Fatal("wrong night business date", ci.Date)
	}
	_, _, _, _, _, _, _, e = s.TelegramCheckOut(WithPunchTime(ctx, night.Add(12*time.Hour)), tgID, "")
	if e != nil {
		t.Fatal("night out:", e)
	}
	exportPath, e := s.exportBeforeReset(ctx, start.Format("2006-01-02"), start.Format("2006-01-02"), "")
	if e != nil {
		t.Fatal("durable export:", e)
	}
	defer os.Remove(exportPath)
	file, e := os.ReadFile(exportPath)
	if e != nil || len(file) < 100 || string(file[:2]) != "PK" {
		t.Fatal("invalid XLSX export", e)
	}
	var backup []byte
	if e = db.QueryRow("SELECT content FROM standalone_exports WHERE filename=$1", filepath.Base(exportPath)).Scan(&backup); e != nil || !bytes.Equal(file, backup) {
		t.Fatal("export backup mismatch", e)
	}
	defer db.Exec("DELETE FROM standalone_exports WHERE filename=$1", filepath.Base(exportPath))

}

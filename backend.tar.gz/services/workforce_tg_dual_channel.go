package services

import (
	"context"
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
)

const (
	AttendanceModeTGOnly        = "tg_only"
	AttendanceModePCTG          = "pc_tg"
	AttendanceModeSharedStation = "shared_station"
	TelegramChannelPersonal     = "personal"
	TelegramChannelWorkstation  = "workstation"

	PunchSourceTelegram = "telegram"
	PunchSourceAgent    = "agent"
	PunchSourceWeb      = "web"

	// punchAttendanceSourcesSQL matches all channels that create workforce punch sessions.
	punchAttendanceSourcesSQL = `IN ('telegram','agent','web')`
)

// TelegramActor is the resolved identity for a Telegram user action.
type TelegramActor struct {
	Channel         string
	EmployeeID      uuid.UUID
	DeviceID        uuid.UUID
	DeviceName      string
	RequiresPCLogin bool
	// PunchSource overrides DB/sync channel when set (e.g. web admin punch → "web").
	PunchSource string
}

func resolvePunchSource(actor *TelegramActor, fallback string) string {
	if actor != nil {
		if src := strings.TrimSpace(actor.PunchSource); src != "" {
			return src
		}
	}
	fallback = strings.TrimSpace(fallback)
	if fallback == "" {
		return PunchSourceTelegram
	}
	return fallback
}

type DeviceTelegramBindingRow struct {
	ID               uuid.UUID
	DeviceID         uuid.UUID
	DeviceName       string
	TelegramUserID   int64
	TelegramUsername string
	ChatID           string
	BoundAt          time.Time
	Status           int
	EmployeeID       uuid.UUID
	EmployeeName     string
	EmployeeCode     string
}

func (s *WorkforceTelegramService) getEmployeeAttendanceMode(ctx context.Context, empID uuid.UUID) (string, error) {
	var mode string
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(NULLIF(TRIM(attendance_mode), ''), 'pc_tg')
		FROM employees WHERE id = $1`, empID).Scan(&mode)
	if err == sql.ErrNoRows {
		return AttendanceModePCTG, ErrEmployeeNotFound
	}
	if err != nil {
		return AttendanceModePCTG, err
	}
	switch mode {
	case AttendanceModeTGOnly, AttendanceModePCTG, AttendanceModeSharedStation:
		return mode, nil
	default:
		return AttendanceModePCTG, nil
	}
}

func (s *WorkforceTelegramService) setEmployeeAttendanceMode(ctx context.Context, empID uuid.UUID, mode string) error {
	switch mode {
	case AttendanceModeTGOnly, AttendanceModePCTG, AttendanceModeSharedStation:
	default:
		return fmt.Errorf("invalid attendance mode")
	}
	_, err := s.db.ExecContext(ctx, `
		UPDATE employees SET attendance_mode = $2, updated_at = NOW() WHERE id = $1`, empID, mode)
	return err
}

type workstationTGDevice struct {
	ID   uuid.UUID
	Name string
}

func (s *WorkforceTelegramService) telegramUserBoundToWorkstation(ctx context.Context, telegramUserID int64) (uuid.UUID, string, error) {
	var deviceID uuid.UUID
	var deviceName string
	err := s.db.QueryRowContext(ctx, `
		SELECT b.device_id, COALESCE(d.hostname, '')
		FROM device_telegram_bindings b
		JOIN devices d ON d.id = b.device_id
		WHERE b.telegram_user_id = $1 AND b.status = 1
		ORDER BY b.bound_at DESC
		LIMIT 1`, telegramUserID).Scan(&deviceID, &deviceName)
	if err == sql.ErrNoRows {
		return uuid.Nil, "", nil
	}
	return deviceID, deviceName, err
}

func (s *WorkforceTelegramService) telegramUserHasWorkstationBinding(ctx context.Context, telegramUserID int64) (bool, error) {
	var n int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM device_telegram_bindings
		WHERE telegram_user_id = $1 AND status = 1`, telegramUserID).Scan(&n)
	return n > 0, err
}

func (s *WorkforceTelegramService) listWorkstationDevicesForTelegram(ctx context.Context, telegramUserID int64) ([]workstationTGDevice, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT b.device_id, COALESCE(d.hostname, '')
		FROM device_telegram_bindings b
		JOIN devices d ON d.id = b.device_id
		WHERE b.telegram_user_id = $1 AND b.status = 1
		ORDER BY d.last_seen_at DESC NULLS LAST, b.bound_at DESC`, telegramUserID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]workstationTGDevice, 0)
	for rows.Next() {
		var item workstationTGDevice
		if err := rows.Scan(&item.ID, &item.Name); err != nil {
			return nil, err
		}
		out = append(out, item)
	}
	return out, rows.Err()
}

func (s *WorkforceTelegramService) employeeIsSharedWorkstationMember(ctx context.Context, deviceID, employeeID uuid.UUID) (bool, error) {
	var n int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM wf_shared_workstation_members
		WHERE device_id = $1 AND employee_id = $2`, deviceID, employeeID).Scan(&n)
	if err != nil {
		return false, err
	}
	if n > 0 {
		return true, nil
	}
	var invited uuid.NullUUID
	err = s.db.QueryRowContext(ctx, `
		SELECT invited_employee_uuid FROM devices
		WHERE id = $1 AND COALESCE(is_shared_workstation, FALSE) = TRUE`, deviceID).Scan(&invited)
	if err == sql.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return invited.Valid && invited.UUID == employeeID, nil
}

func (s *WorkforceTelegramService) resolveWorkstationActorForTelegram(
	ctx context.Context, telegramUserID int64, preferredDeviceID uuid.UUID, deviceHint string,
) (*TelegramActor, error) {
	devices, err := s.listWorkstationDevicesForTelegram(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	if len(devices) == 0 {
		return nil, nil
	}

	if preferredDeviceID == uuid.Nil && strings.TrimSpace(deviceHint) != "" {
		matched, matchErr := matchWorkstationDeviceByHint(devices, deviceHint)
		if matchErr != nil {
			return nil, matchErr
		}
		preferredDeviceID = matched.ID
	}
	if preferredDeviceID != uuid.Nil {
		var target *workstationTGDevice
		for i := range devices {
			if devices[i].ID == preferredDeviceID {
				target = &devices[i]
				break
			}
		}
		if target == nil {
			return nil, ErrWorkstationDeviceNotBound
		}
		empID, loginErr := s.resolveWorkstationLoggedInEmployee(ctx, target.ID)
		if loginErr != nil {
			return nil, loginErr
		}
		return &TelegramActor{
			Channel:    TelegramChannelWorkstation,
			DeviceID:   target.ID,
			DeviceName: target.Name,
			EmployeeID: empID,
		}, nil
	}

	type loggedInDevice struct {
		device    workstationTGDevice
		empID     uuid.UUID
		sessionAt time.Time
		lastSeen  time.Time
	}
	loggedIn := make([]loggedInDevice, 0, len(devices))
	for _, device := range devices {
		empID, sessionAt, lastSeen, loginErr := s.resolveWorkstationLoggedInEmployeeDetail(ctx, device.ID)
		if loginErr == nil {
			loggedIn = append(loggedIn, loggedInDevice{
				device: device, empID: empID, sessionAt: sessionAt, lastSeen: lastSeen,
			})
			continue
		}
		if loginErr != ErrPCLoginRequired {
			return nil, loginErr
		}
	}
	if len(loggedIn) > 1 {
		// Ambiguous without a device-tagged button.
		return nil, ErrWorkstationDeviceRequired
	}
	if len(loggedIn) == 1 {
		return &TelegramActor{
			Channel:    TelegramChannelWorkstation,
			DeviceID:   loggedIn[0].device.ID,
			DeviceName: loggedIn[0].device.Name,
			EmployeeID: loggedIn[0].empID,
		}, nil
	}

	actor := &TelegramActor{
		Channel:         TelegramChannelWorkstation,
		RequiresPCLogin: true,
	}
	if len(devices) == 1 {
		actor.DeviceID = devices[0].ID
		actor.DeviceName = devices[0].Name
	}
	return actor, nil
}

func (s *WorkforceTelegramService) resolveWorkstationLoggedInEmployee(ctx context.Context, deviceID uuid.UUID) (uuid.UUID, error) {
	empID, _, _, err := s.resolveWorkstationLoggedInEmployeeDetail(ctx, deviceID)
	return empID, err
}

func (s *WorkforceTelegramService) resolveWorkstationLoggedInEmployeeDetail(
	ctx context.Context, deviceID uuid.UUID,
) (empID uuid.UUID, sessionAt, lastSeen time.Time, err error) {
	if deviceID == uuid.Nil {
		return uuid.Nil, time.Time{}, time.Time{}, ErrPCLoginRequired
	}
	var loggedIn uuid.UUID
	var sessionAtNull, lastSeenNull sql.NullTime
	err = s.db.QueryRowContext(ctx, `
		SELECT employee_uuid, employee_session_at, last_seen_at FROM devices
		WHERE id = $1 AND LOWER(status) = 'approved'`, deviceID).Scan(&loggedIn, &sessionAtNull, &lastSeenNull)
	if err == sql.ErrNoRows {
		return uuid.Nil, time.Time{}, time.Time{}, ErrPCLoginRequired
	}
	if err != nil {
		return uuid.Nil, time.Time{}, time.Time{}, err
	}
	if !sessionAtNull.Valid || loggedIn == uuid.Nil {
		return uuid.Nil, time.Time{}, time.Time{}, ErrPCLoginRequired
	}
	if lastSeenNull.Valid {
		lastSeen = lastSeenNull.Time
	}
	return loggedIn, sessionAtNull.Time, lastSeen, nil
}

func (s *WorkforceTelegramService) findSharedWorkstationDeviceForEmployee(ctx context.Context, empID uuid.UUID) (uuid.UUID, error) {
	var deviceID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT m.device_id FROM wf_shared_workstation_members m
		JOIN devices d ON d.id = m.device_id AND LOWER(d.status) = 'approved'
		WHERE m.employee_id = $1
		ORDER BY d.last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err == nil && deviceID != uuid.Nil {
		return deviceID, nil
	}
	if err != nil && err != sql.ErrNoRows {
		return uuid.Nil, err
	}
	err = s.db.QueryRowContext(ctx, `
		SELECT id FROM devices
		WHERE invited_employee_uuid = $1 AND COALESCE(is_shared_workstation, FALSE) = TRUE
			AND LOWER(status) = 'approved'
		ORDER BY last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&deviceID)
	if err == sql.ErrNoRows {
		return uuid.Nil, ErrWorkstationNotConfigured
	}
	return deviceID, err
}

func (s *WorkforceTelegramService) deviceIsSharedWorkstation(ctx context.Context, deviceID uuid.UUID) (bool, error) {
	var isShared bool
	var memberCount int
	err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(is_shared_workstation, FALSE),
			(SELECT COUNT(*) FROM wf_shared_workstation_members WHERE device_id = $1)
		FROM devices WHERE id = $1`, deviceID).Scan(&isShared, &memberCount)
	if err != nil {
		return false, err
	}
	return isShared || memberCount > 0, nil
}

// ResolveTelegramBinding returns how a TG account is bound without requiring PC login.
// Optional deviceID / deviceHint pins multi-device workstation TG to one PC.
func (s *WorkforceTelegramService) ResolveTelegramBinding(ctx context.Context, telegramUserID int64) (*TelegramActor, error) {
	return s.ResolveTelegramBindingWithDevice(ctx, telegramUserID, uuid.Nil, "")
}

func (s *WorkforceTelegramService) ResolveTelegramBindingWithDevice(
	ctx context.Context, telegramUserID int64, deviceID uuid.UUID, deviceHint string,
) (*TelegramActor, error) {
	if telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid telegram user id")
	}
	if actor, err := s.resolveWorkstationActorForTelegram(ctx, telegramUserID, deviceID, deviceHint); err != nil {
		return nil, err
	} else if actor != nil {
		return actor, nil
	}
	if deviceID != uuid.Nil || strings.TrimSpace(deviceHint) != "" {
		// Device pin only applies to workstation bindings.
		return nil, ErrWorkstationDeviceNotBound
	}
	empID, err := s.resolvePersonalTelegramEmployee(ctx, telegramUserID)
	if err != nil {
		return nil, err
	}
	return &TelegramActor{Channel: TelegramChannelPersonal, EmployeeID: empID}, nil
}

// ResolveTelegramActor resolves the employee for punch/activity commands.
func (s *WorkforceTelegramService) ResolveTelegramActor(ctx context.Context, telegramUserID int64) (*TelegramActor, error) {
	return s.ResolveTelegramActorWithDevice(ctx, telegramUserID, uuid.Nil, "")
}

func (s *WorkforceTelegramService) ResolveTelegramActorWithDevice(
	ctx context.Context, telegramUserID int64, deviceID uuid.UUID, deviceHint string,
) (*TelegramActor, error) {
	actor, err := s.ResolveTelegramBindingWithDevice(ctx, telegramUserID, deviceID, deviceHint)
	if err != nil {
		return nil, err
	}
	if actor.Channel == TelegramChannelWorkstation {
		if actor.EmployeeID == uuid.Nil {
			return actor, ErrPCLoginRequired
		}
		return actor, nil
	}
	return actor, nil
}

func ParseOptionalDeviceID(raw string) (uuid.UUID, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return uuid.Nil, nil
	}
	id, err := uuid.Parse(raw)
	if err != nil {
		return uuid.Nil, fmt.Errorf("invalid device id")
	}
	return id, nil
}

func (s *WorkforceTelegramService) resolvePersonalTelegramEmployee(ctx context.Context, telegramUserID int64) (uuid.UUID, error) {
	var empID uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT employee_id FROM employee_telegram_bindings
		WHERE telegram_user_id = $1 AND status = 1`, telegramUserID).Scan(&empID)
	if err == sql.ErrNoRows {
		return uuid.Nil, ErrTelegramNotBound
	}
	return empID, err
}

func (s *WorkforceTelegramService) employeeRequiresPCLogin(ctx context.Context, empID uuid.UUID, globalRequire bool) (bool, error) {
	mode, err := s.getEmployeeAttendanceMode(ctx, empID)
	if err != nil {
		return globalRequire, err
	}
	switch mode {
	case AttendanceModeTGOnly:
		return false, nil
	case AttendanceModeSharedStation:
		return true, nil
	default:
		return globalRequire, nil
	}
}

func (s *WorkforceTelegramService) updateTelegramChatID(ctx context.Context, actor *TelegramActor, chatID string) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" || actor == nil {
		return
	}
	if actor.Channel == TelegramChannelWorkstation && actor.DeviceID != uuid.Nil {
		if isTelegramGroupChatID(chatID) {
			_, _ = s.db.ExecContext(ctx, `
				UPDATE device_telegram_bindings SET chat_id = $1
				WHERE device_id = $2 AND status = 1`, chatID, actor.DeviceID)
		}
		return
	}
	if actor.EmployeeID != uuid.Nil {
		if isTelegramGroupChatID(chatID) {
			_, _ = s.db.ExecContext(ctx, `
				UPDATE employee_telegram_bindings SET chat_id = $1
				WHERE employee_id = $2 AND status = 1`, chatID, actor.EmployeeID)
			return
		}
		_, _ = s.db.ExecContext(ctx, `
			UPDATE employee_telegram_bindings SET chat_id = $1
			WHERE employee_id = $2 AND status = 1
			  AND COALESCE(NULLIF(TRIM(chat_id), ''), '') = ''`, chatID, actor.EmployeeID)
	}
}

// getChatIDForEmployee resolves the attendance group chat for PC→TG notifications and grace config.
func (s *WorkforceTelegramService) getChatIDForEmployee(ctx context.Context, empID uuid.UUID) string {
	return s.resolveNotifyChatID(ctx, empID, uuid.Nil)
}

func isTelegramGroupChatID(chatID string) bool {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return false
	}
	if strings.HasPrefix(chatID, "-") {
		return true
	}
	if n, err := strconv.ParseInt(chatID, 10, 64); err == nil && n < 0 {
		return true
	}
	return false
}

func (s *WorkforceTelegramService) chatIDFromDeviceBinding(ctx context.Context, deviceID uuid.UUID) string {
	if deviceID == uuid.Nil {
		return ""
	}
	var chatID string
	_ = s.db.QueryRowContext(ctx, `
		SELECT COALESCE(chat_id,'') FROM device_telegram_bindings
		WHERE device_id = $1 AND status = 1`, deviceID).Scan(&chatID)
	return strings.TrimSpace(chatID)
}

// resolveNotifyChatID picks the best Telegram chat for PC→TG group notifications.
func (s *WorkforceTelegramService) resolveNotifyChatID(ctx context.Context, empID, deviceID uuid.UUID) string {
	if empID == uuid.Nil && deviceID == uuid.Nil {
		return ""
	}

	if deviceID != uuid.Nil {
		if chatID := s.chatIDFromDeviceBinding(ctx, deviceID); chatID != "" && isTelegramGroupChatID(chatID) {
			return chatID
		}
	}

	var personalChat string
	if empID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings
			WHERE employee_id = $1 AND status = 1 ORDER BY updated_at DESC NULLS LAST LIMIT 1`, empID).Scan(&personalChat)
		personalChat = strings.TrimSpace(personalChat)
		if personalChat != "" && isTelegramGroupChatID(personalChat) {
			return personalChat
		}
	}

	if empID != uuid.Nil {
		var wsChat string
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(dtb.chat_id,'')
			FROM wf_shared_workstation_members m
			JOIN device_telegram_bindings dtb ON dtb.device_id = m.device_id AND dtb.status = 1
			WHERE m.employee_id = $1
			ORDER BY dtb.bound_at DESC NULLS LAST LIMIT 1`, empID).Scan(&wsChat)
		wsChat = strings.TrimSpace(wsChat)
		if wsChat != "" && isTelegramGroupChatID(wsChat) {
			return wsChat
		}
	}

	if deviceID != uuid.Nil {
		if chatID := s.chatIDFromDeviceBinding(ctx, deviceID); chatID != "" {
			return chatID
		}
	}

	if empID != uuid.Nil {
		var loggedInDevice uuid.UUID
		if err := s.db.QueryRowContext(ctx, `
			SELECT id FROM devices
			WHERE employee_uuid = $1 AND LOWER(status) = 'approved' AND employee_session_at IS NOT NULL
			ORDER BY last_seen_at DESC NULLS LAST LIMIT 1`, empID).Scan(&loggedInDevice); err == nil && loggedInDevice != uuid.Nil {
			if chatID := s.chatIDFromDeviceBinding(ctx, loggedInDevice); chatID != "" {
				return chatID
			}
		}
	}

	if personalChat != "" {
		return personalChat
	}

	if empID != uuid.Nil {
		var sessionChat string
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(source_chat_id,'') FROM work_sessions
			WHERE employee_id = $1 AND COALESCE(source_chat_id,'') != ''
			ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&sessionChat)
		if strings.TrimSpace(sessionChat) != "" {
			return strings.TrimSpace(sessionChat)
		}
	}

	if empID != uuid.Nil {
		var groupChat string
		_ = s.db.QueryRowContext(ctx, `
			SELECT g.chat_id FROM wf_telegram_groups g
			WHERE g.enabled = TRUE
			  AND EXISTS (
			    SELECT 1 FROM employee_telegram_bindings b
			    WHERE b.employee_id = $1 AND b.status = 1
			  )
			ORDER BY g.created_at DESC LIMIT 1`, empID).Scan(&groupChat)
		if strings.TrimSpace(groupChat) != "" {
			return strings.TrimSpace(groupChat)
		}
	}

	var groupCount int
	_ = s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM wf_telegram_groups WHERE enabled = TRUE`).Scan(&groupCount)
	if groupCount == 1 {
		var onlyChat string
		_ = s.db.QueryRowContext(ctx, `SELECT chat_id FROM wf_telegram_groups WHERE enabled = TRUE LIMIT 1`).Scan(&onlyChat)
		return strings.TrimSpace(onlyChat)
	}

	return ""
}

func (s *WorkforceTelegramService) resolveNotifyTelegramUID(ctx context.Context, empID, deviceID uuid.UUID) int64 {
	var tgUID int64
	if empID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(telegram_user_id,0) FROM employee_telegram_bindings
			WHERE employee_id = $1 AND status = 1 ORDER BY updated_at DESC NULLS LAST LIMIT 1`, empID).Scan(&tgUID)
	}
	if tgUID == 0 && deviceID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(telegram_user_id,0) FROM device_telegram_bindings
			WHERE device_id = $1 AND status = 1`, deviceID).Scan(&tgUID)
	}
	return tgUID
}

func preferredDeviceFromActor(actor *TelegramActor) uuid.UUID {
	if actor != nil && actor.Channel == TelegramChannelWorkstation && actor.DeviceID != uuid.Nil {
		return actor.DeviceID
	}
	return uuid.Nil
}

func (s *WorkforceTelegramService) getChatIDForActor(ctx context.Context, actor *TelegramActor) string {
	if actor == nil {
		return ""
	}
	var chatID string
	if actor.Channel == TelegramChannelWorkstation && actor.DeviceID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM device_telegram_bindings
			WHERE device_id = $1 AND status = 1`, actor.DeviceID).Scan(&chatID)
		return chatID
	}
	if actor.EmployeeID != uuid.Nil {
		_ = s.db.QueryRowContext(ctx, `
			SELECT COALESCE(chat_id,'') FROM employee_telegram_bindings
			WHERE employee_id = $1 AND status = 1`, actor.EmployeeID).Scan(&chatID)
	}
	return chatID
}

func (s *WorkforceTelegramService) ensureTelegramNotCrossBound(ctx context.Context, telegramUserID int64, targetChannel string) error {
	hasWorkstation, err := s.telegramUserHasWorkstationBinding(ctx, telegramUserID)
	if err != nil {
		return err
	}
	if hasWorkstation && targetChannel == TelegramChannelPersonal {
		return ErrTelegramBoundToWorkstation
	}
	if empID, err := s.resolvePersonalTelegramEmployee(ctx, telegramUserID); err != nil && err != ErrTelegramNotBound {
		return err
	} else if empID != uuid.Nil && targetChannel == TelegramChannelWorkstation {
		return ErrTelegramBoundToPersonal
	}
	return nil
}

func (s *WorkforceTelegramService) ListDeviceTelegramBindings(ctx context.Context, search string) ([]DeviceTelegramBindingRow, error) {
	search = strings.TrimSpace(search)
	query := `
		SELECT b.id, b.device_id, COALESCE(d.hostname,''), b.telegram_user_id,
			COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''), b.bound_at, b.status,
			m.employee_id, COALESCE(e.name,''), COALESCE(e.employee_id,'')
		FROM device_telegram_bindings b
		JOIN devices d ON d.id = b.device_id
		LEFT JOIN wf_shared_workstation_members m ON m.device_id = b.device_id
		LEFT JOIN employees e ON e.id = m.employee_id
		WHERE b.status = 1`
	args := []interface{}{}
	if search != "" {
		query += ` AND (d.hostname ILIKE $1 OR b.telegram_username ILIKE $1 OR b.telegram_user_id::text ILIKE $1
			OR e.name ILIKE $1 OR e.employee_id ILIKE $1)`
		args = append(args, "%"+search+"%")
	}
	query += ` ORDER BY b.bound_at DESC, e.name NULLS LAST`
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]DeviceTelegramBindingRow, 0)
	for rows.Next() {
		var row DeviceTelegramBindingRow
		var empID uuid.NullUUID
		if err := rows.Scan(&row.ID, &row.DeviceID, &row.DeviceName, &row.TelegramUserID,
			&row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status,
			&empID, &row.EmployeeName, &row.EmployeeCode); err != nil {
			continue
		}
		if empID.Valid {
			row.EmployeeID = empID.UUID
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) GetDeviceTelegramBindingByDevice(ctx context.Context, deviceID uuid.UUID) (int64, string, string, bool) {
	if deviceID == uuid.Nil {
		return 0, "", "", false
	}
	var tgUID int64
	var tgUser string
	var chatID string
	err := s.db.QueryRowContext(ctx, `
		SELECT telegram_user_id, COALESCE(telegram_username,''), COALESCE(chat_id,'')
		FROM device_telegram_bindings
		WHERE device_id = $1 AND status = 1`, deviceID).Scan(&tgUID, &tgUser, &chatID)
	if err != nil {
		return 0, "", "", false
	}
	return tgUID, tgUser, chatID, tgUID > 0
}

func (s *WorkforceTelegramService) GetDeviceTelegramBindingByID(ctx context.Context, id uuid.UUID) (*DeviceTelegramBindingRow, error) {
	var row DeviceTelegramBindingRow
	err := s.db.QueryRowContext(ctx, `
		SELECT b.id, b.device_id, COALESCE(d.hostname,''), b.telegram_user_id,
			COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''), b.bound_at, b.status
		FROM device_telegram_bindings b
		JOIN devices d ON d.id = b.device_id
		WHERE b.id = $1 AND b.status = 1`, id).
		Scan(&row.ID, &row.DeviceID, &row.DeviceName, &row.TelegramUserID,
			&row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status)
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("device binding not found")
	}
	if err != nil {
		return nil, err
	}
	return &row, nil
}

func (s *WorkforceTelegramService) ResolveLoggedInEmployeeOnDevice(ctx context.Context, deviceID uuid.UUID) (uuid.UUID, error) {
	return s.resolveWorkstationLoggedInEmployee(ctx, deviceID)
}

func (s *WorkforceTelegramService) DeleteDeviceTelegramBinding(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM device_telegram_bindings WHERE id = $1`, id)
	return err
}

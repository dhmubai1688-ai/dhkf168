package services

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"

	"tg-attendance/backend/security"
)

type WorkforceTelegramService struct {
	db          *sql.DB
	workforce   *WorkforceService
	wsHub       *WebSocketHub
	penaltyPush *PenaltyPushService
	agentNotify *AgentNotificationService
}

func NewWorkforceTelegramService(db *sql.DB, workforce *WorkforceService) *WorkforceTelegramService {
	return &WorkforceTelegramService{
		db:          db,
		workforce:   workforce,
		penaltyPush: NewPenaltyPushService(db),
	}
}

// mapLookupBool reads a boolean from a JSON map under any of the given keys.
// Accepts bool, 0/1 numbers, and common string forms so settings toggles are not
// silently ignored when the JSON type is not a strict bool.
func mapLookupBool(in map[string]interface{}, keys ...string) (bool, bool) {
	if in == nil {
		return false, false
	}
	for _, key := range keys {
		raw, exists := in[key]
		if !exists || raw == nil {
			continue
		}
		switch v := raw.(type) {
		case bool:
			return v, true
		case float64:
			return v != 0, true
		case json.Number:
			n, err := v.Int64()
			if err != nil {
				f, fErr := v.Float64()
				if fErr != nil {
					continue
				}
				return f != 0, true
			}
			return n != 0, true
		case int:
			return v != 0, true
		case int64:
			return v != 0, true
		case string:
			s := strings.TrimSpace(strings.ToLower(v))
			switch s {
			case "1", "true", "yes", "on":
				return true, true
			case "0", "false", "no", "off", "":
				return false, true
			}
		}
	}
	return false, false
}

func (s *WorkforceTelegramService) SetWebSocketHub(hub *WebSocketHub) {
	s.wsHub = hub
}

func (s *WorkforceTelegramService) SetAgentNotificationService(svc *AgentNotificationService) {
	s.agentNotify = svc
}

// pushAutoPenaltyNotify sends TG-generated fines to the 罚款推送频道 when enabled.
// Non-blocking; failures are logged and do not affect attendance flow.
func (s *WorkforceTelegramService) pushAutoPenaltyNotify(
	ctx context.Context,
	empID uuid.UUID,
	amount float64,
	category, reason, penaltyDate string,
) {
	if s == nil || s.penaltyPush == nil || amount <= 0 {
		return
	}
	var name, position string
	_ = s.db.QueryRowContext(ctx, `
		SELECT name, COALESCE(position,'') FROM employees WHERE id = $1`, empID).
		Scan(&name, &position)
	if strings.TrimSpace(name) == "" {
		return
	}
	rec := PenaltyPushRecord{
		Date:         strings.TrimSpace(penaltyDate),
		EmployeeID:   empID.String(),
		EmployeeName: name,
		Position:     position,
		Amount:       amount,
		Category:     category,
		Reason:       reason,
	}
	go func(r PenaltyPushRecord, eid uuid.UUID) {
		ok, err := s.penaltyPush.PushPenaltyRecord(context.Background(), r)
		if err != nil {
			log.Printf("[Telegram] auto penalty push failed category=%s emp=%s: %v", r.Category, r.EmployeeName, err)
			return
		}
		if ok {
			log.Printf("[Telegram] auto penalty push sent category=%s amount=%.2f emp=%s", r.Category, r.Amount, r.EmployeeName)
		}
		if s.agentNotify != nil {
			s.agentNotify.PushPenalty(eid, r.Amount, r.Category, r.Reason, r.Date, r.EmployeeName)
		}
	}(rec, empID)
}

type TelegramSettings struct {
	ID                    uuid.UUID
	Enabled               bool
	BotUsername           string
	BotID                 int64
	HasBotToken           bool
	Timezone              string
	DayStart              string
	DayEnd                string
	NightStart            string
	NightEnd              string
	MiddleStart           string
	MiddleEnd             string
	GraceMinutes          int
	GraceMinutesAfter     int
	CheckOutGraceBefore   int
	LateToleranceMinutes  int
	EarlyLeaveToleranceMinutes int
	DualShiftEnabled      bool
	TripleShiftEnabled    bool
	DailyResetTime        string
	DailyResetEnabled     bool
	DailyResetExecutionOffsetMinutes int
	ShiftWindowDisabled   bool
	WorkEndGraceMinutes   int
	WorkEndGraceAfter     int
	RequirePCLogin          bool
	CaptureLinkedToCheckin  bool
	// WebPunchOnly: when true, attendance is driven by web admin punch; TG/PC punch is rejected.
	WebPunchOnly            bool
	AdminTelegramUserIDs    string
	BotMode               string
	WebhookURL            string
	HasWebhookSecret      bool
	BotUILang             string
	// FineCurrency: ISO-like code for TG fine display (CNY/THB/USD). Amounts stay numeric.
	FineCurrency          string
	// ShowKeyboardInfoButtons: 我的记录 / 排行榜 / 导出数据 on the TG reply keyboard.
	ShowKeyboardInfoButtons bool
	UpdatedAt             time.Time
}

type TelegramGroupRow struct {
	ID                 uuid.UUID
	ChatID             string
	ChatTitle          string
	Enabled            bool
	ShiftGraceBefore   *int
	ShiftGraceAfter    *int
	CheckOutGraceBefore *int
	CheckOutGraceAfter  *int
	LateToleranceMinutes *int
	EarlyLeaveToleranceMinutes *int
	DailyResetTime     string
	BotUILang          string
	CreatedAt          time.Time
}

type TelegramBindingRow struct {
	ID               uuid.UUID
	EmployeeID       uuid.UUID
	EmployeeName     string
	EmployeeCode     string
	AttendanceMode   string
	TelegramUserID   int64
	TelegramUsername string
	ChatID           string
	BoundAt          time.Time
	Status           int
}

func (s *WorkforceTelegramService) IsActive(ctx context.Context) (bool, error) {
	if !TelegramAttendanceEnabled() {
		return false, nil
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return false, err
	}
	return settings.Enabled && settings.HasBotToken, nil
}

// IsWebPunchOnly reports whether TG/PC punch channels are disabled in favor of web admin punch.
func (s *WorkforceTelegramService) IsWebPunchOnly(ctx context.Context) bool {
	settings, err := s.GetSettings(ctx)
	if err != nil || settings == nil {
		return false
	}
	return settings.WebPunchOnly
}

// ensureAttendanceModuleAvailable allows web punch when web_punch_only is on even without bot token.
func (s *WorkforceTelegramService) ensureAttendanceModuleAvailable(ctx context.Context) error {
	if !TelegramAttendanceEnabled() {
		return ErrTelegramDisabled
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return err
	}
	if settings.WebPunchOnly {
		return nil
	}
	if !settings.Enabled || !settings.HasBotToken {
		return ErrTelegramDisabled
	}
	return nil
}

// rejectIfWebPunchOnly blocks TG Bot / PC agent punch when web-only mode is enabled.
func (s *WorkforceTelegramService) rejectIfWebPunchOnly(ctx context.Context) error {
	if s.IsWebPunchOnly(ctx) {
		return ErrWebPunchOnlyMode
	}
	return nil
}

// RejectIfWebPunchOnly is the exported form for HTTP handlers (PC agent checkout etc.).
func (s *WorkforceTelegramService) RejectIfWebPunchOnly(ctx context.Context) error {
	return s.rejectIfWebPunchOnly(ctx)
}

func (s *WorkforceTelegramService) GetSettings(ctx context.Context) (*TelegramSettings, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, enabled, COALESCE(bot_username,''), COALESCE(bot_id,0),
			CASE WHEN bot_token_enc IS NOT NULL AND bot_token_enc != '' THEN TRUE ELSE FALSE END,
			timezone, day_start, day_end, COALESCE(night_start,'21:00'), COALESCE(night_end,'09:00'),
			COALESCE(middle_start,'13:00'), COALESCE(middle_end,'01:00'),
			grace_minutes, COALESCE(grace_minutes_after, 360),
			COALESCE(check_out_grace_before, 120),
			COALESCE(late_tolerance_minutes, 0),
			COALESCE(early_leave_tolerance_minutes, 10),
			dual_shift_enabled, COALESCE(triple_shift_enabled, FALSE),
			COALESCE(daily_reset_time,'09:00'), COALESCE(daily_reset_enabled, TRUE),
			COALESCE(daily_reset_execution_offset_minutes, 120),
			COALESCE(shift_window_disabled, FALSE), COALESCE(work_end_grace_minutes, 5), COALESCE(work_end_grace_after, 360), COALESCE(require_pc_login, TRUE),
			COALESCE(capture_linked_to_checkin, FALSE),
			COALESCE(web_punch_only, FALSE),
			COALESCE(admin_telegram_user_ids,''),
			COALESCE(bot_mode,'polling'), COALESCE(webhook_url,''),
			CASE WHEN webhook_secret IS NOT NULL AND webhook_secret != '' THEN TRUE ELSE FALSE END,
			COALESCE(bot_ui_lang,'both'), COALESCE(NULLIF(TRIM(fine_currency), ''), 'CNY'),
			COALESCE(show_keyboard_info_buttons, FALSE), updated_at
		FROM wf_telegram_settings ORDER BY updated_at DESC, id DESC LIMIT 1`)
	var out TelegramSettings
	if err := row.Scan(&out.ID, &out.Enabled, &out.BotUsername, &out.BotID, &out.HasBotToken,
		&out.Timezone, &out.DayStart, &out.DayEnd, &out.NightStart, &out.NightEnd,
		&out.MiddleStart, &out.MiddleEnd,
		&out.GraceMinutes, &out.GraceMinutesAfter,
		&out.CheckOutGraceBefore, &out.LateToleranceMinutes, &out.EarlyLeaveToleranceMinutes,
		&out.DualShiftEnabled, &out.TripleShiftEnabled, &out.DailyResetTime, &out.DailyResetEnabled,
		&out.DailyResetExecutionOffsetMinutes,
		&out.ShiftWindowDisabled, &out.WorkEndGraceMinutes, &out.WorkEndGraceAfter, &out.RequirePCLogin, &out.CaptureLinkedToCheckin,
		&out.WebPunchOnly, &out.AdminTelegramUserIDs,
		&out.BotMode, &out.WebhookURL, &out.HasWebhookSecret, &out.BotUILang, &out.FineCurrency,
		&out.ShowKeyboardInfoButtons, &out.UpdatedAt); err != nil {
		return nil, err
	}
	out.FineCurrency = NormalizeFineCurrency(out.FineCurrency)
	if strings.TrimSpace(out.MiddleStart) == "" {
		out.MiddleStart = "13:00"
	}
	if strings.TrimSpace(out.MiddleEnd) == "" {
		out.MiddleEnd = "01:00"
	}
	return &out, nil
}

// MultiShiftEnabled reports whether day/night (and optionally middle) punch modes are on.
func (s *TelegramSettings) MultiShiftEnabled() bool {
	return s != nil && (s.DualShiftEnabled || s.TripleShiftEnabled)
}

// EnabledShiftTypes returns configured shift codes for export/filter/handover.
func (s *TelegramSettings) EnabledShiftTypes() []string {
	if s != nil && s.TripleShiftEnabled {
		return []string{"day", "middle", "night"}
	}
	if s != nil && s.DualShiftEnabled {
		return []string{"day", "night"}
	}
	return []string{"day"}
}

func (s *WorkforceTelegramService) UpdateSettings(ctx context.Context, in map[string]interface{}) (*TelegramSettings, error) {
	current, err := s.GetSettings(ctx)
	if err != nil {
		return nil, err
	}

	enabled := current.Enabled
	if v, ok := mapLookupBool(in, "enabled"); ok {
		enabled = v
	}
	timezone := current.Timezone
	if v, ok := in["timezone"].(string); ok && strings.TrimSpace(v) != "" {
		timezone = strings.TrimSpace(v)
	}
	dayStart := current.DayStart
	if v, ok := in["dayStart"].(string); ok && strings.TrimSpace(v) != "" {
		dayStart = strings.TrimSpace(v)
	}
	dayEnd := current.DayEnd
	if v, ok := in["dayEnd"].(string); ok && strings.TrimSpace(v) != "" {
		dayEnd = strings.TrimSpace(v)
	}
	grace := current.GraceMinutes
	if v, ok := in["graceMinutes"].(float64); ok {
		grace = int(v)
	}
	if v, ok := in["checkInGraceBefore"].(float64); ok {
		grace = int(v)
	}
	graceAfter := current.GraceMinutesAfter
	if v, ok := in["graceMinutesAfter"].(float64); ok {
		graceAfter = int(v)
	}
	if v, ok := in["checkInGraceAfter"].(float64); ok {
		graceAfter = int(v)
	}
	checkOutBefore := current.CheckOutGraceBefore
	if v, ok := in["checkOutGraceBefore"].(float64); ok {
		checkOutBefore = int(v)
	}
	lateTolerance := current.LateToleranceMinutes
	if v, ok := in["lateToleranceMinutes"].(float64); ok {
		lateTolerance = int(v)
	}
	if v, ok := in["graceMinutesAfter"].(float64); ok {
		if _, hasLate := in["lateToleranceMinutes"]; !hasLate {
			if _, hasCheckIn := in["checkInGraceAfter"]; !hasCheckIn {
				// legacy-only payload: graceMinutesAfter still updates both window and tolerance
				lateTolerance = int(v)
			}
		}
	}
	earlyLeave := current.EarlyLeaveToleranceMinutes
	if v, ok := in["earlyLeaveToleranceMinutes"].(float64); ok {
		earlyLeave = int(v)
	}
	if v, ok := in["workEndGraceMinutes"].(float64); ok {
		earlyLeave = int(v)
	}
	dual := current.DualShiftEnabled
	if v, ok := mapLookupBool(in, "dualShiftEnabled", "dual_shift_enabled"); ok {
		dual = v
	}
	triple := current.TripleShiftEnabled
	if v, ok := mapLookupBool(in, "tripleShiftEnabled", "triple_shift_enabled"); ok {
		triple = v
	}
	if triple {
		// Triple mode builds on dual UI/windows; keep dual on when triple is enabled.
		dual = true
	}
	nightStart := current.NightStart
	if v, ok := in["nightStart"].(string); ok && strings.TrimSpace(v) != "" {
		nightStart = strings.TrimSpace(v)
	}
	nightEnd := current.NightEnd
	if v, ok := in["nightEnd"].(string); ok && strings.TrimSpace(v) != "" {
		nightEnd = strings.TrimSpace(v)
	}
	middleStart := current.MiddleStart
	if strings.TrimSpace(middleStart) == "" {
		middleStart = "13:00"
	}
	if v, ok := in["middleStart"].(string); ok && strings.TrimSpace(v) != "" {
		middleStart = strings.TrimSpace(v)
	}
	middleEnd := current.MiddleEnd
	if strings.TrimSpace(middleEnd) == "" {
		middleEnd = "01:00"
	}
	if v, ok := in["middleEnd"].(string); ok && strings.TrimSpace(v) != "" {
		middleEnd = strings.TrimSpace(v)
	}
	dailyResetTime := current.DailyResetTime
	if v, ok := in["dailyResetTime"].(string); ok && strings.TrimSpace(v) != "" {
		dailyResetTime = strings.TrimSpace(v)
	}
	dailyResetEnabled := current.DailyResetEnabled
	if v, ok := mapLookupBool(in, "dailyResetEnabled", "daily_reset_enabled"); ok {
		dailyResetEnabled = v
	}
	dailyResetExecutionOffset := current.DailyResetExecutionOffsetMinutes
	if v, ok := in["dailyResetExecutionOffsetMinutes"].(float64); ok {
		dailyResetExecutionOffset = int(v)
	}
	if dailyResetExecutionOffset < 0 {
		dailyResetExecutionOffset = 0
	}
	if dailyResetExecutionOffset > 24*60 {
		dailyResetExecutionOffset = 24 * 60
	}
	shiftWindowDisabled := current.ShiftWindowDisabled
	if v, ok := mapLookupBool(in, "shiftWindowDisabled", "shift_window_disabled"); ok {
		shiftWindowDisabled = v
	}
	workEndGraceAfter := current.WorkEndGraceAfter
	if v, ok := in["workEndGraceAfter"].(float64); ok {
		workEndGraceAfter = int(v)
	}
	if v, ok := in["checkOutGraceAfter"].(float64); ok {
		workEndGraceAfter = int(v)
	}
	if lateTolerance < 0 {
		lateTolerance = 0
	}
	if earlyLeave < 0 {
		earlyLeave = 0
	}
	requirePCLogin := current.RequirePCLogin
	if v, ok := mapLookupBool(in, "requirePCLogin", "require_pc_login"); ok {
		requirePCLogin = v
	}
	captureLinkedToCheckin := current.CaptureLinkedToCheckin
	if v, ok := mapLookupBool(in, "captureLinkedToCheckin", "capture_linked_to_checkin"); ok {
		captureLinkedToCheckin = v
	}
	webPunchOnly := current.WebPunchOnly
	if v, ok := mapLookupBool(in, "webPunchOnly", "web_punch_only"); ok {
		webPunchOnly = v
	}
	adminTelegramUserIDs := current.AdminTelegramUserIDs
	if v, ok := in["adminTelegramUserIds"].(string); ok {
		adminTelegramUserIDs = strings.TrimSpace(v)
	}
	botMode := current.BotMode
	if v, ok := in["botMode"].(string); ok && strings.TrimSpace(v) != "" {
		botMode = strings.ToLower(strings.TrimSpace(v))
	}
	webhookURL := current.WebhookURL
	if v, ok := in["webhookUrl"].(string); ok {
		webhookURL = strings.TrimSpace(v)
	}
	botUILang := current.BotUILang
	if v, ok := in["botUiLang"].(string); ok && strings.TrimSpace(v) != "" {
		botUILang = strings.ToLower(strings.TrimSpace(v))
	}
	fineCurrency := NormalizeFineCurrency(current.FineCurrency)
	if v, ok := in["fineCurrency"].(string); ok {
		fineCurrency = NormalizeFineCurrency(v)
	}
	showKeyboardInfoButtons := current.ShowKeyboardInfoButtons
	if v, ok := mapLookupBool(in, "showKeyboardInfoButtons", "show_keyboard_info_buttons"); ok {
		showKeyboardInfoButtons = v
	}

	botTokenEnc := sql.NullString{}
	botUsername := current.BotUsername
	botID := current.BotID
	if token, ok := in["botToken"].(string); ok && strings.TrimSpace(token) != "" {
		enc, err := EncryptSecret(strings.TrimSpace(token))
		if err != nil {
			return nil, err
		}
		botTokenEnc = sql.NullString{String: enc, Valid: true}
		me, err := telegramGetMe(strings.TrimSpace(token))
		if err != nil {
			return nil, fmt.Errorf("verify bot token: %w", err)
		}
		botUsername = me.Username
		botID = me.ID
	}

	workerSecret := sql.NullString{}
	if v, ok := in["regenerateWorkerSecret"].(bool); ok && v {
		secret, err := generateWorkerSecret()
		if err != nil {
			return nil, err
		}
		workerSecret = sql.NullString{String: secret, Valid: true}
	}
	webhookSecret := sql.NullString{}
	if v, ok := in["regenerateWebhookSecret"].(bool); ok && v {
		secret, err := generateWorkerSecret()
		if err != nil {
			return nil, err
		}
		webhookSecret = sql.NullString{String: secret, Valid: true}
	}

	query := `
		UPDATE wf_telegram_settings SET
			enabled = $1, timezone = $2, day_start = $3, day_end = $4,
			night_start = $5, night_end = $6, middle_start = $7, middle_end = $8,
			grace_minutes = $9, dual_shift_enabled = $10, triple_shift_enabled = $11,
			daily_reset_time = $12, daily_reset_enabled = $13,
			daily_reset_execution_offset_minutes = $14,
			shift_window_disabled = $15, work_end_grace_minutes = $16, work_end_grace_after = $17, require_pc_login = $18,
			capture_linked_to_checkin = $19, web_punch_only = $20,
			admin_telegram_user_ids = $21, grace_minutes_after = $22,
			check_out_grace_before = $23, late_tolerance_minutes = $24, early_leave_tolerance_minutes = $25,
			bot_mode = $26, webhook_url = $27, bot_ui_lang = $28, fine_currency = $29,
			show_keyboard_info_buttons = $30, updated_at = NOW()`
	args := []interface{}{
		enabled, timezone, dayStart, dayEnd, nightStart, nightEnd, middleStart, middleEnd,
		grace, dual, triple, dailyResetTime, dailyResetEnabled, dailyResetExecutionOffset,
		shiftWindowDisabled, earlyLeave, workEndGraceAfter, requirePCLogin, captureLinkedToCheckin,
		webPunchOnly, adminTelegramUserIDs, graceAfter, checkOutBefore, lateTolerance, earlyLeave,
		botMode, webhookURL, botUILang, fineCurrency, showKeyboardInfoButtons,
	}
	argN := 31
	if botTokenEnc.Valid {
		query += fmt.Sprintf(", bot_token_enc = $%d, bot_username = $%d, bot_id = $%d", argN, argN+1, argN+2)
		args = append(args, botTokenEnc.String, botUsername, botID)
		argN += 3
	}
	if workerSecret.Valid {
		query += fmt.Sprintf(", worker_secret = $%d", argN)
		args = append(args, workerSecret.String)
		argN++
	}
	if webhookSecret.Valid {
		query += fmt.Sprintf(", webhook_secret = $%d", argN)
		args = append(args, webhookSecret.String)
		argN++
	}
	query += fmt.Sprintf(" WHERE id = $%d", argN)
	args = append(args, current.ID)

	if _, err := s.db.ExecContext(ctx, query, args...); err != nil {
		return nil, err
	}
	if botTokenEnc.Valid {
		if _, err := s.EnsureWorkerSecret(ctx); err != nil {
			return nil, err
		}
	}
	return s.GetSettings(ctx)
}

func (s *WorkforceTelegramService) GetWebhookSecret(ctx context.Context) (string, error) {
	var secret sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT webhook_secret FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&secret)
	if err != nil {
		return "", err
	}
	if !secret.Valid {
		return "", nil
	}
	return strings.TrimSpace(secret.String), nil
}

func generateWorkerSecret() (string, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func (s *WorkforceTelegramService) ValidateWorkerSecret(ctx context.Context, secret string) error {
	secret = strings.TrimSpace(secret)
	if secret == "" {
		return errors.New("missing worker secret")
	}
	envSecret := strings.TrimSpace(os.Getenv("TELEGRAM_WORKER_SECRET"))
	if envSecret != "" && security.SecureCompare(secret, envSecret) {
		return nil
	}
	if s == nil || s.db == nil {
		return errors.New("invalid worker secret")
	}
	var dbSecret sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT worker_secret FROM wf_telegram_settings ORDER BY updated_at DESC LIMIT 1`).Scan(&dbSecret)
	if err != nil {
		return err
	}
	if dbSecret.Valid && security.SecureCompare(dbSecret.String, secret) {
		return nil
	}
	return errors.New("invalid worker secret")
}

func (s *WorkforceTelegramService) GetBotToken(ctx context.Context) (string, error) {
	var enc sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT bot_token_enc FROM wf_telegram_settings WHERE enabled = TRUE ORDER BY updated_at DESC LIMIT 1`).Scan(&enc)
	if err != nil || !enc.Valid {
		return "", errors.New("bot token not configured")
	}
	return DecryptSecret(enc.String)
}

type telegramMeResult struct {
	ID        int64
	Username  string
	FirstName string
}

func telegramGetMe(token string) (*telegramMeResult, error) {
	req, err := http.NewRequest(http.MethodGet, "https://api.telegram.org/bot"+token+"/getMe", nil)
	if err != nil {
		return nil, err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var parsed struct {
		OK     bool `json:"ok"`
		Result struct {
			ID        int64  `json:"id"`
			Username  string `json:"username"`
			FirstName string `json:"first_name"`
		} `json:"result"`
		Description string `json:"description"`
	}
	if err := json.Unmarshal(body, &parsed); err != nil {
		return nil, err
	}
	if !parsed.OK {
		if parsed.Description != "" {
			return nil, errors.New(parsed.Description)
		}
		return nil, errors.New("telegram getMe failed")
	}
	return &telegramMeResult{
		ID: parsed.Result.ID, Username: parsed.Result.Username, FirstName: parsed.Result.FirstName,
	}, nil
}

func scanTelegramGroupRow(row *TelegramGroupRow, sb, sa, cb, ca, lt, el sql.NullInt32, reset, lang sql.NullString) {
	if sb.Valid && int(sb.Int32) > 0 {
		v := int(sb.Int32)
		row.ShiftGraceBefore = &v
	}
	if sa.Valid && int(sa.Int32) > 0 {
		v := int(sa.Int32)
		row.ShiftGraceAfter = &v
	}
	if cb.Valid && int(cb.Int32) > 0 {
		v := int(cb.Int32)
		row.CheckOutGraceBefore = &v
	}
	if ca.Valid && int(ca.Int32) > 0 {
		v := int(ca.Int32)
		row.CheckOutGraceAfter = &v
	}
	if lt.Valid && int(lt.Int32) >= 0 {
		v := int(lt.Int32)
		row.LateToleranceMinutes = &v
	}
	if el.Valid && int(el.Int32) >= 0 {
		v := int(el.Int32)
		row.EarlyLeaveToleranceMinutes = &v
	}
	if reset.Valid {
		row.DailyResetTime = strings.TrimSpace(reset.String)
	}
	if lang.Valid {
		row.BotUILang = strings.TrimSpace(lang.String)
	}
}

func (s *WorkforceTelegramService) ListGroups(ctx context.Context) ([]TelegramGroupRow, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, chat_id, COALESCE(chat_title,''), enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			late_tolerance_minutes, early_leave_tolerance_minutes,
			daily_reset_time, bot_ui_lang, created_at
		FROM wf_telegram_groups ORDER BY created_at DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TelegramGroupRow, 0)
	for rows.Next() {
		var row TelegramGroupRow
		var sb, sa, cb, ca, lt, el sql.NullInt32
		var reset, lang sql.NullString
		if err := rows.Scan(&row.ID, &row.ChatID, &row.ChatTitle, &row.Enabled,
			&sb, &sa, &cb, &ca, &lt, &el, &reset, &lang, &row.CreatedAt); err != nil {
			continue
		}
		scanTelegramGroupRow(&row, sb, sa, cb, ca, lt, el, reset, lang)
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) UpsertGroup(ctx context.Context, chatID, chatTitle string, enabled bool, overrides map[string]interface{}) (*TelegramGroupRow, error) {
	chatID = strings.TrimSpace(chatID)
	if chatID == "" {
		return nil, fmt.Errorf("chat_id required")
	}
	shiftBefore := nullableIntFromAnyKeys(overrides, "shiftGraceBefore", "checkInGraceBefore")
	shiftAfter := nullableIntFromAnyKeys(overrides, "shiftGraceAfter", "checkInGraceAfter")
	checkOutBefore := nullableIntFromAnyKeys(overrides, "workEndGraceBefore", "checkOutGraceBefore")
	checkOutAfter := nullableIntFromAnyKeys(overrides, "workEndGraceAfter", "checkOutGraceAfter")
	lateTolerance := nullableIntFromAnyAllowZero(overrides["lateToleranceMinutes"])
	earlyLeave := nullableIntFromAnyAllowZero(overrides["earlyLeaveToleranceMinutes"])
	dailyReset := nullableStringFromAny(overrides["dailyResetTime"])
	groupLang := nullableStringFromAny(overrides["botUiLang"])

	var row TelegramGroupRow
	var sb, sa, cb, ca, lt, el sql.NullInt32
	var reset, lang sql.NullString
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO wf_telegram_groups (
			chat_id, chat_title, enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			late_tolerance_minutes, early_leave_tolerance_minutes,
			daily_reset_time, bot_ui_lang
		)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
		ON CONFLICT (chat_id) DO UPDATE SET
			chat_title = CASE WHEN EXCLUDED.chat_title <> '' THEN EXCLUDED.chat_title ELSE wf_telegram_groups.chat_title END,
			enabled = EXCLUDED.enabled,
			shift_grace_before = COALESCE(EXCLUDED.shift_grace_before, wf_telegram_groups.shift_grace_before),
			shift_grace_after = COALESCE(EXCLUDED.shift_grace_after, wf_telegram_groups.shift_grace_after),
			work_end_grace_before = COALESCE(EXCLUDED.work_end_grace_before, wf_telegram_groups.work_end_grace_before),
			work_end_grace_after = COALESCE(EXCLUDED.work_end_grace_after, wf_telegram_groups.work_end_grace_after),
			late_tolerance_minutes = COALESCE(EXCLUDED.late_tolerance_minutes, wf_telegram_groups.late_tolerance_minutes),
			early_leave_tolerance_minutes = COALESCE(EXCLUDED.early_leave_tolerance_minutes, wf_telegram_groups.early_leave_tolerance_minutes),
			daily_reset_time = COALESCE(EXCLUDED.daily_reset_time, wf_telegram_groups.daily_reset_time),
			bot_ui_lang = COALESCE(EXCLUDED.bot_ui_lang, wf_telegram_groups.bot_ui_lang)
		RETURNING id, chat_id, COALESCE(chat_title,''), enabled,
			shift_grace_before, shift_grace_after, work_end_grace_before, work_end_grace_after,
			late_tolerance_minutes, early_leave_tolerance_minutes,
			daily_reset_time, bot_ui_lang, created_at`,
		chatID, strings.TrimSpace(chatTitle), enabled,
		shiftBefore, shiftAfter, checkOutBefore, checkOutAfter, lateTolerance, earlyLeave, dailyReset, groupLang).Scan(
		&row.ID, &row.ChatID, &row.ChatTitle, &row.Enabled,
		&sb, &sa, &cb, &ca, &lt, &el, &reset, &lang, &row.CreatedAt)
	if err != nil {
		return nil, err
	}
	scanTelegramGroupRow(&row, sb, sa, cb, ca, lt, el, reset, lang)
	return &row, nil
}

func nullableIntFromAny(v interface{}) sql.NullInt32 {
	if v == nil {
		return sql.NullInt32{}
	}
	n := intFromAny(v, 0)
	if n <= 0 {
		return sql.NullInt32{}
	}
	return sql.NullInt32{Int32: int32(n), Valid: true}
}

func nullableIntFromAnyAllowZero(v interface{}) sql.NullInt32 {
	if v == nil {
		return sql.NullInt32{}
	}
	n := intFromAny(v, 0)
	if n < 0 {
		return sql.NullInt32{}
	}
	return sql.NullInt32{Int32: int32(n), Valid: true}
}

func nullableIntFromAnyKeys(overrides map[string]interface{}, keys ...string) sql.NullInt32 {
	for _, key := range keys {
		if v, ok := overrides[key]; ok {
			if out := nullableIntFromAny(v); out.Valid {
				return out
			}
		}
	}
	return sql.NullInt32{}
}

func nullableStringFromAny(v interface{}) sql.NullString {
	if v == nil {
		return sql.NullString{}
	}
	s := strings.TrimSpace(fmt.Sprint(v))
	if s == "" {
		return sql.NullString{}
	}
	return sql.NullString{String: s, Valid: true}
}

func (s *WorkforceTelegramService) DeleteGroup(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM wf_telegram_groups WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) ListBindings(ctx context.Context, search string) ([]TelegramBindingRow, error) {
	search = strings.TrimSpace(search)
	query := `
		SELECT b.id, b.employee_id, e.name, COALESCE(e.employee_id,''),
			COALESCE(NULLIF(TRIM(e.attendance_mode), ''), 'pc_tg'),
			b.telegram_user_id, COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''),
			b.bound_at, b.status
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.status = 1`
	args := []interface{}{}
	if search != "" {
		query += ` AND (e.name ILIKE $1 OR e.employee_id ILIKE $1 OR b.telegram_username ILIKE $1 OR b.telegram_user_id::text ILIKE $1)`
		args = append(args, "%"+search+"%")
	}
	query += ` ORDER BY b.bound_at DESC`
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TelegramBindingRow, 0)
	for rows.Next() {
		var row TelegramBindingRow
		if err := rows.Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode, &row.AttendanceMode,
			&row.TelegramUserID, &row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status); err != nil {
			continue
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) CreateBinding(ctx context.Context, employeeID uuid.UUID, telegramUserID int64, telegramUsername, chatID string) (*TelegramBindingRow, error) {
	if telegramUserID <= 0 {
		return nil, fmt.Errorf("invalid telegram user id")
	}
	var exists int
	if err := s.db.QueryRowContext(ctx, `SELECT COUNT(*) FROM employees WHERE id = $1 AND status = 1`, employeeID).Scan(&exists); err != nil || exists == 0 {
		return nil, ErrEmployeeNotFound
	}
	var id uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		INSERT INTO employee_telegram_bindings (employee_id, telegram_user_id, telegram_username, chat_id, status)
		VALUES ($1, $2, $3, $4, 1)
		ON CONFLICT (employee_id) DO UPDATE SET
			telegram_user_id = EXCLUDED.telegram_user_id,
			telegram_username = EXCLUDED.telegram_username,
			chat_id = CASE
				WHEN COALESCE(NULLIF(TRIM(EXCLUDED.chat_id), ''), '') <> '' THEN EXCLUDED.chat_id
				ELSE employee_telegram_bindings.chat_id
			END,
			status = 1,
			bound_at = NOW()
		RETURNING id`, employeeID, telegramUserID, nullString(strings.TrimSpace(telegramUsername)), nullString(strings.TrimSpace(chatID))).Scan(&id)
	if err != nil {
		return nil, err
	}
	items, err := s.ListBindings(ctx, "")
	if err != nil {
		return nil, err
	}
	for _, item := range items {
		if item.ID == id {
			return &item, nil
		}
	}
	return nil, fmt.Errorf("binding not found after create")
}

func (s *WorkforceTelegramService) DeleteBinding(ctx context.Context, id uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM employee_telegram_bindings WHERE id = $1`, id)
	return err
}

func (s *WorkforceTelegramService) GetBindingByID(ctx context.Context, id uuid.UUID) (*TelegramBindingRow, error) {
	var row TelegramBindingRow
	err := s.db.QueryRowContext(ctx, `
		SELECT b.id, b.employee_id, e.name, COALESCE(e.employee_id,''),
			COALESCE(NULLIF(TRIM(e.attendance_mode), ''), 'pc_tg'),
			b.telegram_user_id, COALESCE(b.telegram_username,''), COALESCE(b.chat_id,''), b.bound_at, b.status
		FROM employee_telegram_bindings b
		JOIN employees e ON e.id = b.employee_id
		WHERE b.id = $1 AND b.status = 1`, id).
		Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.EmployeeCode, &row.AttendanceMode,
			&row.TelegramUserID, &row.TelegramUsername, &row.ChatID, &row.BoundAt, &row.Status)
	if err == sql.ErrNoRows {
		return nil, ErrTelegramNotBound
	}
	if err != nil {
		return nil, err
	}
	return &row, nil
}

func (s *WorkforceTelegramService) ResolveEmployeeByTelegramUserID(ctx context.Context, telegramUserID int64) (uuid.UUID, error) {
	return s.ResolveEmployeeByTelegramUserIDWithDevice(ctx, telegramUserID, uuid.Nil, "")
}

func (s *WorkforceTelegramService) ResolveEmployeeByTelegramUserIDWithDevice(
	ctx context.Context, telegramUserID int64, deviceID uuid.UUID, deviceHint string,
) (uuid.UUID, error) {
	actor, err := s.ResolveTelegramActorWithDevice(ctx, telegramUserID, deviceID, deviceHint)
	if err != nil {
		return uuid.Nil, err
	}
	return actor.EmployeeID, nil
}

func (s *WorkforceTelegramService) EmployeeNameByTelegramUserID(ctx context.Context, telegramUserID int64) string {
	if actor, err := s.ResolveTelegramBinding(ctx, telegramUserID); err == nil && actor.EmployeeID != uuid.Nil {
		var name string
		_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, actor.EmployeeID).Scan(&name)
		return strings.TrimSpace(name)
	}
	return ""
}

func (s *WorkforceTelegramService) GetEmployeeSessionStatus(ctx context.Context, empID uuid.UUID) (bool, *uuid.UUID, error) {
	var sid uuid.UUID
	err := s.db.QueryRowContext(ctx, `
		SELECT id FROM work_sessions WHERE employee_id = $1 AND status = 'open'
		ORDER BY checkin_time DESC LIMIT 1`, empID).Scan(&sid)
	if err == sql.ErrNoRows {
		return false, nil, nil
	}
	if err != nil {
		return false, nil, err
	}
	return true, &sid, nil
}

func (s *WorkforceTelegramService) TelegramCheckIn(ctx context.Context, telegramUserID int64, chatID, forcedShift string) (*CheckInResult, uuid.UUID, string, float64, string, string, error) {
	return s.TelegramCheckInWithDevice(ctx, telegramUserID, chatID, forcedShift, uuid.Nil, "")
}

func (s *WorkforceTelegramService) TelegramCheckInWithDevice(
	ctx context.Context, telegramUserID int64, chatID, forcedShift string, deviceID uuid.UUID, deviceHint string,
) (*CheckInResult, uuid.UUID, string, float64, string, string, error) {
	if err := s.rejectIfWebPunchOnly(ctx); err != nil {
		return nil, uuid.Nil, "", 0, "", "", err
	}
	active, err := s.IsActive(ctx)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", err
	}
	if !active {
		return nil, uuid.Nil, "", 0, "", "", ErrTelegramDisabled
	}
	actor, err := s.ResolveTelegramActorWithDevice(ctx, telegramUserID, deviceID, deviceHint)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", err
	}
	empID := actor.EmployeeID
	if chatID != "" {
		_, _ = s.UpsertGroup(ctx, chatID, "", true, nil)
		s.updateTelegramChatID(ctx, actor, chatID)
	}
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
	outcome, err := s.telegramCheckInWithShift(ctx, empID, telegramUserID, chatID, forcedShift, actor)
	if err != nil {
		return nil, empID, name, 0, "", "", err
	}
	return outcome.Result, empID, name, outcome.WorkFine, outcome.HandoverHint, outcome.GroupReplyHTML, nil
}

func (s *WorkforceTelegramService) TelegramCheckOut(ctx context.Context, telegramUserID int64, chatID string) (*CheckOutResult, uuid.UUID, string, float64, string, string, string, error) {
	return s.TelegramCheckOutWithDevice(ctx, telegramUserID, chatID, uuid.Nil, "")
}

func (s *WorkforceTelegramService) TelegramCheckOutWithDevice(
	ctx context.Context, telegramUserID int64, chatID string, deviceID uuid.UUID, deviceHint string,
) (*CheckOutResult, uuid.UUID, string, float64, string, string, string, error) {
	if err := s.rejectIfWebPunchOnly(ctx); err != nil {
		return nil, uuid.Nil, "", 0, "", "", "", err
	}
	active, err := s.IsActive(ctx)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", "", err
	}
	if !active {
		return nil, uuid.Nil, "", 0, "", "", "", ErrTelegramDisabled
	}
	actor, err := s.ResolveTelegramActorWithDevice(ctx, telegramUserID, deviceID, deviceHint)
	if err != nil {
		return nil, uuid.Nil, "", 0, "", "", "", err
	}
	empID := actor.EmployeeID
	var name string
	_ = s.db.QueryRowContext(ctx, `SELECT name FROM employees WHERE id = $1`, empID).Scan(&name)
	if chatID == "" {
		chatID = s.getChatIDForActor(ctx, actor)
	}
	outcome, err := s.telegramCheckOutFIFO(ctx, empID, telegramUserID, chatID, actor)
	if err != nil {
		return nil, empID, name, 0, "", "", "", err
	}
	return outcome.Result, empID, name, outcome.WorkFine, outcome.HandoverHint, outcome.ActivityWarn, outcome.GroupReplyHTML, nil
}

func ParseTelegramUserID(raw string) (int64, error) {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return 0, fmt.Errorf("empty telegram user id")
	}
	return strconv.ParseInt(raw, 10, 64)
}

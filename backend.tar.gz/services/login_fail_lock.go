package services

import (
	"context"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// LoginFailLock tracks per-username failed admin login attempts in Redis.
// Disabled when SECURITY_AUTH_FAIL_THRESHOLD=0 or Redis is unavailable.
type LoginFailLock struct {
	redis     *redis.Client
	threshold int
	window    time.Duration
}

func NewLoginFailLock(redisClient *redis.Client) *LoginFailLock {
	return &LoginFailLock{
		redis:     redisClient,
		threshold: authFailLockThreshold(),
		window:    authFailLockWindow(),
	}
}

func authFailLockThreshold() int {
	v := strings.TrimSpace(os.Getenv("SECURITY_AUTH_FAIL_THRESHOLD"))
	if v == "0" {
		return 0
	}
	if v == "" {
		return 8
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 1 {
		return 8
	}
	return n
}

func authFailLockWindow() time.Duration {
	v := strings.TrimSpace(os.Getenv("SECURITY_AUTH_FAIL_WINDOW_SEC"))
	if v == "" {
		return 900 * time.Second
	}
	n, err := strconv.Atoi(v)
	if err != nil || n < 60 {
		return 900 * time.Second
	}
	return time.Duration(n) * time.Second
}

func (l *LoginFailLock) enabled(username string) bool {
	return l != nil && l.redis != nil && l.threshold > 0 && strings.TrimSpace(username) != ""
}

func (l *LoginFailLock) key(username string) string {
	return "login_fail:" + strings.ToLower(strings.TrimSpace(username))
}

// IsLocked reports whether the username exceeded the failure threshold within the window.
func (l *LoginFailLock) IsLocked(ctx context.Context, username string) (bool, error) {
	if !l.enabled(username) {
		return false, nil
	}
	count, err := l.redis.Get(ctx, l.key(username)).Int64()
	if err == redis.Nil {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return count >= int64(l.threshold), nil
}

// RecordFailure increments the username failure counter and refreshes the window TTL on first hit.
func (l *LoginFailLock) RecordFailure(ctx context.Context, username string) error {
	if !l.enabled(username) {
		return nil
	}
	key := l.key(username)
	count, err := l.redis.Incr(ctx, key).Result()
	if err != nil {
		return err
	}
	if count == 1 {
		if err := l.redis.Expire(ctx, key, l.window).Err(); err != nil {
			return err
		}
	}
	return nil
}

// Clear removes the failure counter after a successful login.
func (l *LoginFailLock) Clear(ctx context.Context, username string) error {
	if !l.enabled(username) {
		return nil
	}
	return l.redis.Del(ctx, l.key(username)).Err()
}

// Threshold returns configured max failures before lock (0 = disabled).
func (l *LoginFailLock) Threshold() int {
	if l == nil {
		return 0
	}
	return l.threshold
}

func (l *LoginFailLock) String() string {
	if l == nil {
		return "LoginFailLock(nil)"
	}
	return fmt.Sprintf("LoginFailLock(threshold=%d window=%s)", l.threshold, l.window)
}

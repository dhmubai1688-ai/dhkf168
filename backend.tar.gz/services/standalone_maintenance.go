package services

import (
	"context"
	"time"
)

// Called by the single inbox owner AFTER queued punches are drained. No competing
// scheduler can auto-close an activity before a delayed return-to-seat is handled.
func (s *WorkforceTelegramService) StandaloneMaintenance(ctx context.Context, full bool) {
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return
	}
	s.tickActivityTimers(ctx)
	s.MaybeRunDailyReset(ctx)
	if full {
		s.RecoverMissedDailyResets(ctx)
		s.RecoverExpiredActivities(ctx)
		s.CloseExpiredWorkSessionsGlobal(ctx)
		s.MaybePushMonthlyArchive(ctx)
		_ = s.CleanupTelegramRetention(ctx)
		_, _ = s.db.ExecContext(ctx, `DELETE FROM standalone_exports WHERE created_at<NOW()-interval '7 days'; DELETE FROM standalone_sessions WHERE expires_at<NOW(); DELETE FROM standalone_login_attempts WHERE expires_at<NOW(); DELETE FROM standalone_inbox WHERE status IN ('done','resolved') AND received_at<NOW()-interval '30 days'`)
	}
}

// A maintenance deadline bounds database waits on a constrained free instance.
func StandaloneMaintenanceContext(ctx context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, 45*time.Second)
}

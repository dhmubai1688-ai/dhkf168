package services

import (
	"context"
	"database/sql"
	"fmt"
	"net/url"
	"os"
	"strconv"
	"time"
)

// OpenAttendanceDatabase is the only database bootstrap used by the standalone binary.
// A dedicated empty database is required; monitor databases cannot be upgraded accidentally.
func OpenAttendanceDatabase() (*sql.DB, error) {
	raw := os.Getenv("DATABASE_URL")
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" || (u.Scheme != "postgres" && u.Scheme != "postgresql") {
		return nil, fmt.Errorf("DATABASE_URL must be a PostgreSQL URI")
	}
	q := u.Query()
	if os.Getenv("ENV") == "production" {
		q.Set("sslmode", "verify-full")
		ca := os.Getenv("PGSSLROOTCERT")
		if ca == "" {
			return nil, fmt.Errorf("PGSSLROOTCERT must point to the Aiven CA certificate")
		}
		q.Set("sslrootcert", ca)
	}
	q.Set("connect_timeout", "10")
	u.RawQuery = q.Encode()
	db, err := sql.Open("postgres", u.String())
	if err != nil {
		return nil, err
	}
	max := 5
	if n, e := strconv.Atoi(os.Getenv("DB_MAX_CONNECTIONS")); e == nil && n >= 3 && n <= 10 {
		max = n
	}
	db.SetMaxOpenConns(max)
	db.SetMaxIdleConns(1)
	db.SetConnMaxIdleTime(time.Minute)
	db.SetConnMaxLifetime(10 * time.Minute)
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	fail := func(err error) (*sql.DB, error) { db.Close(); return nil, err }
	if err = db.PingContext(ctx); err != nil {
		return fail(err)
	}
	conn, err := db.Conn(ctx)
	if err != nil {
		return fail(err)
	}
	defer conn.Close()
	if _, err = conn.ExecContext(ctx, "SELECT pg_advisory_lock(84392701)"); err != nil {
		return fail(err)
	}
	defer conn.ExecContext(context.Background(), "SELECT pg_advisory_unlock(84392701)")
	var marker, users bool
	if err = conn.QueryRowContext(ctx, "SELECT to_regclass('public.standalone_schema') IS NOT NULL, to_regclass('public.users') IS NOT NULL").Scan(&marker, &users); err != nil {
		return fail(err)
	}
	if users && !marker {
		return fail(fmt.Errorf("refusing an existing non-standalone database; create a dedicated empty Aiven database"))
	}
	if _, err = conn.ExecContext(ctx, `CREATE TABLE IF NOT EXISTS standalone_schema(version integer PRIMARY KEY, installed_at timestamptz DEFAULT NOW());`); err != nil {
		return fail(err)
	}
	var version int
	_ = conn.QueryRowContext(ctx, "SELECT COALESCE(MAX(version),0) FROM standalone_schema").Scan(&version)
	if version < 1 {
		for _, migrate := range []func(*sql.DB) error{initEmbeddedSchema, migrateSchema, ensureAuthSessionsSchema, ensureWorkforceSchema, ensureWorkforceTelegramSchema, seedDefaultAdmin} {
			if err = migrate(db); err != nil {
				return fail(err)
			}
		}
		if _, err = db.Exec(`CREATE TABLE IF NOT EXISTS standalone_sessions(token_hash text PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires_at timestamptz NOT NULL);
   CREATE TABLE IF NOT EXISTS standalone_login_attempts(bucket text PRIMARY KEY,attempts integer NOT NULL DEFAULT 0,expires_at timestamptz NOT NULL);
   CREATE TABLE IF NOT EXISTS standalone_inbox(update_id bigint PRIMARY KEY,body jsonb NOT NULL,status text NOT NULL DEFAULT 'pending',received_at timestamptz NOT NULL DEFAULT NOW(),started_at timestamptz,finished_at timestamptz,note text NOT NULL DEFAULT '');
   CREATE INDEX IF NOT EXISTS standalone_inbox_pending ON standalone_inbox(status,update_id);
   INSERT INTO standalone_schema(version) VALUES(1) ON CONFLICT DO NOTHING;`); err != nil {
			return fail(err)
		}
	}
	if version < 2 {
		if _, err = db.Exec(`ALTER TABLE employees ALTER COLUMN attendance_mode SET DEFAULT 'tg_only'; UPDATE employees SET attendance_mode='tg_only' WHERE attendance_mode='pc_tg'; INSERT INTO standalone_schema(version) VALUES(2) ON CONFLICT DO NOTHING;`); err != nil {
			return fail(err)
		}
	}
	if version < 3 {
		if _, err = db.Exec(`CREATE TABLE IF NOT EXISTS standalone_exports(filename text PRIMARY KEY,content bytea NOT NULL,created_at timestamptz NOT NULL DEFAULT NOW()); INSERT INTO standalone_schema(version) VALUES(3) ON CONFLICT DO NOTHING;`); err != nil {
			return fail(err)
		}
	}
	return db, nil
}

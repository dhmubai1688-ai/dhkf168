package services

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	"github.com/google/uuid"
)

func employeeHasLangPref(ctx context.Context, db *sql.DB, empID uuid.UUID) bool {
	if db == nil || empID == uuid.Nil {
		return false
	}
	var lang sql.NullString
	err := db.QueryRowContext(ctx, `
		SELECT preferred_lang FROM wf_tg_employee_lang_prefs WHERE employee_id = $1`, empID).
		Scan(&lang)
	return err == nil && lang.Valid && strings.TrimSpace(lang.String) != ""
}

func groupPunchTemplateLang(mode TgLangMode) TgLangMode {
	switch mode {
	case TgLangVi:
		return TgLangVi
	case TgLangEn:
		return TgLangEn
	default:
		return TgLangZh
	}
}

// resolveEmployeeGroupNotifyLang picks language for PC/admin group punch cards.
// Employee /lang wins; otherwise group botUiLang (both → zh).
func resolveEmployeeGroupNotifyLang(hasPersonalPref bool, personal, group TgLangMode) TgLangMode {
	if hasPersonalPref {
		return personal
	}
	return groupPunchTemplateLang(group)
}

// replyLangForEmployeeGroupNotify is for PC/后台 group announcements of this employee.
func (s *WorkforceTelegramService) replyLangForEmployeeGroupNotify(ctx context.Context, empID uuid.UUID, chatID string) TgLangMode {
	if employeeHasLangPref(ctx, s.db, empID) {
		return s.GetReplyLangForEmployee(ctx, empID)
	}
	return groupPunchTemplateLang(s.GetLangMode(ctx, chatID))
}

// GetReplyLangForEmployee returns zh/vi/en for punch reply HTML for this employee.
// Employees without /lang default to Chinese.
func (s *WorkforceTelegramService) GetReplyLangForEmployee(ctx context.Context, empID uuid.UUID) TgLangMode {
	if empID == uuid.Nil {
		return TgLangZh
	}
	var lang sql.NullString
	err := s.db.QueryRowContext(ctx, `
		SELECT preferred_lang FROM wf_tg_employee_lang_prefs WHERE employee_id = $1`, empID).
		Scan(&lang)
	if err != nil || !lang.Valid {
		return TgLangZh
	}
	switch normalizeTgLangMode(lang.String) {
	case TgLangVi:
		return TgLangVi
	case TgLangEn:
		return TgLangEn
	default:
		return TgLangZh
	}
}

// GetReplyLangForUser resolves the current employee for this Telegram account, then returns
// that employee's preferred lang. Unbound / PC-not-logged-in workstation → Chinese default.
func (s *WorkforceTelegramService) GetReplyLangForUser(ctx context.Context, telegramUserID int64) TgLangMode {
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil || empID == uuid.Nil {
		return TgLangZh
	}
	return s.GetReplyLangForEmployee(ctx, empID)
}

// keyboardLangForUser uses the resolved employee's /lang when set; otherwise group/bot UI language.
func (s *WorkforceTelegramService) keyboardLangForUser(ctx context.Context, chatID string, telegramUserID int64) TgLangMode {
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil || empID == uuid.Nil {
		return s.GetLangMode(ctx, chatID)
	}
	if !employeeHasLangPref(ctx, s.db, empID) {
		return s.GetLangMode(ctx, chatID)
	}
	return s.GetReplyLangForEmployee(ctx, empID)
}

// DisplayLangForTelegram is the language for bot keyboards / local bot cache.
// Employee /lang wins; otherwise group botUiLang (same as keyboard). Not used for punch HTML
// (punch replies without a personal pref still default to Chinese).
func (s *WorkforceTelegramService) DisplayLangForTelegram(ctx context.Context, chatID string, telegramUserID int64) TgLangMode {
	return s.keyboardLangForUser(ctx, chatID, telegramUserID)
}

func normalizeUserReplyLang(raw string) (TgLangMode, bool) {
	raw = strings.ToLower(strings.TrimSpace(raw))
	switch raw {
	case "zh", "cn", "chinese", "中文":
		return TgLangZh, true
	case "vi", "vn", "vietnamese", "越南语", "越":
		return TgLangVi, true
	case "en", "english", "英语", "英文", "英":
		return TgLangEn, true
	default:
		return TgLangZh, false
	}
}

// SetEmployeePreferredLang stores /lang preference for one employee (zh, vi, or en).
func (s *WorkforceTelegramService) SetEmployeePreferredLang(ctx context.Context, empID uuid.UUID, lang string) error {
	if empID == uuid.Nil {
		return fmt.Errorf("invalid employee id")
	}
	mode, ok := normalizeUserReplyLang(lang)
	if !ok {
		return ErrUnsupportedReplyLang
	}
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_employee_lang_prefs (employee_id, preferred_lang, updated_at)
		VALUES ($1, $2, NOW())
		ON CONFLICT (employee_id) DO UPDATE SET
			preferred_lang = EXCLUDED.preferred_lang,
			updated_at = NOW()`, empID, string(mode))
	return err
}

// SetUserPreferredLang resolves the employee currently associated with this Telegram account
// (personal bind, or workstation with PC login) and stores language for that employee.
func (s *WorkforceTelegramService) SetUserPreferredLang(ctx context.Context, telegramUserID int64, lang string) error {
	if telegramUserID <= 0 {
		return fmt.Errorf("invalid telegram user id")
	}
	if _, ok := normalizeUserReplyLang(lang); !ok {
		return ErrUnsupportedReplyLang
	}
	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return err
	}
	if empID == uuid.Nil {
		return ErrPCLoginRequired
	}
	return s.SetEmployeePreferredLang(ctx, empID, lang)
}

func tgReplyLabel(zh, vi, en string, mode TgLangMode) string {
	switch mode {
	case TgLangVi:
		if strings.TrimSpace(vi) != "" {
			return vi
		}
	case TgLangEn:
		if strings.TrimSpace(en) != "" {
			return en
		}
	}
	return zh
}

func tgReplyShiftLabel(shift string, mode TgLangMode) string {
	switch shift {
	case "night":
		return tgReplyLabel("夜班", "Ca đêm", "Night shift", mode)
	case "middle":
		return tgReplyLabel("中班", "Ca giữa", "Middle shift", mode)
	default:
		return tgReplyLabel("白班", "Ca ngày", "Day shift", mode)
	}
}

func tgReplyUnlimitedLabel(mode TgLangMode) string {
	return tgReplyLabel("不限", "Không giới hạn", "Unlimited", mode)
}

func formatDurationForLang(seconds int, mode TgLangMode) string {
	if seconds <= 0 {
		switch mode {
		case TgLangVi:
			return "0 giây"
		case TgLangEn:
			return "0s"
		default:
			return "0秒"
		}
	}
	m, sec := seconds/60, seconds%60
	h := m / 60
	m = m % 60
	switch mode {
	case TgLangVi:
		if h > 0 {
			return fmt.Sprintf("%d giờ %d phút %d giây", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%d phút %d giây", m, sec)
		}
		return fmt.Sprintf("%d giây", sec)
	case TgLangEn:
		if h > 0 {
			return fmt.Sprintf("%dh %dm %ds", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%dm %ds", m, sec)
		}
		return fmt.Sprintf("%ds", sec)
	default:
		if h > 0 {
			return fmt.Sprintf("%d小时%d分%d秒", h, m, sec)
		}
		if m > 0 {
			return fmt.Sprintf("%d分%d秒", m, sec)
		}
		return fmt.Sprintf("%d秒", sec)
	}
}

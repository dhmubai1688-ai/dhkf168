package services

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
)

type TgHandoverRow struct {
	ID           uuid.UUID
	EmployeeID   uuid.UUID
	EmployeeName string
	ChatID       string
	FromShift    string
	ToShift      string
	Note         string
	HandoverAt   time.Time
}

type TgRankingRow struct {
	Rank           int
	EmployeeID     uuid.UUID
	EmployeeName   string
	EmployeeCode   string
	ActivityCount  int
	OvertimeSeconds int
	FineTotal      float64
}

type TgDailyResetResult struct {
	ResetDate           string   `json:"resetDate"`
	ExportDate          string   `json:"exportDate"`
	ExportDateNote      string   `json:"exportDateNote,omitempty"`
	ClosedWorkSessions  int      `json:"closedWorkSessions"`
	ClosedAgentSessions int      `json:"closedAgentSessions"`
	ClosedActivities    int      `json:"closedActivities"`
	ExportPath          string   `json:"exportPath,omitempty"`
	ArchivedMonth       string   `json:"archivedMonth,omitempty"`
	BindingWarnings     []string `json:"bindingWarnings,omitempty"`
	SkippedAllGroups    bool     `json:"skippedAllGroups,omitempty"`
	GroupsProcessed     int      `json:"groupsProcessed"`
}

// DailyResetRunOptions 手动日重置可选参数（定时/懒重置不传）。
type DailyResetRunOptions struct {
	// ExportBusinessToday 为 true 时导出各群当前业务日数据，而非默认的「上一统计日」。
	ExportBusinessToday bool
	// ManualTrigger 为 true 表示管理端手动触发；补全下班会保留日期保护，避免白天误关当日在班会话。
	ManualTrigger bool
	// ForcedExportDate 非空时强制使用该统计日导出/清库（补偿重置用）。
	ForcedExportDate string
}

func tgLoadLocation(tz string) *time.Location {
	tz = strings.TrimSpace(tz)
	if tz == "" {
		tz = "Asia/Shanghai"
	}
	loc, err := time.LoadLocation(tz)
	if err != nil {
		return time.FixedZone("CST", 8*3600)
	}
	return loc
}

func parseClock(s string) (hour, minute int, ok bool) {
	s = strings.TrimSpace(s)
	parts := strings.Split(s, ":")
	if len(parts) != 2 {
		return 0, 0, false
	}
	var h, m int
	if _, err := fmt.Sscanf(parts[0], "%d", &h); err != nil {
		return 0, 0, false
	}
	if _, err := fmt.Sscanf(parts[1], "%d", &m); err != nil {
		return 0, 0, false
	}
	if h < 0 || h > 23 || m < 0 || m > 59 {
		return 0, 0, false
	}
	return h, m, true
}

func minutesOfDay(t time.Time) int {
	return t.Hour()*60 + t.Minute()
}

func clockToMinutes(h, m int) int {
	return h*60 + m
}

func isWithinWindow(nowMin, startMin, endMin, grace int) bool {
	startMin -= grace
	endMin += grace
	if startMin < 0 {
		startMin = 0
	}
	if endMin > 24*60-1 {
		endMin = 24*60 - 1
	}
	if startMin <= endMin {
		return nowMin >= startMin && nowMin <= endMin
	}
	return nowMin >= startMin || nowMin <= endMin
}

func (s *WorkforceTelegramService) resolveCurrentShift(settings *TelegramSettings, now time.Time) (string, error) {
	loc := tgLoadLocation(settings.Timezone)
	now = now.In(loc)
	nowMin := minutesOfDay(now)

	dayStartH, dayStartM, ok1 := parseClock(settings.DayStart)
	dayEndH, dayEndM, ok2 := parseClock(settings.DayEnd)
	if !ok1 || !ok2 {
		return "day", nil
	}
	dayStart := clockToMinutes(dayStartH, dayStartM)
	dayEnd := clockToMinutes(dayEndH, dayEndM)

	if !settings.MultiShiftEnabled() {
		if isWithinWindow(nowMin, dayStart, dayEnd, settings.GraceMinutes) {
			return "day", nil
		}
		return "", ErrOutsideWorkWindow
	}

	nightStartH, nightStartM, ok3 := parseClock(settings.NightStart)
	nightEndH, nightEndM, ok4 := parseClock(settings.NightEnd)
	if !ok3 || !ok4 {
		return "", fmt.Errorf("invalid night shift window")
	}
	nightStart := clockToMinutes(nightStartH, nightStartM)
	nightEnd := clockToMinutes(nightEndH, nightEndM)

	if isWithinWindow(nowMin, dayStart, dayEnd, settings.GraceMinutes) {
		return "day", nil
	}
	if settings.TripleShiftEnabled {
		mh, mm, okm1 := parseClock(shiftStartClock(settings, "middle"))
		eh, em, okm2 := parseClock(shiftEndClock(settings, "middle"))
		if okm1 && okm2 {
			if isWithinWindow(nowMin, clockToMinutes(mh, mm), clockToMinutes(eh, em), settings.GraceMinutes) {
				return "middle", nil
			}
		}
	}
	if isWithinWindow(nowMin, nightStart, nightEnd, settings.GraceMinutes) {
		return "night", nil
	}
	return "", ErrOutsideWorkWindow
}

func oppositeShift(shift string) string {
	if shift == "night" {
		return "day"
	}
	return "night"
}

// nextHandoverShift returns the next shift in dual (day↔night) or triple (day→middle→night→day) rotation.
func nextHandoverShift(fromShift string, triple bool) string {
	from, _ := normalizeShiftType(fromShift)
	if triple {
		switch from {
		case "day":
			return "middle"
		case "middle":
			return "night"
		default:
			return "day"
		}
	}
	return oppositeShift(from)
}

func shiftLabel(shift string) string {
	switch shift {
	case "night":
		return "夜班"
	case "middle":
		return "中班"
	default:
		return "白班"
	}
}

// ShiftLabelPublic returns localized shift label for API responses.
func ShiftLabelPublic(shift string) string {
	return shiftLabel(shift)
}

func (s *WorkforceTelegramService) hasCompletedShiftToday(ctx context.Context, empID uuid.UUID, date, shift string) (bool, error) {
	var count int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM work_sessions
		WHERE employee_id = $1 AND attendance_date = $2::date AND shift_type = $3 AND status = 'closed'`,
		empID, date, shift).Scan(&count)
	return count > 0, err
}

func (s *WorkforceTelegramService) telegramCheckInWithShift(ctx context.Context, empID uuid.UUID, telegramUserID int64, chatID, forcedShift string, actor *TelegramActor) (*CheckInOutcome, error) {
	return s.telegramCheckInExplicit(ctx, empID, telegramUserID, chatID, forcedShift, actor)
}

func (s *WorkforceTelegramService) GetGroupShiftState(ctx context.Context, chatID string, empID uuid.UUID, shift string) (bool, error) {
	var count int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(*) FROM wf_tg_group_shift_state
		WHERE chat_id = $1 AND employee_id = $2 AND shift_type = $3`,
		strings.TrimSpace(chatID), empID, shift).Scan(&count)
	return count > 0, err
}

func (s *WorkforceTelegramService) TelegramHandover(ctx context.Context, telegramUserID int64, note string) (*CheckInResult, *TgHandoverRow, error) {
	if err := s.rejectIfWebPunchOnly(ctx); err != nil {
		return nil, nil, err
	}
	active, err := s.IsActive(ctx)
	if err != nil || !active {
		return nil, nil, ErrTelegramDisabled
	}
	settings, err := s.GetSettings(ctx)
	if err != nil {
		return nil, nil, err
	}
	if !settings.MultiShiftEnabled() {
		return nil, nil, ErrDualShiftDisabled
	}

	empID, err := s.ResolveEmployeeByTelegramUserID(ctx, telegramUserID)
	if err != nil {
		return nil, nil, err
	}
	open, _, err := s.GetEmployeeSessionStatus(ctx, empID)
	if err != nil {
		return nil, nil, err
	}
	if !open {
		return nil, nil, ErrNoOpenSession
	}

	if _, err = s.getOpenActivitySession(ctx, empID); err == nil {
		if _, err = s.TelegramEndActivity(ctx, telegramUserID); err != nil {
			return nil, nil, err
		}
	} else if !errors.Is(err, ErrActivityNotActive) {
		return nil, nil, err
	}

	var fromShift string
	var fromSID uuid.UUID
	_ = s.db.QueryRowContext(ctx, `
		SELECT id, COALESCE(shift_type,'day') FROM work_sessions
		WHERE employee_id = $1 AND status = 'open' ORDER BY checkin_time ASC LIMIT 1`, empID).Scan(&fromSID, &fromShift)

	toShift := nextHandoverShift(fromShift, settings.TripleShiftEnabled)
	loc := tgLoadLocation(settings.Timezone)
	now := punchNow(ctx).In(loc)

	var empName, chatID string
	_ = s.db.QueryRowContext(ctx, `
		SELECT e.name, COALESCE(b.chat_id,'')
		FROM employees e
		LEFT JOIN employee_telegram_bindings b ON b.employee_id = e.id AND b.status = 1
		WHERE e.id = $1`, empID).Scan(&empName, &chatID)

	period, _ := s.DetermineCurrentPeriod(ctx, chatID, now)
	shiftDetail := ""
	if toShift == "night" {
		shiftDetail = resolveNightShiftDetail(settings, now)
	} else if toShift == "middle" {
		shiftDetail = resolveMiddleShiftDetail(settings, now)
	}
	recordDate := resolveAttendanceDate(toShift, shiftDetail, period, now, loc)
	done, err := s.hasCompletedShiftOnDate(ctx, empID, recordDate, toShift)
	if err != nil {
		return nil, nil, err
	}
	if done {
		return nil, nil, ErrShiftAlreadyCompleted
	}

	s.SyncAgentCaptureStop(ctx, empID, fromSID)
	if _, err = s.workforce.CheckOutForEmployee(ctx, empID, "telegram", nil, nil, &CheckOutOptions{ShiftType: fromShift}); err != nil {
		return nil, nil, err
	}

	handoverID := uuid.New()
	row := &TgHandoverRow{
		ID: handoverID, EmployeeID: empID, EmployeeName: empName, ChatID: chatID,
		FromShift: fromShift, ToShift: toShift, Note: strings.TrimSpace(note), HandoverAt: punchNow(ctx),
	}
	_, err = s.db.ExecContext(ctx, `
		INSERT INTO wf_tg_handovers (id, employee_id, employee_name, chat_id, from_shift, to_shift, note)
		VALUES ($1, $2, $3, NULLIF($4,''), $5, $6, NULLIF($7,''))`,
		row.ID, row.EmployeeID, row.EmployeeName, row.ChatID, row.FromShift, row.ToShift, row.Note)
	if err != nil {
		return nil, nil, err
	}

	result, err := s.workforce.CheckInForEmployee(ctx, empID, "telegram", nil, &CheckInOptions{
		ShiftType:   toShift,
		RecordDate:  recordDate,
		ShiftDetail: shiftDetail,
	})
	if err != nil {
		return nil, row, err
	}
	if chatID != "" {
		_ = s.setGroupShiftState(ctx, chatID, empID, toShift, recordDate)
	}
	result.ShiftType = toShift
	s.SyncAgentCaptureStart(ctx, empID, result.SessionID)
	s.SyncAgentTelegramCheckInNotify(ctx, empID, result.SessionID)
	return result, row, nil
}

func (s *WorkforceTelegramService) ListHandovers(ctx context.Context, date, search string, limit int) ([]TgHandoverRow, error) {
	if limit <= 0 {
		limit = 100
	}
	if limit > 500 {
		limit = 500
	}
	where := "1=1"
	args := []interface{}{}
	argN := 1
	if strings.TrimSpace(date) != "" {
		where += fmt.Sprintf(" AND handover_at::date = $%d::date", argN)
		args = append(args, date)
		argN++
	}
	if strings.TrimSpace(search) != "" {
		where += fmt.Sprintf(" AND (employee_name ILIKE $%d OR note ILIKE $%d)", argN, argN)
		args = append(args, "%"+search+"%")
		argN++
	}
	query := fmt.Sprintf(`
		SELECT id, employee_id, employee_name, COALESCE(chat_id,''), from_shift, to_shift, COALESCE(note,''), handover_at
		FROM wf_tg_handovers WHERE %s ORDER BY handover_at DESC LIMIT %d`, where, limit)
	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	items := make([]TgHandoverRow, 0)
	for rows.Next() {
		var row TgHandoverRow
		if err := rows.Scan(&row.ID, &row.EmployeeID, &row.EmployeeName, &row.ChatID,
			&row.FromShift, &row.ToShift, &row.Note, &row.HandoverAt); err != nil {
			continue
		}
		items = append(items, row)
	}
	return items, nil
}

func (s *WorkforceTelegramService) ListRankings(ctx context.Context, date, metric string, limit int) ([]TgRankingRow, error) {
	return s.ListRankingsForShift(ctx, date, metric, "", "", limit)
}

func (s *WorkforceTelegramService) forceCloseOpenActivityByEmployee(ctx context.Context, empID uuid.UUID) error {
	session, err := s.getOpenActivitySession(ctx, empID)
	if errors.Is(err, ErrActivityNotActive) {
		return nil
	}
	if err != nil {
		return err
	}
	now := punchNow(ctx)
	elapsed := int(now.Sub(session.StartedAt).Seconds())
	if elapsed < 0 {
		elapsed = 0
	}
	overtime := 0
	if session.LimitSeconds > 0 && elapsed > session.LimitSeconds {
		overtime = elapsed - session.LimitSeconds
	}
	fine := computeActivityOvertimeFine(s.loadActivityFineMap(ctx, session.ActivityCode), float64(overtime)/60.0)

	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	var penaltyID sql.NullString
	if fine > 0 {
		pid := uuid.NewString()
		_, err = tx.ExecContext(ctx, `
			INSERT INTO penalty_records (id, employee_id, employee_name, position, amount, category, reason, penalty_date, created_by, created_at)
			SELECT $1, e.id, e.name, COALESCE(e.position,''), $2, 'TG活动', $3, $4::date, 'telegram-reset', NOW()
			FROM employees e WHERE e.id = $5`,
			pid, fine, fmt.Sprintf("%s 日重置超时 %s", session.ActivityName, formatDurationZh(overtime)), session.AttendanceDate, empID)
		if err != nil {
			return err
		}
		penaltyID = sql.NullString{String: pid, Valid: true}
	}
	_, err = tx.ExecContext(ctx, `
		UPDATE wf_tg_activity_sessions SET status='closed', ended_at=NOW(), elapsed_seconds=$1,
			overtime_seconds=$2, fine_amount=$3, penalty_record_id=NULLIF($4,'')::uuid
		WHERE id=$5 AND status='open'`,
		elapsed, overtime, fine, nullStringFromNull(penaltyID), session.ID)
	if err != nil {
		return err
	}
	if err = tx.Commit(); err != nil {
		return err
	}
	if fine > 0 {
		s.pushAutoPenaltyNotify(ctx, empID, fine, "TG活动",
			fmt.Sprintf("%s 日重置超时 %s", session.ActivityName, formatDurationZh(overtime)), session.AttendanceDate)
	}
	return nil
}

func StartTelegramDailyResetScheduler(ctx context.Context, svc *WorkforceTelegramService) {
	if svc == nil {
		return
	}
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				svc.MaybeRunDailyReset(context.Background())
				svc.MaybePushMonthlyArchive(context.Background())
			}
		}
	}()
}
